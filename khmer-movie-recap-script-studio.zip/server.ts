import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { synthesizeEdgeTts } from './server/edgeTts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: '10mb' }));

// Shared Gemini AI Client instance
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const KHMER_RECAP_SYSTEM_INSTRUCTION = `
អ្នកគឺជាអ្នកនិពន្ធ និងជាអ្នកសម្រាយរឿងខ្មែរអាជីពដ៏ល្បីល្បាញ ដែលមានបទពិសោធន៍រាប់ឆ្នាំក្នុងការផលិត Script សម្រាយសាច់រឿងភាពយន្តគ្រប់ទម្រង់ (Movie Recap & Storytelling Master)។
ភារកិច្ចចម្បងរបស់អ្នកគឺ៖
1. សរសេរ Script សម្រាយរឿងជាភាសាខ្មែរឱ្យមានភាពរលូន ជក់ចិត្ត កន្ត្រាក់អារម្មណ៍ និងលម្អិតឈុតឆាកម្ដងមួយៗ (Beat-by-beat scene description)។
2. ត្រូវរៀបរាប់យ៉ាងពិស្ដារពីកាយវិការតួអង្គ (Gestures & Expressions) អារម្មណ៍ភ័យខ្លាច តក់ស្លុត ឬរំភើបញាប់ញ័រ (Emotions) និងបរិយាកាសជុំវិញ (Atmosphere & Lighting) ដោយដាច់ខាតមិនត្រូវកាត់សេចក្ដីសង្ខេបលឿនពេកឡើយ។
3. ត្រូវតែបញ្ជាក់សញ្ញាសម្គាល់ច្បាស់លាស់សម្រាប់អ្នកអានសំឡេង និងអ្នកកាត់តវីដេអូ៖
   - [ឈុតឆាក]: រៀបរាប់ពីរូបភាព ប្លង់កាមេរ៉ា បរិយាកាស និងសកម្មភាពតួអង្គ
   - [សំឡេងបន្លឺ]: សំឡេងបែបផែន (SFX), សំឡេងតន្ត្រីរំជួលចិត្ត (BGM), សំឡេងដកដង្ហើមធំ, សំឡេងទះទ្វារ, បាសបន្លឺឡើង...
   - [ពន្យល់សាច់រឿង]: ពាក្យពេចន៍របស់អ្នកសម្រាយរឿងជាភាសាខ្មែរ ប្រើប្រាស់សូរសៀងរលូន ដូចជា "ស្រាប់តែពេលនោះ...", "អ្នកទាំងអស់គ្នាសាកគិតមើលទៅ...", "អ្វីដែលគួរឱ្យរន្ធត់បំផុតនោះគឺ..."
   - [អារម្មណ៍តួអង្គ]: អារម្មណ៍ខាងក្នុង កាយវិការភ័យតក់ស្លុត ឬភាពស្ទាក់ស្ទើរ
   - [កំណត់សម្គាល់កាត់ត]: ការកាត់ប្លង់ Zoom, Slow motion, Glitch cut សម្រាប់ Editor
`;

// API 1: Generate Full Beat-by-Beat Recap Script
app.post('/api/generate-script', async (req: Request, res: Response) => {
  try {
    const {
      title,
      genre,
      synopsis,
      tone,
      pacing,
      beatCount = 6,
      customInstructions = '',
    } = req.body;

    if (!title && !synopsis) {
      return res.status(400).json({ error: 'សូមបញ្ចូលចំណងជើងរឿង ឬដំណើររឿងសង្ខេប!' });
    }

    const prompt = `
សូមបង្កើត Script សម្រាយរឿងខ្មែរអាជីពលម្អិតឈុតឆាកម្ដងមួយៗ (Beat-by-Beat Movie Recap) ដោយអនុវត្តតាមលក្ខខណ្ឌខាងក្រោម៖
- ចំណងជើងរឿង: ${title || 'រឿងអាថ៌កំបាំង'}
- ប្រភេទរឿង: ${genre || 'រន្ធត់ / ភ័យរន្ធត់'}
- សាច់រឿងសង្ខេប / ដំណើររឿង: ${synopsis || 'សាច់រឿងតានតឹងគួរឱ្យជក់ចិត្ត'}
- សម្លេង / អារម្មណ៍សាច់រឿង (Tone): ${tone || 'ញាប់ញ័រ រន្ធត់ ជក់ចិត្ត'}
- ល្បឿនសាច់រឿង (Pacing): ${pacing || 'លម្អិតខ្លាំង Beat-by-Beat មិនកាត់សេចក្តីលឿន'}
- ចំនួនឈុតឆាកគោលដៅ (Beats): ${beatCount} ឈុត
${customInstructions ? `- សេចក្តីណែនាំបន្ថែមពិសេស: ${customInstructions}` : ''}

សូមសរសេរជាភាសាខ្មែរសុទ្ធសាធ យ៉ាងពិរោះ ជក់ចិត្ត រៀបរាប់លម្អិតកាយវិការ និងបរិយាកាសដោយមិនរំលងព័ត៌មានលម្អិត។
សូមរៀបចំទម្រង់ឆ្លើយតបជា JSON តាម Schema ឱ្យបានត្រឹមត្រូវ។
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_RECAP_SYSTEM_INSTRUCTION,
        temperature: 0.8,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            genre: { type: Type.STRING },
            estimatedDuration: { type: Type.STRING, description: 'ឧ. 8-10 នាទី' },
            hookOpening: { type: Type.STRING, description: 'ពាក្យបើកឆាកទាក់ទាញអារម្មណ៍ដំបូងរបស់អ្នកសម្រាយរឿង' },
            beats: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  beatNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING, description: 'ចំណងជើងឈុតឆាក' },
                  timestamp: { type: Type.STRING, description: 'ឧ. 00:00 - 01:15' },
                  sceneDescription: { type: Type.STRING, description: 'ការរៀបរាប់ឈុតឆាក [ឈុតឆាក] ប្លង់កាមេរ៉ា បរិយាកាស' },
                  audioCue: { type: Type.STRING, description: 'សំឡេងបែបផែន និងភ្លេង [សំឡេងបន្លឺ]' },
                  narration: { type: Type.STRING, description: 'ពាក្យសម្រាយរបស់អ្នកអានជាភាសាខ្មែរ [ពន្យល់សាច់រឿង]' },
                  characterEmotion: { type: Type.STRING, description: 'កាយវិការ និងអារម្មណ៍ [អារម្មណ៍តួអង្គ]' },
                  directorNotes: { type: Type.STRING, description: 'បច្ចេកទេសកាត់ត [កំណត់សម្គាល់កាត់ត]' },
                },
                required: ['beatNumber', 'title', 'timestamp', 'sceneDescription', 'audioCue', 'narration', 'characterEmotion'],
              },
            },
            outroCallToAction: { type: Type.STRING, description: 'ពាក្យបញ្ចប់រឿង និងផ្តាំផ្ញើទស្សនិកជនចុច Like/Subscribe' },
          },
          required: ['title', 'beats', 'hookOpening'],
        },
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);

    // Ensure all beats have unique ids
    if (Array.isArray(parsed.beats)) {
      parsed.beats = parsed.beats.map((b: any, index: number) => ({
        ...b,
        id: b.id || `beat-${Date.now()}-${index + 1}`,
        beatNumber: b.beatNumber || index + 1,
      }));
    }

    res.json(parsed);
  } catch (error: any) {
    console.error('Error generating script:', error);
    res.status(500).json({ error: error.message || 'បរាជ័យក្នុងការបង្កើត Script សូមព្យាយាមម្តងទៀត។' });
  }
});

// API 2: Continue Next Scenes (Append beats)
app.post('/api/continue-script', async (req: Request, res: Response) => {
  try {
    const { title, existingBeats, direction } = req.body;

    const lastBeatsContext = (existingBeats || [])
      .slice(-3)
      .map((b: any) => `ឈុតទី ${b.beatNumber} (${b.title}): [ពន្យល់សាច់រឿង] ${b.narration}`)
      .join('\n');

    const prompt = `
នេះជាសាច់រឿងនៃរឿង "${title || 'ភាពយន្ត'}":
បរិបទឈុតចុងក្រោយ៖
${lastBeatsContext}

ទិសដៅបន្តបន្ទាប់ ឬចំណុចរបត់សាច់រឿង (Plot twist/Direction):
${direction || 'បន្តដំណើររឿងឱ្យកាន់តែតានតឹង ភ្ញាក់ផ្អើល និងដល់ចំណុចកំពូល'}

សូមសរសេរបន្ថែម 3 ឈុតឆាកបន្ទាប់ (Beats) ដោយរក្សារចនាប័ទ្មលម្អិត [ឈុតឆាក], [សំឡេងបន្លឺ], [ពន្យល់សាច់រឿង], [អារម្មណ៍តួអង្គ]។
ចាប់ផ្តើមលេខរៀងឈុតឆាកពីលេខ ${(existingBeats?.length || 0) + 1}។
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_RECAP_SYSTEM_INSTRUCTION,
        temperature: 0.8,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              beatNumber: { type: Type.INTEGER },
              title: { type: Type.STRING },
              timestamp: { type: Type.STRING },
              sceneDescription: { type: Type.STRING },
              audioCue: { type: Type.STRING },
              narration: { type: Type.STRING },
              characterEmotion: { type: Type.STRING },
              directorNotes: { type: Type.STRING },
            },
            required: ['beatNumber', 'title', 'timestamp', 'sceneDescription', 'audioCue', 'narration', 'characterEmotion'],
          },
        },
      },
    });

    const text = response.text || '[]';
    const newBeats = JSON.parse(text).map((b: any, index: number) => ({
      ...b,
      id: `beat-${Date.now()}-${index + 1}`,
      beatNumber: b.beatNumber || (existingBeats?.length || 0) + index + 1,
    }));

    res.json({ newBeats });
  } catch (error: any) {
    console.error('Error continuing script:', error);
    res.status(500).json({ error: error.message || 'បរាជ័យក្នុងការបន្តឈុតឆាក។' });
  }
});

// API 3: Enhance / Rewrite a Single Beat
app.post('/api/enhance-scene', async (req: Request, res: Response) => {
  try {
    const { beat, instructionType, customText } = req.body;
    if (!beat) {
      return res.status(400).json({ error: 'មិនមានព័ត៌មានឈុតឆាកឡើយ!' });
    }

    let instructionPrompt = '';
    if (instructionType === 'more_scary') {
      instructionPrompt = 'សូមធ្វើឱ្យឈុតនេះកាន់តែភ័យរន្ធត់ ញាប់ញ័រ បន្ថែមសូរសំឡេងព្រឺព្រួច និងការពិពណ៌នាពីភាពងងឹតត្រជាក់រណ្តំ។';
    } else if (instructionType === 'more_detail') {
      instructionPrompt = 'សូមបន្ថែមព័ត៌មានលម្អិតពីកាយវិការ ដង្ហើម ដំណក់ញើស ទឹកមុខតួអង្គ និងប្លង់កាមេរ៉ាជុំវិញ។';
    } else if (instructionType === 'smoother_voice') {
      instructionPrompt = 'សូមសម្រួលពាក្យសម្រាយ [ពន្យល់សាច់រឿង] ឱ្យរលូន ពិរោះ ងាយស្រួលអានបញ្ចូលសំឡេង និងទាក់ទាញដួងចិត្ត។';
    } else {
      instructionPrompt = customText || 'សូមកែសម្រួលឈុតនេះឱ្យកាន់តែល្អប្រសើរ និងជក់ចិត្ត។';
    }

    const prompt = `
ឈុតឆាកដើម៖
- ចំណងជើង: ${beat.title}
- [ឈុតឆាក]: ${beat.sceneDescription}
- [សំឡេងបន្លឺ]: ${beat.audioCue}
- [ពន្យល់សាច់រឿង]: ${beat.narration}
- [អារម្មណ៍តួអង្គ]: ${beat.characterEmotion}

ការកែប្រែដែលចង់បាន៖
${instructionPrompt}

សូមបង្កើតទម្រង់ថ្មីសម្រាប់ឈុតនេះជា JSON ដោយរក្សាលេខឈុត ${beat.beatNumber}។
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_RECAP_SYSTEM_INSTRUCTION,
        temperature: 0.7,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            sceneDescription: { type: Type.STRING },
            audioCue: { type: Type.STRING },
            narration: { type: Type.STRING },
            characterEmotion: { type: Type.STRING },
            directorNotes: { type: Type.STRING },
          },
          required: ['title', 'sceneDescription', 'audioCue', 'narration', 'characterEmotion'],
        },
      },
    });

    const updated = JSON.parse(response.text || '{}');
    res.json({
      ...beat,
      ...updated,
    });
  } catch (error: any) {
    console.error('Error enhancing beat:', error);
    res.status(500).json({ error: error.message || 'បរាជ័យក្នុងការកែច្នៃឈុតឆាក។' });
  }
});

// API 4: Native Khmer Edge TTS endpoint (km-KH-PisethNeural & km-KH-SreymomNeural)
app.post('/api/edge-tts', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'km-KH-PisethNeural', rate = '+0%', pitch = '+0Hz', download = false } = req.body;
    if (!text || text.trim() === '') {
      return res.status(400).json({ error: 'សូមបញ្ចូលអត្ថបទសម្រាប់បញ្ចេញសំឡេង' });
    }

    const cleanText = text.slice(0, 2500);
    const audioBuffer = await synthesizeEdgeTts(cleanText, voice, rate, pitch);

    if (download) {
      res.setHeader('Content-Type', 'audio/mpeg');
      res.setHeader('Content-Disposition', 'attachment; filename="recap_audio_sample.mp3"');
      return res.send(audioBuffer);
    }

    const base64Audio = audioBuffer.toString('base64');
    res.json({
      audioData: base64Audio,
      format: 'audio/mpeg',
      voiceUsed: voice.includes('Pipha') ? 'km-KH-PisethNeural' : voice,
    });
  } catch (error: any) {
    console.error('Edge TTS Error:', error);
    res.status(500).json({ error: error.message || 'បរាជ័យក្នុងការផលិតសំឡេង Edge TTS' });
  }
});

// API 5: Text-to-Speech preview for the narration (Primary: Edge TTS for Khmer, Fallback: Gemini)
app.post('/api/tts-narration', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'km-KH-PisethNeural' } = req.body;
    if (!text || text.trim() === '') {
      return res.status(400).json({ error: 'សូមបញ្ចូលអត្ថបទសម្រាប់បញ្ចេញសំឡេង' });
    }

    const cleanText = text.slice(0, 1500);

    // Try Microsoft Edge TTS first for authentic Khmer pronunciation
    try {
      const audioBuffer = await synthesizeEdgeTts(cleanText, voiceName);
      const base64Audio = audioBuffer.toString('base64');
      return res.json({
        audioData: base64Audio,
        format: 'audio/mpeg',
        provider: 'edge-tts',
        voiceUsed: voiceName.includes('Pipha') ? 'km-KH-PisethNeural' : voiceName,
      });
    } catch (edgeError: any) {
      console.warn('Edge TTS failed, falling back to Gemini TTS:', edgeError?.message);
    }

    // Fallback: Gemini TTS
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText.slice(0, 600),
              speechMetadata: {
                style: 'Dramatic cinematic movie recap narrator, suspenseful pacing and deep engaging tone',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      return res.status(500).json({ error: 'មិនអាចផលិតសំឡេងបានឡើយ' });
    }

    res.json({ audioData: base64Audio, format: 'audio/wav', provider: 'gemini' });
  } catch (error: any) {
    console.error('Error generating TTS:', error);
    res.status(500).json({ error: error.message || 'កំហុសបច្ចេកទេសក្នុងសំឡេង TTS' });
  }
});

// Static mount for generated recaps (scripts and audio files)
const storagePath = path.resolve(__dirname, 'generated_recaps');
app.use('/files', express.static(storagePath));

// Proxy /api/recap/* to FastAPI server on port 8001
app.all('/api/recap/*', async (req: Request, res: Response) => {
  try {
    const targetUrl = `http://127.0.0.1:8001${req.originalUrl}`;
    const response = await fetch(targetUrl, {
      method: req.method,
      headers: {
        'Content-Type': (req.headers['content-type'] as string) || 'application/json',
      },
      body: ['POST', 'PUT', 'PATCH'].includes(req.method) ? JSON.stringify(req.body) : undefined,
    });
    const contentType = response.headers.get('content-type') || 'application/json';
    res.setHeader('content-type', contentType);
    res.status(response.status);
    const data = await response.text();
    return res.send(data);
  } catch (err: any) {
    res.status(502).json({ error: 'FastAPI service unavailable: ' + err.message });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
