import requests
import json
import time

url = "http://localhost:8001/api/recap/generate"
payload = {
    "movie_title": "រថភ្លើងទៅប៊ូសាន (Train to Busan)",
    "genre": "ភ័យរន្ធត់ (Horror)",
    "voice": "km-KH-PisethNeural",
    "notes": "តួអង្គសំខាន់ Seok-woo និងកូនស្រី Su-an"
}

res = requests.post(url, json=payload, timeout=10)
print("POST status:", res.status_code)
data = res.json()
print("Response:", data)
task_id = data.get("task_id")

if task_id:
    for i in range(12):
        time.sleep(3)
        status_res = requests.get(f"http://localhost:8001/api/recap/status/{task_id}")
        status_data = status_res.json()
        print(f"Status check {i+1}: {status_data.get('status')} - {status_data.get('progress')}% - {status_data.get('stage')}")
        if status_data.get("status") in ["completed", "failed"]:
            print("Final result:", status_data)
            break
