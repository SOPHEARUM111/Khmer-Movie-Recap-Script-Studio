import os
import asyncio
import subprocess
from voice_cloning_engine import voice_cloner

async def test_listen():
    sample_file = "my_voice.wav"
    
    # ប្រសិនបើ my_voice.wav មិនទាន់មាន ប្រើឯកសារ sample ក្នុង workspace ធ្វើជា my_voice.wav
    if not os.path.exists(sample_file):
        for candidate in ["recap_audio_sample.mp3", "test_khmer_cli.mp3"]:
            if os.path.exists(candidate):
                print(f"ℹ️ មិនទាន់ឃើញ {sample_file} ទេ, កំពុងរៀបចំចេញពី {candidate}...")
                ffmpeg_cmd = ["ffmpeg", "-y", "-i", candidate, "-ac", "1", "-ar", "16000", sample_file]
                subprocess.run(ffmpeg_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                break

    if not os.path.exists(sample_file):
        print("❌ សូមដាក់ឯកសារសំឡេង my_voice.wav ក្នុង folder ជាមុនសិន!")
        return

    # ១. បញ្ចូលសំឡេងគំរូរបស់អ្នក
    print(f"🎙️ កំពុងដំណើរការ Denoise & Clean Sample ពីឯកសារ៖ {sample_file}")
    profile_id = voice_cloner.process_and_clean_sample(sample_file, "សំឡេងរបស់ខ្ញុំ")
    
    # ២. ឱ្យ AI យកសំឡេងរបស់អ្នកទៅអានអត្ថបទសម្រាយរឿង
    test_text = "ជំរាបសួរប្រិយមិត្តទាំងអស់គ្នា! នេះជាសំឡេងមនុស្សពិតរបស់ខ្ញុំដែលត្រូវបាន AI ចម្លងយកមកសម្រាយរឿង Train to Busan។"
    output_audio = "cloned_result.mp3"
    
    print("⏳ កំពុងបង្កើតសំឡេង Clone...")
    await voice_cloner.synthesize_with_cloned_voice(test_text, profile_id, output_audio)
    print(f"🎉 រួចរាល់! អ្នកអាចបើកស្តាប់ឯកសារ៖ {output_audio}")

if __name__ == "__main__":
    asyncio.run(test_listen())
