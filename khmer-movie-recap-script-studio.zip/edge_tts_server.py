import asyncio
import os
import edge_tts
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ==============================================================================
# Script គំរូសម្រាប់ដំណើរការផ្ទាល់ (Standalone execution):
# python edge_tts_server.py
# ==============================================================================
TEXT = "ជំរាបសួរប្រិយមិត្តទាំងអស់គ្នា! សូមស្វាគមន៍មកកាន់ការសម្រាយរឿង Train to Busan។"
# ចំណាំ៖ ក្នុងប្រព័ន្ធ Microsoft Edge TTS សំឡេងខ្មែរផ្លូវការគឺ:
# - km-KH-PisethNeural (សំឡេងប្រុស ពិសិដ្ឋ)
# - km-KH-SreymomNeural (សំឡេងស្រី ស្រីមុំ)
VOICE = "km-KH-PisethNeural"
OUTPUT_FILE = "recap_audio_sample.mp3"


async def generate_voice(
    text: str = TEXT,
    voice: str = VOICE,
    rate: str = "+0%",
    pitch: str = "+0Hz",
    output_path: str = OUTPUT_FILE,
):
    """ផលិតឯកសារសំឡេង MP3 ដោយប្រើ Microsoft Edge TTS"""
    clean_voice = voice
    if "Pipha" in voice:
        clean_voice = "km-KH-PisethNeural"

    communicate = edge_tts.Communicate(text, clean_voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)
    print(f"បានបង្កើតឯកសារសំឡេងជោគជ័យ៖ {output_path}")
    return output_path


# ==============================================================================
# FastAPI Service សម្រាប់បញ្ជូនសំឡេងទៅកាន់ Frontend / API
# ដំណើរការតាមរយៈ៖ uvicorn edge_tts_server:app --port 8000 --reload
# ==============================================================================
app = FastAPI(
    title="Khmer Movie Recap TTS Service",
    description="សេវាកម្មផលិតសំឡេងសម្រាយរឿងជាភាសាខ្មែរ (Edge TTS & Gemini)",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class VoiceRequest(BaseModel):
    text: str = Field(..., description="អត្ថបទសម្រាយរឿងជាភាសាខ្មែរ")
    voice: str = Field(
        default="km-KH-PisethNeural",
        description="ឈ្មោះសំឡេង: km-KH-PisethNeural (ប្រុស) ឬ km-KH-SreymomNeural (ស្រី)",
    )
    rate: str = Field(default="+0%", description="ល្បឿនអាន: ឧ. -10%, +0%, +10%")
    pitch: str = Field(default="+0Hz", description="កម្ពស់សំឡេង: ឧ. -5Hz, +0Hz, +5Hz")


@app.get("/")
def root():
    return {
        "status": "online",
        "service": "Khmer Recap Edge-TTS API",
        "voices": [
            {
                "id": "km-KH-PisethNeural",
                "name": "ពិសិដ្ឋ (Piseth)",
                "gender": "Male",
                "recommended_for": "រឿងរន្ធត់/ភ័យរន្ធត់/Action",
            },
            {
                "id": "km-KH-SreymomNeural",
                "name": "ស្រីមុំ (Sreymom)",
                "gender": "Female",
                "recommended_for": "រឿងមនោសញ្ចេតនា/រឿងជីវិត/Fantasy",
            },
        ],
    }


@app.post("/api/tts")
async def api_tts(req: VoiceRequest):
    try:
        clean_voice = req.voice
        if "Pipha" in clean_voice:
            clean_voice = "km-KH-PisethNeural"

        communicate = edge_tts.Communicate(
            req.text, clean_voice, rate=req.rate, pitch=req.pitch
        )
        audio_bytes = bytearray()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_bytes.extend(chunk["data"])

        return Response(content=bytes(audio_bytes), media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/tts/download")
async def api_tts_download(req: VoiceRequest):
    try:
        output_name = "recap_audio_sample.mp3"
        await generate_voice(
            text=req.text,
            voice=req.voice,
            rate=req.rate,
            pitch=req.pitch,
            output_path=output_name,
        )
        return FileResponse(
            output_name,
            media_type="audio/mpeg",
            filename="recap_audio_sample.mp3",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    print("កំពុងដំណើរការផលិតសំឡេងគំរូ...")
    asyncio.run(generate_voice())
