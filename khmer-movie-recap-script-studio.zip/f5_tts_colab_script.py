# ==============================================================================
# ប្រព័ន្ធ Clone សំឡេងមនុស្សពិត ១០០% (Zero-Shot Cross-Lingual Voice Cloning)
# បច្ចេកវិទ្យា៖ F5-TTS / XTTS-v2 (ដំណើរការឥតគិតថ្លៃលើ Google Colab ឬ Local GPU)
# ==============================================================================
# របៀបប្រើប្រាស់៖
# ១. បើក https://colab.research.google.com រួចជ្រើសរើស GPU (T4 GPU - Free)
# ២. Run កូដនេះ រួចទម្លាក់ File សំឡេងរបស់អ្នកចូល (ឧ. sample_voice.wav)
# ៣. វាយអត្ថបទជាអក្សរ នោះ AI នឹងបន្លឺសំឡេងដូចអ្នក ១០០%!
# ==============================================================================

import os
import sys
import asyncio
import subprocess

def install_dependencies():
    print("🚀 [ជំហានទី ១] កំពុងដំឡើងបណ្ណាល័យ AI Voice Cloning...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "f5-tts", "soundfile", "torchaudio", "edge-tts"], check=True)
    except Exception as e:
        print(f"⚠️ Warning during installation: {e}")

# កំណត់សំឡេងគំរូមនុស្សពិត (អ្នកអាចថតសំឡេងខ្លួនឯង ១០ ទៅ ២០ វិនាទី)
SAMPLE_AUDIO = "sample_voice.wav"
SAMPLE_TEXT = "ជំរាបសួរប្រិយមិត្តទាំងអស់គ្នា នេះជាសំឡេងគំរូរបស់ខ្ញុំ។"

# អត្ថបទសម្រាយរឿងដែលអ្នកចង់ឱ្យសំឡេង Clone អាន
RECAP_TEXT_TO_READ = """
ភ្លាមនោះ ទ្វារទូរថភ្លើងត្រូវបានទម្លុះ! 
ហ្វូងខ្មោចឆៅរាប់សិបនាក់បានសម្រុកចូលមកដូចទឹកបាក់ទំនប់ 
គ្មាននរណាម្នាក់អាចគេចខ្លួនផុតឡើយ! 
តើឪពុកម្នាក់នេះអាចការពារកូនស្រីជាទីស្រឡាញ់បានដោយរបៀបណា?
"""

def generate_exact_cloned_voice(ref_audio_path, ref_text, gen_text, output_file="final_cloned_voice.wav"):
    """
    អានអត្ថបទជាអក្សរ ដោយប្រើប្រាស់ទឹកដមសំឡេងមនុស្សពិតដែលបាន Clone ដូចបេះបិទ
    """
    print(f"🎙️ កំពុងដំណើរការ Voice Cloning សម្រាប់អត្ថបទ៖\n{gen_text.strip()}\n")
    try:
        from f5_tts.api import F5TTS
        f5tts = F5TTS(model_type="F5-TTS")
        f5tts.infer(
            ref_file=ref_audio_path,
            ref_text=ref_text,
            gen_text=gen_text,
            file_wave_container=output_file
        )
        print(f"🎉 បង្កើតសំឡេង Clone ជោគជ័យ៖ {output_file}")
        return output_file
    except ImportError:
        print("⚠️ មិនទាន់មាន F5-TTS Library ប្រើប្រាស់ Fallback Engine (Edge-TTS) ជំនួស...")
        import edge_tts
        async def _run_fallback():
            communicate = edge_tts.Communicate(gen_text, "km-KH-PisethNeural")
            await communicate.save(output_file)
        asyncio.run(_run_fallback())
        print(f"✅ បង្កើតសំឡេងជោគជ័យតាម Edge-TTS: {output_file}")
        return output_file

if __name__ == "__main__":
    print("🚀 ប្រព័ន្ធ Clone សំឡេងមនុស្សពិត ១០០% ត្រូវបានចាប់ផ្តើម!")
    # ប្រសិនបើមាន Sample Audio
    if os.path.exists(SAMPLE_AUDIO):
        generate_exact_cloned_voice(SAMPLE_AUDIO, SAMPLE_TEXT, RECAP_TEXT_TO_READ)
    else:
        print(f"ℹ️ ពុំបានរកឃើញ {SAMPLE_AUDIO} ទេ។ កំពុងបង្កើតសំឡេងសម្រាយគំរូ...")
        generate_exact_cloned_voice("my_voice.wav", SAMPLE_TEXT, RECAP_TEXT_TO_READ)
