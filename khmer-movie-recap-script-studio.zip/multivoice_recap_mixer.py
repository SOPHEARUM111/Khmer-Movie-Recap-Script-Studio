# ==============================================================================
# ប្រព័ន្ធបម្លែង និងផ្គុំសំឡេងតួអង្គចម្រុះស្វ័យប្រវត្តិ (Multi-Voice Audio Drama Engine)
# បច្ចេកវិទ្យា៖ Edge-TTS + FFmpeg Audio Mixer
# ==============================================================================

import os
import re
import asyncio
import subprocess
from typing import List, Dict

# ការកំណត់ទឹកដមសំឡេងសម្រាប់តួអង្គនីមួយៗ (ប្រើប្រាស់ Voice ផ្លូវការ km-KH-PisethNeural & km-KH-SreymomNeural)
ROLE_SETTINGS = {
    "អ្នកសម្រាយ": {
        "voice": "km-KH-PisethNeural",
        "rate": "+2%",
        "pitch": "+0Hz"
    },
    "ក្មេងប្រុស": {
        "voice": "km-KH-PisethNeural",
        "rate": "+15%",
        "pitch": "+15Hz"   # សំឡេងខ្ពស់ស្រួចបែបក្មេងប្រុស
    },
    "ក្មេងស្រី": {
        "voice": "km-KH-SreymomNeural",
        "rate": "+12%",
        "pitch": "+15Hz"   # សំឡេងខ្ពស់ស្រទន់បែបក្មេងស្រី
    },
    "មនុស្សប្រុស": {
        "voice": "km-KH-PisethNeural",
        "rate": "-2%",
        "pitch": "-5Hz"    # សំឡេងរឹងមាំ
    },
    "មនុស្សស្រី": {
        "voice": "km-KH-SreymomNeural",
        "rate": "+0%",
        "pitch": "+5Hz"    # សំឡេងនារីពេញវ័យ
    },
    "មនុស្សចាស់": {
        "voice": "km-KH-PisethNeural",
        "rate": "-15%",
        "pitch": "-12Hz"   # សំឡេងយឺត និងគ្រល័រទាប
    },
    "បិសាច": {
        "voice": "km-KH-PisethNeural",
        "rate": "-18%",
        "pitch": "-15Hz"   # សំឡេងបិសាចគ្រល័រធ្ងន់
    }
}

TEMP_DIR = "temp_voice_clips"
os.makedirs(TEMP_DIR, exist_ok=True)

def parse_multi_voice_script(raw_script: str) -> List[Dict[str, str]]:
    """
    បំបែកអត្ថបទទៅតាមស្លាកតួអង្គ [តួអង្គ] សេចក្តីលម្អិត
    """
    segments = []
    lines = raw_script.strip().split("\n")
    default_role = "អ្នកសម្រាយ"

    for line in lines:
        line = line.strip()
        if not line:
            continue

        match = re.match(r"^\[(.*?)\]\s*(.*)$", line)
        if match:
            tag_name = match.group(1).strip()
            content = match.group(2).strip()

            role = default_role
            for known_role in ROLE_SETTINGS.keys():
                if known_role in tag_name:
                    role = known_role
                    break

            if content:
                segments.append({"role": role, "text": content})
        else:
            segments.append({"role": default_role, "text": line})

    return segments

async def render_segment_audio(segment: Dict[str, str], output_file: str):
    """
    បម្លែងឃ្លានីមួយៗទៅជាសំឡេងតាមលក្ខណៈតួអង្គ
    """
    import edge_tts
    role = segment["role"]
    config = ROLE_SETTINGS.get(role, ROLE_SETTINGS["អ្នកសម្រាយ"])

    clean_voice = config["voice"]
    if "Pipha" in clean_voice:
        clean_voice = "km-KH-PisethNeural"

    try:
        communicate = edge_tts.Communicate(
            text=segment["text"],
            voice=clean_voice,
            rate=config["rate"],
            pitch=config["pitch"]
        )
        await communicate.save(output_file)
    except Exception as e:
        print(f"⚠️ Warning rendering {role} ({e}), retrying standard TTS...")
        communicate = edge_tts.Communicate(
            text=segment["text"],
            voice=clean_voice
        )
        await communicate.save(output_file)

async def build_multi_voice_audio(script_text: str, final_audio_output: str = "final_movie_recap_multivoice.mp3"):
    """
    ដំណើរការផ្គុំសំឡេងតួអង្គទាំងអស់បញ្ចូលគ្នាជាឯកសារតែមួយ
    """
    segments = parse_multi_voice_script(script_text)
    clip_files = []

    print(f"🎬 រកឃើញ {len(segments)} ឃ្លាសន្ទនា។ កំពុងបម្លែងសំឡេងតួអង្គ...")

    for i, seg in enumerate(segments):
        clip_path = os.path.join(TEMP_DIR, f"clip_{i:03d}_{seg['role']}.mp3")
        await render_segment_audio(seg, clip_path)
        clip_files.append(clip_path)
        print(f"  [{i+1}/{len(segments)}] {seg['role']}: {seg['text'][:35]}...")

    # បង្កើតឯកសារ Concat សម្រាប់ FFmpeg ផ្គុំសំឡេង
    concat_list_file = os.path.join(TEMP_DIR, "concat_audio_list.txt")
    with open(concat_list_file, "w", encoding="utf-8") as f:
        for clip in clip_files:
            f.write(f"file '{os.path.abspath(clip)}'\n")

    # ផ្គុំឯកសារសំឡេងទាំងអស់ចូលគ្នា
    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", concat_list_file,
        "-c", "copy",
        final_audio_output
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    print(f"\n🎉 ជោគជ័យ! សំឡេងសម្រាយរឿងប្តូរសំឡេងតួអង្គត្រូវបានបង្កើតឡើង៖ {final_audio_output}")
    return final_audio_output

if __name__ == "__main__":
    # សាច់រឿងគំរូសាកល្បងដែលមានតួអង្គ ៧ ផ្សេងគ្នា
    SAMPLE_RECAP_STORY = """
    [អ្នកសម្រាយ] រថភ្លើងឆ្ពោះទៅកាន់ទីក្រុងប៊ូសាន បានចាប់ផ្តើមចេញដំណើរក្នុងបរិយាកាសដ៏ស្ងប់ស្ងាត់ ប៉ុន្តែគ្មាននរណាម្នាក់ដឹងទេថានេះជាដំណើរឆ្ពោះទៅកាន់ឋាននរក។
    [ក្មេងស្រី] ប៉ា! ហេតុអីបានជាមនុស្សនៅខាងក្រៅនោះរត់ជាន់គ្នាអ៊ីចឹង? កូនខ្លាចណាស់ប៉ា!
    [មនុស្សប្រុស] កុំភ័យកូន! មកឈរក្រោយខ្នងប៉ា គ្មាននរណាអាចធ្វើបាបកូនបានឡើយ!
    [មនុស្សចាស់] លោកអើយលោក! តើមានរឿងចង្រៃអីកើតឡើងចំពោះស្រុកយើងទៅវិញ? ព្រះជួយផង!
    [បិសាច] ក្រោកឡើង... គ្មាននរណាម្នាក់អាចគេចចេញពីទូរថភ្លើងនេះបានឡើយ! ហាហាហា!
    [មនុស្សស្រី] បង! ជួយកូនយើងផង! ពួកវាចូលមកដល់ក្បែរយើងហើយបង!
    [ក្មេងប្រុស] បងប្រុស! ខ្ញុំឃើញផ្លូវរូងក្រោមដីនៅខាងមុខហើយ រត់ទៅទាំងអស់គ្នា!
    [អ្នកសម្រាយ] ការតស៊ូដើម្បីរស់រានមានជីវិតបានចាប់ផ្តើមឡើង ចំកណ្តាលហ្វូងខ្មោចឆៅដែលគ្មានក្តីមេត្តា។
    """

    asyncio.run(build_multi_voice_audio(SAMPLE_RECAP_STORY))
