import os
import uuid
import asyncio
import re
from typing import Dict, Any, Optional
from fastapi import FastAPI, BackgroundTasks, HTTPException, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import google.generativeai as genai
import edge_tts
from voice_cloner import voice_cloner, VOICE_PROFILES_DIR

# --- ការកំណត់រចនាសម្ព័ន្ធ (Configuration) ---
# កំណត់ Gemini API Key របស់អ្នក (អាចយកពី aistudio.google.com)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY and GEMINI_API_KEY != "YOUR_GEMINI_API_KEY_HERE":
    genai.configure(api_key=GEMINI_API_KEY)

# ថតផ្ទុកឯកសារសំឡេង និង Script
STORAGE_DIR = "generated_recaps"
os.makedirs(STORAGE_DIR, exist_ok=True)

app = FastAPI(
    title="Movie Recap AI Engine API",
    description="Khmer Movie Recap generation with Gemini 3.5/3.8 Flash & Zero-Shot Voice Cloning / Edge TTS Voiceover",
    version="1.1.0"
)

# អនុញ្ញាតឱ្យ Mobile App (Flutter / React Native / Web) អាចតភ្ជាប់បាន (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# បើក Folder សម្រាប់ឱ្យ App ទាញយកឯកសារ Audio/Text/Voice Profiles
app.mount("/files", StaticFiles(directory=STORAGE_DIR), name="files")
app.mount("/cloned_voice_profiles", StaticFiles(directory=VOICE_PROFILES_DIR), name="cloned_voice_profiles")

# ឃ្លាំងផ្ទុកស្ថានភាព Task ក្នុង Memory (សម្រាប់ Production អាចប្តូរទៅប្រើ Redis)
task_db: Dict[str, Dict[str, Any]] = {}

# ផែនទីកំណត់ឈ្មោះសំឡេង Edge TTS ខ្មែរ
VOICE_MAP = {
    "km-KH-PiphaNeural": "km-KH-PisethNeural",
    "km-KH-PisethNeural": "km-KH-PisethNeural",
    "km-KH-SreymomNeural": "km-KH-SreymomNeural",
    "Pipha": "km-KH-PisethNeural",
    "Piseth": "km-KH-PisethNeural",
    "Sreymom": "km-KH-SreymomNeural",
}

def resolve_khmer_voice(voice_name: str) -> str:
    """កំណត់ឈ្មោះ voice ត្រឹមត្រូវសម្រាប់ edge-tts (Piseth ឬ Sreymom)"""
    if not voice_name:
        return "km-KH-PisethNeural"
    if voice_name in VOICE_MAP:
        return VOICE_MAP[voice_name]
    if "sreymom" in voice_name.lower():
        return "km-KH-SreymomNeural"
    return "km-KH-PisethNeural"

# --- ទម្រង់ទិន្នន័យ (Pydantic Models) ---
class RecapRequest(BaseModel):
    movie_title: str
    genre: str = "ភ័យរន្ធត់ (Horror)"
    voice: str = "km-KH-PisethNeural"
    duration: int = 90
    notes: str = ""
    include_child_voice: bool = True
    include_elderly_voice: bool = True
    use_cloned_voice: bool = False
    cloned_voice_id: Optional[str] = None

# --- អនុគមន៍ជំនួយសម្រាប់ហៅ Gemini ៥ វគ្គ ---
ACT_PROMPTS = [
    {"act": "Act I (00-15mn)", "instruction": "សរសេរ Act I: ការណែនាំតួអង្គ បរិយាកាសដំបូង និងឧប្បត្តិហេតុដំបូងដែលបង្កបញ្ហា យ៉ាងតិច 800 ពាក្យ។ កុំទាន់បញ្ចប់រឿង។"},
    {"act": "Act II (15-45mn)", "instruction": "សរសេរ Act II: ដំណើររឿងកាន់តែស្មុគស្មាញ ឧបសគ្គធំៗ និងការរត់គេចខ្លួនយ៉ាងតានតឹង យ៉ាងតិច 1000 ពាក្យ។"},
    {"act": "Act III (45-70mn)", "instruction": "សរសេរ Act III: ចំណុចកណ្ដាលនៃការបែកបាក់ អស់សង្ឃឹម និងការតស៊ូវាយទម្លុះទូរថភ្លើង យ៉ាងតិច 1000 ពាក្យ។"},
    {"act": "Act IV (70-85mn)", "instruction": "សរសេរ Act IV: ចំណុចកំពូល (Climax) ភាពតក់ស្លុត និងការប្រយុទ្ធចុងក្រោយ យ៉ាងតិច 1000 ពាក្យ។"},
    {"act": "Act V (85-90mn)", "instruction": "សរសេរ Act V: វគ្គបញ្ចប់ដ៏កម្សត់ ការលះបង់ ការសង្គ្រោះ និងទស្សនវិជ្ជាដាស់តឿនជីវិត ព្រមទាំងពាក្យជំរាបលា យ៉ាងតិច 800 ពាក្យ។"},
]

def get_active_gemini_models():
    """បញ្ជីម៉ូដែល Gemini ដែលដំណើរការបានល្អបំផុត (gemini-3.8-flash, gemini-3.1-flash-lite)"""
    candidate_names = ["gemini-3.8-flash", "gemini-3.1-flash-lite"]
    system_instruction = (
        "អ្នកគឺជាអ្នកសម្រាយរឿងខ្មែរអាជីព។ សរសេរ Script សម្រាយរឿងជាភាសាខ្មែរឱ្យមានភាពរលូន "
        "ជក់ចិត្ត លម្អិតឈុតឆាកម្ដងមួយៗ (Beat-by-beat) ដោយដាក់សញ្ញាសម្គាល់ [ឈុតឆាក] និង [សំឡេង]។"
    )
    models = []
    for name in candidate_names:
        try:
            m = genai.GenerativeModel(model_name=name, system_instruction=system_instruction)
            models.append((name, m))
        except Exception:
            pass
    return models

def generate_fallback_act(movie_title: str, genre: str, stage_name: str, notes: str) -> str:
    """បង្កើតអត្ថបទសម្រាយរឿងខ្មែរគុណភាពខ្ពស់ ក្នុងករណី API Quota កំណត់"""
    templates = {
        "Act I (00-15mn)": (
            f"[ឈុតឆាក: ពន្លឺថ្ងៃរៀបលិច បរិយាកាសស្ងប់ស្ងាត់តែបង្កប់ភាពអាថ៌កំបាំងក្នុងរឿង {movie_title}]\\n"
            f"[សំឡេងបន្លឺ: សំឡេងតន្ត្រីរំជួលចិត្តបែប {genre} និងសំឡេងខ្យល់បក់រំហើយ]\\n"
            f"[ពន្យល់សាច់រឿង]: សួស្តីបងប្អូនទាំងអស់គ្នា! ថ្ងៃនេះយើងនឹងនាំអារម្មណ៍អ្នកទាំងអស់គ្នាមកទស្សនានូវរឿង {movie_title}។ "
            f"ដំណើររឿងចាប់ផ្តើមពីតួអង្គសំខាន់ដែលកំពុងប្រឈមមុខនឹងស្ថានភាពមិនធម្មតា។ គ្រប់យ៉ាងមើលទៅដូចជាធម្មតា "
            f"ប៉ុន្តែនៅពីក្រោយភាពស្ងប់ស្ងាត់នេះ គ្រោះកាចដ៏ធំធេងកំពុងរង់ចាំលេបត្របាក់ជីវិតពួកគេ...\\n"
            f"[អារម្មណ៍តួអង្គ: ភ័យព្រួយ ស្រឡាំងកាំង មិនដឹងខ្លួនថាគ្រោះថ្នាក់បានឈានមកដល់]"
        ),
        "Act II (15-45mn)": (
            f"[ឈុតឆាក: ការប្រទាញប្រទង់ ឧបសគ្គធំៗបានកើតឡើងយ៉ាងរហ័ស]\\n"
            f"[សំឡេងបន្លឺ: សំឡេងបេះដូងលោតញាប់ និងសំឡេងទះទ្វារយ៉ាងខ្លាំង]\\n"
            f"[ពន្យល់សាច់រឿង]: ចូលមកដល់វគ្គទីពីរ ភាពស្មុគស្មាញបានកើតឡើងជាបន្តបន្ទាប់! តួអង្គយើងត្រូវបង្ខំចិត្តរត់គេចខ្លួន "
            f"យ៉ាងតក់ស្លុត ព្រោះឧបសគ្គដ៏សាហាវបានឡោមព័ទ្ធជុំទិស។ ម្នាក់ៗស្ទើរតែអស់ដង្ហើមទៅហើយ "
            f"ខណៈដែលពួកគេព្យាយាមស្វែងរកច្រកចេញតែមួយគត់ដើម្បីរស់រានមានជីវិត...\\n"
            f"[កំណត់សម្គាល់កាត់ត: ប្លង់ Zoom លឿន និង Slow-motion ត្រង់ឈុតរត់គេច]"
        ),
        "Act III (45-70mn)": (
            f"[ឈុតឆាក: ភាពអស់សង្ឃឹម និងការបែកបាក់គ្នាក្នុងក្រុម]\\n"
            f"[សំឡេងបន្លឺ: ភ្លេងកម្សត់លាយឡំភាពតានតឹង]\\n"
            f"[ពន្យល់សាច់រឿង]: មកដល់ចំណុចកណ្តាលរឿង ស្ថានការណ៍កាន់តែអាក្រក់ទៅៗ! ការបែកបាក់រវាងតួអង្គបានកើតឡើង "
            f"សេចក្តីទុកចិត្តត្រូវបានសាកល្បងយ៉ាងធ្ងន់ធ្ងរ។ គ្មានអ្នកណាដឹងច្បាស់ទេថាតើអ្នកណានឹងអាចឆ្លងផុតរាត្រីដ៏ខ្មៅងងឹតនេះបានឡើយ...\\n"
            f"[អារម្មណ៍តួអង្គ: ទឹកភ្នែកស្រក់ចុះ ភាពឯកោ និងការតស៊ូដល់ដង្ហើមចុងក្រោយ]"
        ),
        "Act IV (70-85mn)": (
            f"[ឈុតឆាក: ចំណុចកំពូល Climax ការប្រយុទ្ធតតាំងដ៏អស្ចារ្យ]\\n"
            f"[សំឡេងបន្លឺ: សំឡេងផ្ទុះយ៉ាងកក្រើក និងស្គរវាយសម្រុកយ៉ាងលឿន]\\n"
            f"[ពន្យល់សាច់រឿង]: នេះជាចំណុច Climax នៃរឿង {movie_title}! គ្មានផ្លូវថយក្រោយទៀតទេ តួអង្គទាំងអស់ត្រូវតែប្រឈមមុខ "
            f"នឹងការពិតដ៏សាហាវ។ ការវាយបក និងការប្រយុទ្ធដ៏ស្វិតស្វាញបានចាប់ផ្តើមឡើង "
            f"ធ្វើឱ្យទស្សនិកជនទប់ដង្ហើមតាមគ្រប់វិនាទី...\\n"
            f"[កំណត់សម្គាល់កាត់ត: Glitch effect និងការកាត់ប្លង់ញាប់ស្មេរ]"
        ),
        "Act V (85-90mn)": (
            f"[ឈុតឆាក: ពន្លឺព្រះអាទិត្យរះឡើងវិញលើសមរភូមិដ៏ស្ងប់ស្ងាត់]\\n"
            f"[សំឡេងបន្លឺ: ភ្លេងរំជួលចិត្ត និងការដកដង្ហើមធូរស្រាល]\\n"
            f"[ពន្យល់សាច់រឿង]: ទីបំផុត ព្យុះសង្ឃរាបានកន្លងផុតទៅ។ ការលះបង់ដ៏ធំធេងបានបន្សល់ទុកនូវមេរៀនជីវិតដ៏មានតម្លៃ "
            f"ដែលដាស់តឿនយើងគ្រប់គ្នាអំពីតម្លៃនៃគ្រួសារ និងក្តីស្រឡាញ់។ សូមអរគុណបងប្អូនទាំងអស់គ្នាសម្រាប់ការទស្សនា "
            f"សូមជួយ Like និង Subscribe ដើម្បីតាមដានរឿងល្អៗជាបន្តទៀត!\\n"
            f"[អារម្មណ៍តួអង្គ: ស្នាមញញឹមទាំងទឹកភ្នែក និងក្តីសង្ឃឹមជាថ្មី]"
        ),
    }
    return templates.get(stage_name, f"[ពន្យល់សាច់រឿង]: សាច់រឿងបន្តយ៉ាងជក់ចិត្តក្នុងរឿង {movie_title}...")

async def process_recap_pipeline(task_id: str, request: RecapRequest):
    try:
        current_api_key = os.getenv("GEMINI_API_KEY") or GEMINI_API_KEY
        if current_api_key and current_api_key != "YOUR_GEMINI_API_KEY_HERE":
            genai.configure(api_key=current_api_key)

        task_db[task_id]["status"] = "generating_script"
        task_db[task_id]["progress"] = 10
        
        # បង្កើត Chat Session លើ Gemini
        models = get_active_gemini_models()
        chat = None
        for name, m in models:
            try:
                chat = m.start_chat(history=[])
                break
            except Exception:
                continue

        full_script = f"# សម្រាយរឿង៖ {request.movie_title}\\n\\n"
        full_script += f"**ប្រភេទរឿង**៖ {request.genre}\\n\\n"
        
        # រត់ Chaining ម្តងមួយ Act ទាំង ៥
        for index, item in enumerate(ACT_PROMPTS):
            stage_name = item["act"]
            task_db[task_id]["stage"] = f"កំពុងសរសេរ {stage_name}..."
            task_db[task_id]["progress"] = 15 + (index * 12)  # កើនពី 15% ដល់ 63%
            
            prompt = (
                f"រឿង៖ {request.movie_title} (ប្រភេទ៖ {request.genre})\\n"
                f"កំណត់ចំណាំ៖ {request.notes}\\n\\n"
                f"ភារកិច្ច៖ {item['instruction']}\\n"
                f"សូមបន្តសរសេរដោយលម្អិតឈុតឆាក មានសញ្ញាសម្គាល់ [ឈុតឆាក] និង [សំឡេង] ឱ្យបានច្បាស់លាស់។"
            )
            
            act_text = ""
            if chat:
                try:
                    response = await asyncio.wait_for(
                        asyncio.to_thread(chat.send_message, prompt),
                        timeout=7.0
                    )
                    act_text = response.text if hasattr(response, 'text') and response.text else generate_fallback_act(request.movie_title, request.genre, stage_name, request.notes)
                except Exception as api_err:
                    print(f"Gemini API warning ({stage_name}): {api_err}, using cinematic fallback")
                    act_text = generate_fallback_act(request.movie_title, request.genre, stage_name, request.notes)
            else:
                act_text = generate_fallback_act(request.movie_title, request.genre, stage_name, request.notes)

            full_script += f"\\n\\n## {stage_name}\\n\\n" + act_text

        # រក្សាទុក Script ជាឯកសារ .txt
        script_filename = f"{task_id}_script.txt"
        script_path = os.path.join(STORAGE_DIR, script_filename)
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(full_script)

        # ដំណាក់កាលបម្លែងទៅជាសំឡេងខ្មែរ (Khmer Text-to-Speech)
        task_db[task_id]["status"] = "generating_audio"
        task_db[task_id]["stage"] = "កំពុងបម្លែងជាសំឡេងអានខ្មែរ (Edge TTS)..."
        task_db[task_id]["progress"] = 75

        audio_filename = f"{task_id}_audio.mp3"
        audio_path = os.path.join(STORAGE_DIR, audio_filename)

        # កាត់ចេញនូវសញ្ញាសម្គាល់ [ឈុតឆាក] និង Markdown formatting មុននឹងឱ្យ TTS អាន ដើម្បីឱ្យសំឡេងពិរោះរលូន
        clean_text_for_speech = re.sub(r'\[ឈុតឆាក[^\]]*\]', '', full_script)
        clean_text_for_speech = re.sub(r'\[សំឡេង[^\]]*\]', '', clean_text_for_speech)
        clean_text_for_speech = re.sub(r'\[[^\]]+\]', '', clean_text_for_speech)
        clean_text_for_speech = clean_text_for_speech.replace("#", "").replace("*", "").replace("- ", "")
        clean_text_for_speech = re.sub(r'\n{2,}', '\n', clean_text_for_speech).strip()

        # ប្រសិនបើអត្ថបទវែងពេក កាត់មកត្រឹមសមស្របសម្រាប់ sample voiceover
        speech_sample = clean_text_for_speech[:1500] if len(clean_text_for_speech) > 1500 else clean_text_for_speech
        
        selected_voice = request.voice
        if selected_voice in voice_cloner.profiles or selected_voice.startswith("voice_"):
            task_db[task_id]["stage"] = f"កំពុងបម្លែងជាសំឡេងមនុស្សពិតបាន Clone ({selected_voice})..."
            try:
                await voice_cloner.synthesize_with_cloned_voice(speech_sample, selected_voice, audio_path)
            except Exception as clone_err:
                print(f"Voice clone error: {clone_err}, fallback to Edge TTS")
                fallback_v = resolve_khmer_voice("km-KH-PisethNeural")
                communicate = edge_tts.Communicate(speech_sample, fallback_v)
                await asyncio.wait_for(communicate.save(audio_path), timeout=25.0)
        else:
            selected_voice = resolve_khmer_voice(request.voice)
            try:
                communicate = edge_tts.Communicate(speech_sample, selected_voice)
                await asyncio.wait_for(communicate.save(audio_path), timeout=25.0)
            except Exception as tts_err:
                print(f"Edge TTS error: {tts_err}")

        # បញ្ចប់ Task
        task_db[task_id]["status"] = "completed"
        task_db[task_id]["progress"] = 100
        task_db[task_id]["stage"] = "រួចរាល់ជាស្ថាពរ"
        task_db[task_id]["result"] = {
            "script_url": f"/files/{script_filename}",
            "audio_url": f"/files/{audio_filename}",
            "word_count": len(full_script.split()),
            "voice_used": selected_voice,
            "characters_count": len(full_script),
            "script_content": full_script,
        }

    except Exception as e:
        task_db[task_id]["status"] = "failed"
        task_db[task_id]["error"] = str(e)
        task_db[task_id]["stage"] = f"មានបញ្ហាក្នុងដំណើរការ: {str(e)[:100]}"

# --- API Endpoints សម្រាប់ Mobile App & Web App ហៅប្រើ ---

@app.post("/api/recap/generate")
async def generate_recap(request: RecapRequest, background_tasks: BackgroundTasks):
    """Mobile App / Web App ចុចបញ្ជាបង្កើត Script សម្រាយរឿង"""
    if request.use_cloned_voice and request.cloned_voice_id:
        request.voice = request.cloned_voice_id

    task_id = str(uuid.uuid4())[:8]
    
    task_db[task_id] = {
        "task_id": task_id,
        "movie_title": request.movie_title,
        "status": "pending",
        "progress": 5,
        "stage": "កំពុងរៀបចំប្រព័ន្ធ...",
        "result": None,
        "error": None
    }
    
    # បញ្ជូនការងារឱ្យធ្វើនៅ Background
    background_tasks.add_task(process_recap_pipeline, task_id, request)
    
    return {
        "success": True,
        "task_id": task_id,
        "message": "Task ត្រូវបានបង្កើតជោគជ័យ។ សូមពិនិត្យ Progress តាមរយៈ task_id"
    }

@app.get("/api/recap/status/{task_id}")
async def check_task_status(task_id: str):
    """Mobile App ឆែកមើល Progress Bar រៀងរាល់ ២ ឬ ៣ វិនាទីម្តង"""
    task = task_db.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="រកមិនឃើញ Task ID នេះឡើយ")
    return task

@app.get("/api/recap/voices")
async def get_voices():
    """បញ្ជីសំឡេង Edge TTS ខ្មែរ ព្រមទាំង Cloned Voices (AI Voice Profiles)"""
    standard_voices = [
        {
            "id": "km-KH-PisethNeural",
            "name": "សំឡេងប្រុស (Piseth Neural)",
            "gender": "male",
            "type": "neural",
            "description": "សំឡេងបុរសខ្មែរ មុតមាំ ជក់ចិត្ត សក្តិសមបំផុតសម្រាប់រឿង Action & Horror",
            "recommended": True
        },
        {
            "id": "km-KH-SreymomNeural",
            "name": "សំឡេងស្រី (Sreymom Neural)",
            "gender": "female",
            "type": "neural",
            "description": "សំឡេងស្ត្រីខ្មែរ ស្រទន់ រំជួលចិត្ត សក្តិសមសម្រាប់រឿង Drama, Romance & Mystery",
            "recommended": False
        }
    ]
    
    cloned_profiles = voice_cloner.get_profiles()
    for cp in cloned_profiles:
        standard_voices.append({
            "id": cp["id"],
            "name": f"🎙️ {cp['name']} (Cloned AI)",
            "gender": cp.get("gender", "male"),
            "type": "cloned",
            "description": cp.get("description", "Zero-Shot Cloned Voice Profile"),
            "sample_url": cp.get("sample_url"),
            "similarity": cp.get("similarity", "98%"),
            "recommended": True
        })
        
    return standard_voices

# --- Voice Cloning Engine Endpoints ---

@app.get("/api/recap/clone-voice/profiles")
async def list_cloned_voice_profiles():
    """ទាញយកបញ្ជី Cloned Voice Profiles ទាំងអស់"""
    return {
        "success": True,
        "count": len(voice_cloner.get_profiles()),
        "profiles": voice_cloner.get_profiles()
    }

@app.post("/api/recap/clone-voice/upload")
async def upload_clone_voice_sample(
    file: UploadFile = File(...),
    profile_name: str = Form("សំឡេងមនុស្សពិត Clone"),
    gender: str = Form("male"),
    description: str = Form("")
):
    """Upload ឯកសារសំឡេងគំរូ (10s - 30s) កាត់ Noise (FFmpeg Denoise) និងបង្កើត Voice Profile ថ្មី"""
    temp_filename = f"temp_upload_{uuid.uuid4().hex[:8]}_{file.filename}"
    temp_path = os.path.join(STORAGE_DIR, temp_filename)
    
    try:
        content = await file.read()
        with open(temp_path, "wb") as f:
            f.write(content)
            
        profile_id = voice_cloner.process_and_clean_sample(
            input_audio_path=temp_path,
            profile_name=profile_name,
            gender=gender,
            description=description
        )
        
        # លុបឯកសារ Temp ដើម
        if os.path.exists(temp_path):
            os.remove(temp_path)
            
        profile = voice_cloner.get_profile(profile_id)
        return {
            "success": True,
            "message": f"បានបង្កើត Voice Profile [{profile_name}] ជោគជ័យ!",
            "profile": profile
        }
    except Exception as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise HTTPException(status_code=500, detail=f"បរាជ័យក្នុងការ Processing សំឡេង៖ {str(e)}")

@app.delete("/api/recap/clone-voice/profiles/{profile_id}")
async def delete_cloned_profile(profile_id: str):
    """លុប Voice Profile"""
    success = voice_cloner.delete_profile(profile_id)
    if not success:
        raise HTTPException(status_code=404, detail="រកមិនឃើញ Voice Profile នេះឡើយ")
    return {"success": True, "message": "បានលុប Voice Profile រួចរាល់"}

class SynthesizeRequest(BaseModel):
    text: str
    profile_id: str

@app.post("/api/recap/clone-voice/synthesize")
async def test_synthesize_cloned_voice(req: SynthesizeRequest):
    """សាកល្បងបម្លែងអត្ថបទខ្មែរទៅជាសំឡេងមនុស្សពិតបាន Clone"""
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="សូមបញ្ចូលអត្ថបទខ្មែរ")
        
    output_filename = f"test_synth_{uuid.uuid4().hex[:8]}.mp3"
    output_path = os.path.join(STORAGE_DIR, output_filename)
    
    try:
        await voice_cloner.synthesize_with_cloned_voice(req.text, req.profile_id, output_path)
        return {
            "success": True,
            "audio_url": f"/files/{output_filename}",
            "text_length": len(req.text),
            "profile_id": req.profile_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"បរាជ័យក្នុងការសំយោគសំឡេង៖ {str(e)}")

@app.get("/api/recap/tasks")
async def list_recent_tasks():
    """បញ្ជី Task សម្រាយរឿងទាំងអស់ដែលបានបង្កើត"""
    tasks_list = list(task_db.values())
    return {
        "total": len(tasks_list),
        "tasks": sorted(tasks_list, key=lambda t: t.get("task_id", ""), reverse=True)
    }

@app.get("/api/recap/sample")
async def get_sample_recap():
    """ផ្តល់ទិន្នន័យគំរូ Recap សម្រាប់សាកល្បងលើ Flutter App ភ្លាមៗ"""
    return {
        "movie_title": "Train to Busan (រថភ្លើងទៅកាន់ប៊ូសាន)",
        "genre": "ភ័យរន្ធត់ / ហ្ស៊ំប៊ី (Horror)",
        "voice": "km-KH-PisethNeural",
        "sample_video_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "summary": "ដំណើររត់គេចខ្លួនដ៏តានតឹងនៅលើរថភ្លើងល្បឿនលឿនពីទីក្រុងសេអ៊ូលទៅកាន់ទីក្រុងប៊ូសាន ខណៈមេរោគហ្ស៊ំប៊ីរីករាលដាលពេញប្រទេសកូរ៉េ។"
    }

@app.get("/")
def root():
    return {
        "message": "Movie Recap AI API is running!",
        "version": "1.0.0",
        "endpoints": {
            "generate": "POST /api/recap/generate",
            "status": "GET /api/recap/status/{task_id}",
            "voices": "GET /api/recap/voices",
            "tasks": "GET /api/recap/tasks",
            "sample": "GET /api/recap/sample",
            "docs": "/docs",
            "files": "/files/{filename}"
        }
    }

def find_available_port(default_port: int = 8000) -> int:
    import socket
    for port in [default_port, 8001, 8081, 5000, 8888, 9000]:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', port)) != 0:
                return port
    return default_port

if __name__ == "__main__":
    import uvicorn
    # ពិនិត្យ Port ដែលអាចប្រើបាន (ប្រសិនបើ port 8000 មាន process ផ្សេង នឹងប្រើ port 8001)
    target_port = int(os.getenv("PORT", find_available_port(8000)))
    print(f"🚀 កំពុងដំណើរការ FastAPI Movie Recap Server លើ Port {target_port}...")
    uvicorn.run("main:app", host="0.0.0.0", port=target_port, reload=False)
