export interface Beat {
  id: string;
  beatNumber: number;
  title: string;
  timestamp: string; // e.g. "00:00 - 01:15"
  sceneDescription: string; // [ឈុតឆាក] Visuals, camera angles, lighting, character positions
  audioCue: string; // [សំឡេងបន្លឺ] SFX, BGM, ambiance, sudden thuds
  narration: string; // [ពន្យល់សាច់រឿង] Narrative voiceover in engaging Khmer
  characterEmotion: string; // [អារម្មណ៍តួអង្គ] Fear, shock, adrenaline, breathlessness
  directorNotes?: string; // [កំណត់សម្គាល់កាត់ត] Zoom, slow motion, whip pan, color grading cue
}

export interface RecapScript {
  id: string;
  title: string;
  genre: string;
  synopsis: string;
  tone: string;
  pacing: string;
  estimatedDuration: string;
  hookOpening: string; // [ពាក្យបើកឆាកទាក់ទាញ]
  beats: Beat[];
  outroCallToAction: string; // [ពាក្យបញ្ចប់រឿង]
  createdAt: number;
  updatedAt: number;
}

export type ViewTab = 'editor' | 'teleprompter' | 'flutter-app' | 'soundboard' | 'export';
