import React, { useState, useEffect } from 'react';
import {
  Film,
  Sparkles,
  Layers,
  Plus,
  Play,
  RotateCcw,
  Sliders,
  Tv,
  Music2,
  Download,
  AlertCircle,
  Loader2,
  FileText,
  Clock,
  Send,
  Video,
  Volume2,
  Mic,
  HeartPulse,
} from 'lucide-react';
import { RecapScript, Beat, ViewTab } from './types/script';
import { SAMPLE_SCRIPTS } from './data/sampleScripts';
import { Header } from './components/Header';
import { BeatCard } from './components/BeatCard';
import { TeleprompterView } from './components/TeleprompterView';
import { SoundboardDrawer } from './components/SoundboardDrawer';
import { ExportModal } from './components/ExportModal';
import { ScriptGeneratorModal } from './components/ScriptGeneratorModal';
import { ScriptSelectorModal } from './components/ScriptSelectorModal';
import { EdgeTtsModal } from './components/EdgeTtsModal';
import { VoiceCloningModal } from './components/VoiceCloningModal';
import { FlutterAppView } from './components/FlutterAppView';
import { calculateKhmerWordStats } from './utils/exportHelpers';

export default function App() {
  // Load scripts from localStorage or default to SAMPLE_SCRIPTS
  const [scripts, setScripts] = useState<RecapScript[]>(() => {
    try {
      const saved = localStorage.getItem('khmer_recap_scripts');
      if (saved) {
        const parsed: RecapScript[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // If the new Master Edition isn't in parsed scripts, merge latest official scripts
          const hasMaster = parsed.some((s) => s.id === 'script-train-to-busan-master');
          if (!hasMaster) {
            const existingIds = new Set(parsed.map((s) => s.id));
            const newSamples = SAMPLE_SCRIPTS.filter((s) => !existingIds.has(s.id));
            return [...SAMPLE_SCRIPTS, ...parsed.filter((p) => !SAMPLE_SCRIPTS.some((s) => s.id === p.id))];
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return SAMPLE_SCRIPTS;
  });

  const [currentScriptId, setCurrentScriptId] = useState<string>(
    () => scripts[0]?.id || SAMPLE_SCRIPTS[0].id
  );

  const [activeTab, setActiveTab] = useState<ViewTab>('editor');
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [isSelectorOpen, setIsSelectorOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isEdgeTtsOpen, setIsEdgeTtsOpen] = useState(false);
  const [isVoiceCloningOpen, setIsVoiceCloningOpen] = useState(false);

  // AI Continue state
  const [isContinuing, setIsContinuing] = useState(false);
  const [continueDirection, setContinueDirection] = useState('');
  const [showContinueInput, setShowContinueInput] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('khmer_recap_scripts', JSON.stringify(scripts));
    } catch (e) {
      console.error(e);
    }
  }, [scripts]);

  const currentScript =
    scripts.find((s) => s.id === currentScriptId) || scripts[0] || SAMPLE_SCRIPTS[0];

  const updateCurrentScript = (updated: RecapScript) => {
    setScripts((prev) =>
      prev.map((s) => (s.id === updated.id ? { ...updated, updatedAt: Date.now() } : s))
    );
  };

  const handleUpdateBeat = (updatedBeat: Beat) => {
    const newBeats = currentScript.beats.map((b) =>
      b.id === updatedBeat.id ? updatedBeat : b
    );
    updateCurrentScript({ ...currentScript, beats: newBeats });
  };

  const handleDeleteBeat = (beatId: string) => {
    if (currentScript.beats.length <= 1) {
      alert('Script ត្រូវតែមានឈុតឆាកយ៉ាងហោចណាស់មួយ!');
      return;
    }
    const newBeats = currentScript.beats
      .filter((b) => b.id !== beatId)
      .map((b, idx) => ({ ...b, beatNumber: idx + 1 }));
    updateCurrentScript({ ...currentScript, beats: newBeats });
  };

  const handleMoveBeatUp = (beatId: string) => {
    const idx = currentScript.beats.findIndex((b) => b.id === beatId);
    if (idx <= 0) return;
    const newBeats = [...currentScript.beats];
    const temp = newBeats[idx];
    newBeats[idx] = newBeats[idx - 1];
    newBeats[idx - 1] = temp;
    updateCurrentScript({
      ...currentScript,
      beats: newBeats.map((b, i) => ({ ...b, beatNumber: i + 1 })),
    });
  };

  const handleMoveBeatDown = (beatId: string) => {
    const idx = currentScript.beats.findIndex((b) => b.id === beatId);
    if (idx < 0 || idx >= currentScript.beats.length - 1) return;
    const newBeats = [...currentScript.beats];
    const temp = newBeats[idx];
    newBeats[idx] = newBeats[idx + 1];
    newBeats[idx + 1] = temp;
    updateCurrentScript({
      ...currentScript,
      beats: newBeats.map((b, i) => ({ ...b, beatNumber: i + 1 })),
    });
  };

  const handleAddManualBeat = () => {
    const nextNum = currentScript.beats.length + 1;
    const newBeat: Beat = {
      id: `beat-${Date.now()}`,
      beatNumber: nextNum,
      title: `ឈុតឆាកទី ${nextNum}`,
      timestamp: `0${nextNum}:00 - 0${nextNum}:45`,
      sceneDescription: 'រៀបរាប់ពីរូបភាព ប្លង់កាមេរ៉ា និងកាយវិការតួអង្គ...',
      audioCue: 'សំឡេងបែបផែន SFX ឬភ្លេង BGM...',
      narration: 'ពាក្យសម្រាយរឿងខ្មែររបស់អ្នកអានសំឡេង...',
      characterEmotion: 'អារម្មណ៍តួអង្គ ភ័យខ្លាច ឬរំភើប...',
      directorNotes: 'បច្ចេកទេសកាត់ត...',
    };
    updateCurrentScript({
      ...currentScript,
      beats: [...currentScript.beats, newBeat],
    });
  };

  // AI Continue Script
  const handleContinueWithAi = async () => {
    setIsContinuing(true);
    try {
      const res = await fetch('/api/continue-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: currentScript.title,
          existingBeats: currentScript.beats,
          direction: continueDirection,
        }),
      });

      if (!res.ok) throw new Error('បរាជ័យក្នុងការបន្តឈុតឆាក');
      const data = await res.json();
      if (Array.isArray(data.newBeats) && data.newBeats.length > 0) {
        updateCurrentScript({
          ...currentScript,
          beats: [...currentScript.beats, ...data.newBeats],
        });
        setContinueDirection('');
        setShowContinueInput(false);
      }
    } catch (err: any) {
      alert(err.message || 'កំហុសបច្ចេកទេស');
    } finally {
      setIsContinuing(false);
    }
  };

  const handleScriptGenerated = (newScript: RecapScript) => {
    setScripts((prev) => [newScript, ...prev]);
    setCurrentScriptId(newScript.id);
    setActiveTab('editor');
  };

  const handleImportScriptFromFlutter = (importedScript: RecapScript) => {
    setScripts((prev) => [importedScript, ...prev.filter((s) => s.id !== importedScript.id)]);
    setCurrentScriptId(importedScript.id);
    setActiveTab('editor');
  };

  const handleDeleteScript = (id: string) => {
    const remaining = scripts.filter((s) => s.id !== id);
    setScripts(remaining);
    if (currentScriptId === id) {
      setCurrentScriptId(remaining[0]?.id || SAMPLE_SCRIPTS[0].id);
    }
  };

  const handleResetOfficialScripts = () => {
    const customScripts = scripts.filter(
      (s) => s.id.startsWith('custom-') || !SAMPLE_SCRIPTS.some((sample) => sample.id === s.id)
    );
    const merged = [...SAMPLE_SCRIPTS, ...customScripts];
    setScripts(merged);
    setCurrentScriptId(SAMPLE_SCRIPTS[0].id);
  };

  const stats = calculateKhmerWordStats(currentScript);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Global Studio Header */}
      <Header
        currentScript={currentScript}
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === 'export') {
            setIsExportOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenGenerator={() => setIsGeneratorOpen(true)}
        onOpenScriptSelector={() => setIsSelectorOpen(true)}
        onOpenEdgeTts={() => setIsEdgeTtsOpen(true)}
        onOpenVoiceCloning={() => setIsVoiceCloningOpen(true)}
      />

      {/* Main Tab Views */}
      <main className="flex-1 flex flex-col">
        {/* TAB 1: SCRIPT EDITOR & BEAT-BY-BEAT STUDIO */}
        {activeTab === 'editor' && (
          <div className="max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            {/* Script Overview Banner */}
            <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-slate-900/90 to-amber-950/30 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                      {currentScript.genre}
                    </span>
                    <span className="text-xs text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-full">
                      ចង្វាក់: {currentScript.pacing.split('(')[0]}
                    </span>
                    <span className="text-xs text-rose-300 bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-500/20">
                      សម្លេង: {currentScript.tone.split('(')[0]}
                    </span>
                  </div>
                  <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-slate-100 tracking-tight">
                    {currentScript.title}
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
                    {currentScript.synopsis}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
                  <button
                    onClick={() => setActiveTab('teleprompter')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
                  >
                    <Tv className="w-4 h-4" />
                    <span>បើកផ្ទាំងអាន Teleprompter</span>
                  </button>
                </div>
              </div>

              {/* Hook Opening Preview Card */}
              {currentScript.hookOpening && (
                <div className="mt-6 bg-slate-950/70 border border-amber-500/30 rounded-2xl p-4">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>[ពាក្យបើកឆាកទាក់ទាញ - HOOK OPENING]</span>
                  </div>
                  <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed font-medium">
                    {currentScript.hookOpening}
                  </p>
                </div>
              )}
            </div>

            {/* Directive Legend Bar */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
              <span className="font-semibold text-slate-300">
                សញ្ញាសម្គាល់កាត់ត & អានសំឡេង៖
              </span>
              <div className="flex flex-wrap items-center gap-3">
                <span className="flex items-center gap-1.5 text-cyan-400 bg-cyan-950/40 px-2 py-1 rounded-md border border-cyan-500/20">
                  <Video className="w-3 h-3" /> [ឈុតឆាក]: រូបភាព/ប្លង់
                </span>
                <span className="flex items-center gap-1.5 text-amber-400 bg-amber-950/40 px-2 py-1 rounded-md border border-amber-500/20">
                  <Volume2 className="w-3 h-3" /> [សំឡេងបន្លឺ]: SFX/ភ្លេង
                </span>
                <span className="flex items-center gap-1.5 text-emerald-400 bg-emerald-950/40 px-2 py-1 rounded-md border border-emerald-500/20">
                  <Mic className="w-3 h-3" /> [ពន្យល់សាច់រឿង]: ពាក្យអាន
                </span>
                <span className="flex items-center gap-1.5 text-rose-400 bg-rose-950/40 px-2 py-1 rounded-md border border-rose-500/20">
                  <HeartPulse className="w-3 h-3" /> [អារម្មណ៍តួអង្គ]: កាយវិការ
                </span>
              </div>
            </div>

            {/* Beats List */}
            <div className="space-y-4">
              {currentScript.beats.map((beat, idx) => (
                <BeatCard
                  key={beat.id}
                  beat={beat}
                  isFirst={idx === 0}
                  isLast={idx === currentScript.beats.length - 1}
                  onUpdateBeat={handleUpdateBeat}
                  onDeleteBeat={handleDeleteBeat}
                  onMoveUp={handleMoveBeatUp}
                  onMoveDown={handleMoveBeatDown}
                />
              ))}
            </div>

            {/* Outro Call To Action Box */}
            {currentScript.outroCallToAction && (
              <div className="bg-slate-900/80 border border-indigo-500/30 rounded-2xl p-5">
                <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-1.5">
                  [ពាក្យបញ្ចប់រឿង - OUTRO CALL TO ACTION]
                </div>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                  {currentScript.outroCallToAction}
                </p>
              </div>
            )}

            {/* Bottom Actions: Add Beat & AI Continue */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="font-bold text-sm text-slate-200">
                  បន្ថែមឈុតឆាកទៅក្នុង Script
                </h3>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleAddManualBeat}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all border border-slate-700"
                  >
                    <Plus className="w-4 h-4 text-emerald-400" />
                    <span>បន្ថែមឈុតដោយដៃ (Add Beat)</span>
                  </button>

                  <button
                    onClick={() => setShowContinueInput(!showContinueInput)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 transition-all shadow-md shadow-amber-500/20"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>បន្តសាច់រឿងដោយ AI</span>
                  </button>
                </div>
              </div>

              {/* AI Continue Input Drawer */}
              {showContinueInput && (
                <div className="pt-4 border-t border-slate-800/80 space-y-3 animate-in fade-in duration-150">
                  <label className="block text-xs font-semibold text-slate-300">
                    ទិសដៅរបត់សាច់រឿងបន្តបន្ទាប់ (Plot Twist / Next Events):
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={continueDirection}
                      onChange={(e) => setContinueDirection(e.target.value)}
                      placeholder="ឧ. ស្រាប់តែមានតួអង្គចម្លែកលេចខ្លួនមកជួយ ឬរកឃើញច្រកសម្ងាត់កប់ក្រោមដី..."
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500"
                    />
                    <button
                      onClick={handleContinueWithAi}
                      disabled={isContinuing}
                      className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 disabled:opacity-40 shrink-0"
                    >
                      {isContinuing ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      <span>បង្កើត 3 ឈុតបន្ទាប់</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: TELEPROMPTER VIEW */}
        {activeTab === 'teleprompter' && <TeleprompterView script={currentScript} />}

        {/* TAB 3: FLUTTER MOBILE APP CLIENT */}
        {activeTab === 'flutter-app' && (
          <FlutterAppView onLoadScriptToEditor={handleImportScriptFromFlutter} />
        )}

        {/* TAB 4: SOUNDBOARD DRAWER */}
        {activeTab === 'soundboard' && (
          <div className="max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
            <SoundboardDrawer />
          </div>
        )}
      </main>

      {/* Modals */}
      <ScriptGeneratorModal
        isOpen={isGeneratorOpen}
        onClose={() => setIsGeneratorOpen(false)}
        onScriptGenerated={handleScriptGenerated}
      />

      <ScriptSelectorModal
        isOpen={isSelectorOpen}
        onClose={() => setIsSelectorOpen(false)}
        scripts={scripts}
        currentScriptId={currentScript.id}
        onSelectScript={(s) => setCurrentScriptId(s.id)}
        onDeleteScript={handleDeleteScript}
        onNewScript={() => {
          setIsGeneratorOpen(true);
        }}
        onResetOfficialScripts={handleResetOfficialScripts}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        script={currentScript}
      />

      <EdgeTtsModal
        isOpen={isEdgeTtsOpen}
        onClose={() => setIsEdgeTtsOpen(false)}
        script={currentScript}
      />

      <VoiceCloningModal
        isOpen={isVoiceCloningOpen}
        onClose={() => setIsVoiceCloningOpen(false)}
      />
    </div>
  );
}
