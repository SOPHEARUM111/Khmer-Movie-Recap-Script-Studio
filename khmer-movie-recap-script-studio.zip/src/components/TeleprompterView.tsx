import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  Type,
  Eye,
  EyeOff,
  FlipHorizontal,
  Clock,
  Volume2,
} from 'lucide-react';
import { RecapScript } from '../types/script';

interface TeleprompterViewProps {
  script: RecapScript;
}

export const TeleprompterView: React.FC<TeleprompterViewProps> = ({ script }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [scrollSpeed, setScrollSpeed] = useState(1.2); // px per animation frame
  const [fontSize, setFontSize] = useState<number>(28); // in px
  const [showDirectives, setShowDirectives] = useState(true); // show/hide scene & audio cues
  const [isMirrored, setIsMirrored] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [activeBeatIndex, setActiveBeatIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const scrollAnimRef = useRef<number | null>(null);

  // Timer while playing
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setElapsedTime((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Teleprompter smooth auto-scroll loop
  useEffect(() => {
    if (!isPlaying) {
      if (scrollAnimRef.current) cancelAnimationFrame(scrollAnimRef.current);
      return;
    }

    const scrollLoop = () => {
      if (containerRef.current) {
        containerRef.current.scrollTop += scrollSpeed;

        // Check if reached bottom
        const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
        if (scrollTop + clientHeight >= scrollHeight - 10) {
          setIsPlaying(false);
          return;
        }
      }
      scrollAnimRef.current = requestAnimationFrame(scrollLoop);
    };

    scrollAnimRef.current = requestAnimationFrame(scrollLoop);
    return () => {
      if (scrollAnimRef.current) cancelAnimationFrame(scrollAnimRef.current);
    };
  }, [isPlaying, scrollSpeed]);

  // Keyboard shortcut: Spacebar toggles play/pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && (e.target as HTMLElement).tagName !== 'INPUT') {
        e.preventDefault();
        setIsPlaying((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleReset = () => {
    setIsPlaying(false);
    setElapsedTime(0);
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(remainingSecs).padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4.5rem)] bg-slate-950 text-slate-100 select-none">
      {/* Teleprompter Control Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0 z-20">
        <div className="flex items-center gap-3">
          {/* Play/Pause */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`flex items-center gap-2 px-5 py-2 rounded-xl font-bold text-sm transition-all shadow-md ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>ផ្អាក (Pause)</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>ចាប់ផ្តើមអាន (Play)</span>
              </>
            )}
          </button>

          {/* Reset */}
          <button
            onClick={handleReset}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
            title="ត្រឡប់ទៅដើមវិញ"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Timer */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 font-mono text-sm text-amber-400 font-bold">
            <Clock className="w-4 h-4 text-slate-400" />
            <span>{formatTimer(elapsedTime)}</span>
          </div>
        </div>

        {/* Speed & Settings Controls */}
        <div className="flex items-center gap-4 flex-wrap text-xs text-slate-300">
          {/* Speed slider */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">ល្បឿន:</span>
            <input
              type="range"
              min="0.4"
              max="3.5"
              step="0.1"
              value={scrollSpeed}
              onChange={(e) => setScrollSpeed(parseFloat(e.target.value))}
              className="w-24 accent-amber-500 cursor-pointer"
            />
            <span className="font-mono text-amber-400 w-8 text-right">
              {scrollSpeed.toFixed(1)}x
            </span>
          </div>

          {/* Font size */}
          <div className="flex items-center gap-1.5 border-l border-slate-800 pl-3">
            <span className="text-slate-400 font-medium">ទំហំអក្សរ:</span>
            <button
              onClick={() => setFontSize((f) => Math.max(20, f - 2))}
              className="w-7 h-7 rounded bg-slate-800 hover:bg-slate-700 font-bold"
              title="បង្រួមអក្សរ"
            >
              A-
            </button>
            <span className="font-mono text-slate-200 w-6 text-center text-xs">
              {fontSize}
            </span>
            <button
              onClick={() => setFontSize((f) => Math.min(52, f + 2))}
              className="w-7 h-7 rounded bg-slate-800 hover:bg-slate-700 font-bold"
              title="ពង្រីកអក្សរ"
            >
              A+
            </button>
          </div>

          {/* Show/Hide cues */}
          <button
            onClick={() => setShowDirectives(!showDirectives)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
              showDirectives
                ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
            title="បង្ហាញ ឬលាក់សញ្ញាសម្គាល់ [ឈុតឆាក] និង [សំឡេងបន្លឺ]"
          >
            {showDirectives ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>{showDirectives ? 'បង្ហាញសញ្ញា [Cues]' : 'លាក់សញ្ញា [Cues]'}</span>
          </button>

          {/* Mirror toggle for teleprompter glass */}
          <button
            onClick={() => setIsMirrored(!isMirrored)}
            className={`p-2 rounded-lg border transition-all ${
              isMirrored
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
            title="បង្វិលកញ្ចក់ Mirror (សម្រាប់ hardware teleprompter)"
          >
            <FlipHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Prompter Reader Area */}
      <div
        ref={containerRef}
        className={`flex-1 overflow-y-auto px-6 sm:px-12 md:px-24 lg:px-44 py-16 transition-all ${
          isMirrored ? 'scale-x-[-1]' : ''
        }`}
        style={{ scrollBehavior: 'auto' }}
      >
        <div className="max-w-4xl mx-auto space-y-16">
          {/* Title Header */}
          <div className="text-center border-b border-slate-800 pb-8">
            <span className="text-xs uppercase font-bold tracking-widest text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
              {script.genre}
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 mt-4 mb-2">
              {script.title}
            </h1>
            <p className="text-sm text-slate-400 max-w-lg mx-auto">
              {script.synopsis}
            </p>
          </div>

          {/* Hook Opening */}
          {script.hookOpening && (
            <div className="bg-amber-500/10 border-l-4 border-amber-500 rounded-r-2xl p-6">
              {showDirectives && (
                <div className="text-amber-400 font-bold text-xs uppercase tracking-wider mb-2">
                  [ពាក្យបើកឆាកទាក់ទាញ - HOOK]
                </div>
              )}
              <p
                className="text-amber-100 font-semibold leading-relaxed"
                style={{ fontSize: `${fontSize}px` }}
              >
                {script.hookOpening}
              </p>
            </div>
          )}

          {/* Beats */}
          {script.beats.map((beat) => (
            <div
              key={beat.id}
              className="space-y-4 pt-4 border-t border-slate-800/60 transition-all hover:opacity-100"
            >
              {showDirectives && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="bg-amber-500 text-slate-950 font-bold text-xs px-2.5 py-0.5 rounded-md">
                    ឈុតទី {beat.beatNumber}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    [{beat.timestamp}]
                  </span>
                  <span className="text-xs font-semibold text-slate-300">
                    {beat.title}
                  </span>
                </div>
              )}

              {/* Scene & Sound Directives */}
              {showDirectives && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-900/60 p-2.5 rounded-xl border border-cyan-500/20 text-cyan-300">
                    <span className="font-bold block mb-0.5">[ឈុតឆាក]:</span>
                    <span className="text-slate-300">{beat.sceneDescription}</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-xl border border-amber-500/20 text-amber-300">
                    <span className="font-bold block mb-0.5">[សំឡេងបន្លឺ]:</span>
                    <span className="text-amber-200/90 font-mono">{beat.audioCue}</span>
                  </div>
                </div>
              )}

              {/* The Actual Voiceover Text (Prompter Focus) */}
              <div className="py-2">
                {showDirectives && (
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                    [ពន្យល់សាច់រឿង - សម្រាយ]:
                  </span>
                )}
                <p
                  className="font-medium text-slate-100 leading-loose tracking-wide selection:bg-amber-500/40"
                  style={{
                    fontSize: `${fontSize}px`,
                    lineHeight: '1.9',
                  }}
                >
                  {beat.narration}
                </p>
              </div>

              {/* Character Emotion Guide */}
              {showDirectives && (
                <div className="text-xs text-rose-300/80 italic bg-rose-950/20 px-3 py-1.5 rounded-lg border border-rose-500/10">
                  <span className="font-bold">[អារម្មណ៍តួអង្គ]: </span>
                  {beat.characterEmotion}
                </div>
              )}
            </div>
          ))}

          {/* Outro Call To Action */}
          {script.outroCallToAction && (
            <div className="bg-indigo-500/10 border-l-4 border-indigo-500 rounded-r-2xl p-6 mt-12">
              {showDirectives && (
                <div className="text-indigo-400 font-bold text-xs uppercase tracking-wider mb-2">
                  [ពាក្យបញ្ចប់រឿង - OUTRO]
                </div>
              )}
              <p
                className="text-indigo-100 font-semibold leading-relaxed"
                style={{ fontSize: `${fontSize}px` }}
              >
                {script.outroCallToAction}
              </p>
            </div>
          )}

          {/* Bottom Buffer */}
          <div className="h-96 flex items-center justify-center text-slate-600 text-sm">
            --- ចប់ Script សម្រាយរឿង ---
          </div>
        </div>
      </div>
    </div>
  );
};
