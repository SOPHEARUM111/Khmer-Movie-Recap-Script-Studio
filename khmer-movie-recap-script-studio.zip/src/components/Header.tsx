import React from 'react';
import {
  Film,
  Sparkles,
  Tv,
  Music2,
  Download,
  Clock,
  Layers,
  FileText,
  Plus,
  Mic,
  Smartphone,
} from 'lucide-react';
import { RecapScript, ViewTab } from '../types/script';
import { calculateKhmerWordStats } from '../utils/exportHelpers';

interface HeaderProps {
  currentScript: RecapScript;
  activeTab: ViewTab;
  onTabChange: (tab: ViewTab) => void;
  onOpenGenerator: () => void;
  onOpenScriptSelector: () => void;
  onOpenEdgeTts?: () => void;
  onOpenVoiceCloning?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentScript,
  activeTab,
  onTabChange,
  onOpenGenerator,
  onOpenScriptSelector,
  onOpenEdgeTts,
  onOpenVoiceCloning,
}) => {
  const stats = calculateKhmerWordStats(currentScript);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Script Info */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center shadow-lg shadow-amber-500/20 shrink-0">
              <Film className="w-5 h-5 text-slate-950 font-bold" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
                  Movie Recap Studio
                </span>
                <span className="text-xs text-slate-400 hidden sm:inline">
                  • ស្ទូឌីយោសម្រាយរឿងខ្មែរ
                </span>
              </div>
              <button
                onClick={onOpenScriptSelector}
                className="text-left font-bold text-slate-100 hover:text-amber-400 text-sm sm:text-base truncate block max-w-[200px] sm:max-w-xs md:max-w-md transition-colors"
                title={currentScript.title}
              >
                {currentScript.title}
                <span className="text-xs text-slate-400 font-normal ml-2 underline">
                  (ប្តូររឿង)
                </span>
              </button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="hidden lg:flex items-center gap-4 text-xs text-slate-400 border-x border-slate-800/80 px-4">
            <div className="flex items-center gap-1.5" title="រយៈពេលអានប្រហាក់ប្រហែល">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>~{stats.estimatedMinutes} នាទី</span>
            </div>
            <div className="flex items-center gap-1.5" title="ចំនួនឈុតឆាក">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span>{stats.totalBeats} ឈុតឆាក</span>
            </div>
            <div className="flex items-center gap-1.5" title="ចំនួនពាក្យប្រហាក់ប្រហែល">
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>~{stats.estimatedWords.toLocaleString()} ពាក្យ</span>
            </div>
          </div>

          {/* Tab Navigation & Action */}
          <div className="flex items-center gap-2">
            <nav className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => onTabChange('editor')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'editor'
                    ? 'bg-amber-500 text-slate-950 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">កែសម្រួល</span>
                <span className="sm:hidden">Script</span>
              </button>

              <button
                onClick={() => onTabChange('teleprompter')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'teleprompter'
                    ? 'bg-amber-500 text-slate-950 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Tv className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">ផ្ទាំងអាន</span>
                <span className="sm:hidden">អាន</span>
              </button>

              <button
                onClick={() => onTabChange('flutter-app')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all relative ${
                  activeTab === 'flutter-app'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-sm font-semibold'
                    : 'text-cyan-400 hover:text-cyan-300 hover:bg-slate-800/60'
                }`}
                title="កម្មវិធីទូរស័ព្ទ Flutter (Mobile App Player & Generator)"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Flutter App</span>
                <span className="sm:hidden">App</span>
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse hidden md:inline" />
              </button>

              <button
                onClick={() => onTabChange('soundboard')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'soundboard'
                    ? 'bg-amber-500 text-slate-950 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Music2 className="w-3.5 h-3.5" />
                <span className="hidden md:inline">សំឡេង SFX</span>
                <span className="md:hidden">SFX</span>
              </button>

              <button
                onClick={() => onTabChange('export')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'export'
                    ? 'bg-amber-500 text-slate-950 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">នាំចេញ</span>
              </button>
            </nav>

            {/* AI Voice Cloning Button */}
            {onOpenVoiceCloning && (
              <button
                onClick={onOpenVoiceCloning}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
                title="ស្ទូឌីយោចម្លងសំឡេងមនុស្សពិត Zero-Shot Voice Cloning (F5-TTS/XTTS/ElevenLabs)"
              >
                <Mic className="w-3.5 h-3.5 text-purple-400" />
                <span className="hidden sm:inline">ចម្លងសំឡេង AI</span>
                <span className="sm:hidden">Clone</span>
              </button>
            )}

            {/* Edge TTS Studio Button */}
            {onOpenEdgeTts && (
              <button
                onClick={onOpenEdgeTts}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
                title="ផលិតសំឡេងខ្មែរ AI ជាមួយ Microsoft Edge TTS (Piseth & Sreymom)"
              >
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Edge TTS</span>
              </button>
            )}

            {/* Create Script with Gemini */}
            <button
              onClick={onOpenGenerator}
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-bold px-3 py-2 rounded-xl text-xs sm:text-sm shadow-md shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">បង្កើត Script ថ្មី</span>
              <span className="sm:hidden">ថ្មី</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
