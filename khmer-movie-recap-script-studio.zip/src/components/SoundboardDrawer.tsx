import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Play,
  Activity,
  Heart,
  TrendingUp,
  Zap,
  Radio,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { SFX_PRESETS } from '../utils/soundEffects';

export const SoundboardDrawer: React.FC = () => {
  const [activeSoundId, setActiveSoundId] = useState<string | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Activity':
        return <Activity className="w-5 h-5" />;
      case 'Heart':
        return <Heart className="w-5 h-5" />;
      case 'TrendingUp':
        return <TrendingUp className="w-5 h-5" />;
      case 'Zap':
        return <Zap className="w-5 h-5" />;
      case 'Radio':
        return <Radio className="w-5 h-5" />;
      default:
        return <Volume2 className="w-5 h-5" />;
    }
  };

  const handlePlaySound = (preset: typeof SFX_PRESETS[0]) => {
    setActiveSoundId(preset.id);
    preset.play();
    setTimeout(() => {
      setActiveSoundId(null);
    }, 1200);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-bold tracking-wider text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
              Audio Cue Soundboard
            </span>
            <span className="text-xs text-slate-400">• បន្ទះសំឡេងជំនួយកាត់ត</span>
          </div>
          <h2 className="text-lg font-bold text-slate-100 mt-1">
            សំឡេងបែបផែនភាពយន្ត [សំឡេងបន្លឺ] (Cinematic SFX)
          </h2>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>សំឡេងបង្កើតតាម Web Audio API ផ្ទាល់</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {SFX_PRESETS.map((preset) => {
          const isActive = activeSoundId === preset.id;
          return (
            <button
              key={preset.id}
              onClick={() => handlePlaySound(preset)}
              className={`group relative text-left p-4 rounded-xl border transition-all text-slate-100 active:scale-95 ${
                isActive
                  ? 'bg-amber-500/20 border-amber-500/50 shadow-lg shadow-amber-500/20'
                  : 'bg-slate-950/70 hover:bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div
                  className={`w-10 h-10 rounded-xl bg-gradient-to-br ${preset.color} flex items-center justify-center text-white shadow-md transition-transform group-hover:scale-105 ${
                    isActive ? 'animate-bounce' : ''
                  }`}
                >
                  {getIcon(preset.icon)}
                </div>
                <div className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800/80 text-amber-400">
                  <Play className="w-3 h-3 fill-current" />
                  <span>ចាក់</span>
                </div>
              </div>

              <div className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition-colors">
                {preset.nameKh}
              </div>
              <div className="text-xs text-slate-400 font-mono mb-1.5">
                {preset.name}
              </div>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {preset.description}
              </p>
            </button>
          );
        })}
      </div>

      {/* Director Sound Advice */}
      <div className="mt-6 bg-slate-950/80 rounded-xl p-4 border border-slate-800 text-xs text-slate-400 flex items-start gap-3">
        <Sliders className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-slate-200">
            បច្ចេកទេសបញ្ចូលសំឡេងសម្រាយរឿងខ្មែរអាជីព៖
          </span>{' '}
          ពេលដល់សញ្ញាសម្គាល់ <span className="text-amber-400 font-mono">[សំឡេងបន្លឺ]</span> ត្រូវបន្ថយសំឡេងភ្លេង BGM ចុះប្រហែល 30% ដើម្បីឱ្យសំឡេងបែបផែន (SFX) ឬសំឡេងបេះដូងបន្លឺឡើងច្បាស់កន្ត្រាក់អារម្មណ៍អ្នកស្តាប់!
        </div>
      </div>
    </div>
  );
};
