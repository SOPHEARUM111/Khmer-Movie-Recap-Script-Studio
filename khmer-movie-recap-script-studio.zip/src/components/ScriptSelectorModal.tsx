import React from 'react';
import { X, Film, Check, Plus, Trash2, Clock, Layers, RotateCcw } from 'lucide-react';
import { RecapScript } from '../types/script';

interface ScriptSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  scripts: RecapScript[];
  currentScriptId: string;
  onSelectScript: (script: RecapScript) => void;
  onDeleteScript: (id: string) => void;
  onNewScript: () => void;
  onResetOfficialScripts?: () => void;
}

export const ScriptSelectorModal: React.FC<ScriptSelectorModalProps> = ({
  isOpen,
  onClose,
  scripts,
  currentScriptId,
  onSelectScript,
  onDeleteScript,
  onNewScript,
  onResetOfficialScripts,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full flex flex-col max-h-[85vh] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">
              បណ្ណាល័យ Script សម្រាយរឿង (Script Library)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {scripts.map((item) => {
            const isSelected = item.id === currentScriptId;
            return (
              <div
                key={item.id}
                onClick={() => {
                  onSelectScript(item);
                  onClose();
                }}
                className={`group relative p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/40 shadow-md shadow-amber-500/10'
                    : 'bg-slate-950/60 hover:bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-amber-400">
                      {item.genre.split('(')[0]}
                    </span>
                    {isSelected && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        <Check className="w-3 h-3" />
                        <span>កំពុងបើក</span>
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-slate-100 text-sm group-hover:text-amber-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                    {item.synopsis || item.hookOpening}
                  </p>
                  <div className="flex items-center gap-4 text-[11px] text-slate-500 mt-2">
                    <span className="flex items-center gap-1">
                      <Layers className="w-3 h-3 text-indigo-400" />
                      {item.beats?.length || 0} ឈុតឆាក
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      {item.estimatedDuration}
                    </span>
                  </div>
                </div>

                {scripts.length > 1 && !isSelected && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteScript(item.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="លុប Script នេះ"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-between items-center gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onNewScript();
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>បង្កើត Script ថ្មី</span>
            </button>
            {onResetOfficialScripts && (
              <button
                onClick={() => {
                  onResetOfficialScripts();
                  onClose();
                }}
                className="flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-slate-200 px-2.5 py-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 transition-colors"
                title="ផ្ទុកឡើងវិញនូវ Script ផ្លូវការ Train to Busan ទាំងអស់ (រួមទាំង Master Edition)"
              >
                <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
                <span>ផ្ទុកឡើងវិញ Script ផ្លូវការ</span>
              </button>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700"
          >
            បិទ
          </button>
        </div>
      </div>
    </div>
  );
};
