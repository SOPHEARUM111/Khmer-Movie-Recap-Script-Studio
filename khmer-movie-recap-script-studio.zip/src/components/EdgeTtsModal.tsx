import React, { useState, useRef } from 'react';
import {
  X,
  Mic,
  Play,
  Square,
  Download,
  Copy,
  Check,
  Loader2,
  Sparkles,
  Volume2,
  Terminal,
  Settings2,
  FileAudio,
  Radio,
} from 'lucide-react';
import { RecapScript } from '../types/script';

interface EdgeTtsModalProps {
  isOpen: boolean;
  onClose: () => void;
  script: RecapScript;
}

export const EdgeTtsModal: React.FC<EdgeTtsModalProps> = ({ isOpen, onClose, script }) => {
  const [voice, setVoice] = useState<'km-KH-PisethNeural' | 'km-KH-SreymomNeural'>('km-KH-PisethNeural');
  const [rate, setRate] = useState<string>('+0%');
  const [pitch, setPitch] = useState<string>('+0Hz');
  const [text, setText] = useState<string>(() => script.hookOpening || (script.beats[0]?.narration ?? ''));
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'script' | 'fastapi' | 'requirements'>('script');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const pythonSnippet = `import asyncio
import edge_tts

TEXT = """${text.replace(/"/g, '\\"')}"""
VOICE = "${voice}"  # សំឡេង${voice.includes('Piseth') ? 'ប្រុស (Piseth - ពិសិដ្ឋ)' : 'ស្រី (Sreymom - ស្រីមុំ)'}
OUTPUT_FILE = "recap_audio_sample.mp3"

async def generate_voice():
    communicate = edge_tts.Communicate(TEXT, VOICE, rate="${rate}", pitch="${pitch}")
    await communicate.save(OUTPUT_FILE)
    print(f"បានបង្កើតឯកសារសំឡេងជោគជ័យ៖ {OUTPUT_FILE}")

if __name__ == "__main__":
    asyncio.run(generate_voice())
`;

  const fastapiSnippet = `from fastapi import FastAPI, HTTPException
from fastapi.responses import Response, FileResponse
import edge_tts
from pydantic import BaseModel

app = FastAPI(title="Khmer Recap TTS API")

class VoiceRequest(BaseModel):
    text: str
    voice: str = "${voice}"
    rate: str = "${rate}"
    pitch: str = "${pitch}"

@app.post("/generate-voice")
async def generate_voice_api(req: VoiceRequest):
    output_file = "recap_audio_sample.mp3"
    clean_voice = req.voice
    if "Pipha" in clean_voice:
        clean_voice = "km-KH-PisethNeural"
    communicate = edge_tts.Communicate(req.text, clean_voice, rate=req.rate, pitch=req.pitch)
    await communicate.save(output_file)
    return FileResponse(output_file, media_type="audio/mpeg", filename="recap_audio_sample.mp3")

# ដំណើរការ: uvicorn edge_tts_server:app --port 8000 --reload
`;

  const requirementsSnippet = `fastapi>=0.110.0
uvicorn>=0.28.0
google-generativeai>=0.4.0
edge-tts>=6.1.10
pydantic>=2.0.0
python-multipart>=0.0.9
`;

  const handleGenerateAndPlay = async () => {
    if (!text || text.trim() === '') {
      setErrorMsg('សូមបញ្ចូលអត្ថបទ');
      return;
    }

    if (isPlaying && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/edge-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice,
          rate,
          pitch,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'បរាជ័យក្នុងការផលិតសំឡេង');
      }

      const data = await res.json();
      const byteCharacters = atob(data.audioData);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'audio/mpeg' });
      const url = URL.createObjectURL(blob);

      setAudioBlob(blob);
      setAudioUrl(url);

      const audio = new Audio(url);
      audioRef.current = audio;

      audio.onended = () => setIsPlaying(false);
      audio.onerror = () => {
        setIsPlaying(false);
        setErrorMsg('កំហុសក្នុងការចាក់សំឡេង');
      };

      await audio.play();
      setIsPlaying(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'កំហុសបច្ចេកទេស Edge TTS');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadMp3 = () => {
    if (!audioBlob && !audioUrl) {
      // Trigger backend direct download
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = '/api/edge-tts';
      form.target = '_blank';
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'body';
      input.value = JSON.stringify({ text, voice, rate, pitch, download: true });
      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
      return;
    }

    const a = document.createElement('a');
    a.href = audioUrl!;
    a.download = 'recap_audio_sample.mp3';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const getActiveCode = () => {
    if (activeCodeTab === 'fastapi') return fastapiSnippet;
    if (activeCodeTab === 'requirements') return requirementsSnippet;
    return pythonSnippet;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(getActiveCode());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full flex flex-col max-h-[90vh] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">
                  Microsoft Edge TTS Studio (សំឡេងខ្មែរ AI)
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Online Neural
                </span>
              </div>
              <p className="text-xs text-slate-400">
                ផលិតសំឡេងសម្រាយរឿងជាភាសាខ្មែរ ធម្មជាតិ រលូន និងទាញយកជា MP3
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              if (audioRef.current) audioRef.current.pause();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Voice Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              ជ្រើសរើសសំឡេងអាន (Voice Model)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setVoice('km-KH-PisethNeural')}
                className={`p-3.5 rounded-2xl border text-left transition-all flex items-start gap-3 ${
                  voice === 'km-KH-PisethNeural'
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/30'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                  👨
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-100 text-sm">km-KH-PisethNeural</span>
                    <span className="text-[10px] font-semibold text-blue-400 bg-blue-500/10 px-1.5 py-0.2 rounded">
                      សំឡេងប្រុស
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    សំឡេង ពិសិដ្ឋ (Piseth) — សំឡេងធ្ងន់ មាំទាំ ស័ក្តិសមបំផុតសម្រាប់រឿងរន្ធត់/Action
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVoice('km-KH-SreymomNeural')}
                className={`p-3.5 rounded-2xl border text-left transition-all flex items-start gap-3 ${
                  voice === 'km-KH-SreymomNeural'
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/30'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="w-8 h-8 rounded-xl bg-pink-500/10 border border-pink-500/30 text-pink-400 flex items-center justify-center shrink-0 mt-0.5">
                  👩
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-100 text-sm">km-KH-SreymomNeural</span>
                    <span className="text-[10px] font-semibold text-pink-400 bg-pink-500/10 px-1.5 py-0.2 rounded">
                      សំឡេងស្រី
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    សំឡេង ស្រីមុំ (Sreymom) — សំឡេងស្រទន់ រលូន ច្បាស់ពិរោះ
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/* Quick Presets from Script */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                ផ្ទុកអត្ថបទរហ័ស (Quick Presets)
              </label>
              <span className="text-[11px] text-slate-500">
                {text.length} តួអក្សរ
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {script.hookOpening && (
                <button
                  type="button"
                  onClick={() => setText(script.hookOpening)}
                  className="text-xs px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-amber-300 border border-slate-700/60 transition-colors"
                >
                  🎙️ ពាក្យបើកឆាក (Hook)
                </button>
              )}
              {script.beats.slice(0, 4).map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setText(b.narration)}
                  className="text-xs px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-amber-300 border border-slate-700/60 transition-colors"
                >
                  ឈុតទី {b.beatNumber} ({b.title.slice(0, 15)}...)
                </button>
              ))}
              {script.outroCallToAction && (
                <button
                  type="button"
                  onClick={() => setText(script.outroCallToAction)}
                  className="text-xs px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-amber-300 border border-slate-700/60 transition-colors"
                >
                  🎬 ពាក្យបញ្ចប់ (Outro)
                </button>
              )}
            </div>
          </div>

          {/* Narration Text Area */}
          <div>
            <textarea
              rows={5}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="វាយបញ្ចូលអត្ថបទសម្រាយរឿងជាភាសាខ្មែរនៅទីនេះ..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500/50 leading-relaxed font-sans"
            />
          </div>

          {/* Controls: Speed Rate & Pitch */}
          <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1.5">
                ល្បឿនអាន (Rate): {rate}
              </label>
              <div className="flex gap-1.5">
                {['-10%', '+0%', '+10%', '+20%'].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRate(r)}
                    className={`flex-1 py-1 text-xs rounded-lg font-semibold transition-colors ${
                      rate === r
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {r === '+0%' ? 'ធម្មតា' : r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1.5">
                កម្ពស់សំឡេង (Pitch): {pitch}
              </label>
              <div className="flex gap-1.5">
                {['-5Hz', '+0Hz', '+5Hz'].map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPitch(p)}
                    className={`flex-1 py-1 text-xs rounded-lg font-semibold transition-colors ${
                      pitch === p
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {p === '+0Hz' ? 'ធម្មតា' : p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Python / FastAPI Code Snippet preview */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
            <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800 bg-slate-900/70">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('script')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'script'
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5 text-amber-400" />
                  <span>Python Script</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('fastapi')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'fastapi'
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Radio className="w-3.5 h-3.5 text-emerald-400" />
                  <span>FastAPI Service</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('requirements')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'requirements'
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileAudio className="w-3.5 h-3.5 text-blue-400" />
                  <span>requirements.txt</span>
                </button>
              </div>

              <button
                type="button"
                onClick={handleCopyCode}
                className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 hover:text-amber-300 px-2 py-1 rounded-md hover:bg-slate-800 transition-colors"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">បានចម្លង!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>ចម្លងកូដ</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto max-h-40 leading-relaxed">
              <code>{getActiveCode()}</code>
            </pre>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleGenerateAndPlay}
              disabled={isLoading}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-lg ${
                isPlaying
                  ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20'
              } disabled:opacity-50`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>កំពុងផលិតសំឡេង...</span>
                </>
              ) : isPlaying ? (
                <>
                  <Square className="w-4 h-4 fill-current" />
                  <span>បញ្ឈប់សំឡេង</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>ចាក់ស្តាប់ភ្លាមៗ (Play)</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleDownloadMp3}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700/80 transition-colors disabled:opacity-50"
              title="ទាញយកជាឯកសារ MP3 (recap_audio_sample.mp3)"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>ទាញយក MP3</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              if (audioRef.current) audioRef.current.pause();
              onClose();
            }}
            className="px-4 py-2.5 rounded-2xl text-xs font-semibold bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors"
          >
            បិទ
          </button>
        </div>
      </div>
    </div>
  );
};
