import React, { useState } from 'react';
import {
  X,
  Download,
  Copy,
  Check,
  FileText,
  FileCode,
  Share2,
  CheckCheck,
  Terminal,
  Smartphone,
} from 'lucide-react';
import { RecapScript } from '../types/script';
import {
  formatScriptToText,
  formatScriptToSRT,
  formatScriptToPythonEdgeTTS,
  downloadFile,
  calculateKhmerWordStats,
} from '../utils/exportHelpers';

interface ExportModalProps {
  script: RecapScript;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ script, isOpen, onClose }) => {
  const [activeFormat, setActiveFormat] = useState<'txt' | 'srt' | 'voiceonly' | 'py' | 'flutter'>('txt');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const fullText = formatScriptToText(script);
  const srtContent = formatScriptToSRT(script);
  const pythonScript = formatScriptToPythonEdgeTTS(script);
  const voiceOnlyText = [
    script.hookOpening,
    ...script.beats.map((b) => `ឈុតទី ${b.beatNumber}: ${b.narration}`),
    script.outroCallToAction,
  ].filter(Boolean).join('\n\n');

  const flutterCode = `// pubspec.yaml Dependencies:
// http: ^1.2.0
// video_player: ^2.8.2
// audioplayers: ^6.0.0
// cupertino_icons: ^1.0.6

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';

class ${script.title.replace(/[^a-zA-Z0-9]/g, '') || 'Movie'}RecapPlayer extends StatefulWidget {
  final String audioUrl;
  const ${script.title.replace(/[^a-zA-Z0-9]/g, '') || 'Movie'}RecapPlayer({Key? key, required this.audioUrl}) : super(key: key);

  @override
  State<${script.title.replace(/[^a-zA-Z0-9]/g, '') || 'Movie'}RecapPlayer> createState() => _PlayerState();
}

class _PlayerState extends State<${script.title.replace(/[^a-zA-Z0-9]/g, '') || 'Movie'}RecapPlayer> {
  late VideoPlayerController _videoController;
  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4'),
    )..initialize().then((_) => setState(() {}));
    _audioPlayer = AudioPlayer()..setSourceUrl(widget.audioUrl);
  }

  @override
  void dispose() {
    _videoController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('${script.title.replace(/'/g, "\\'")} - Recap')),
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : const Center(child: CircularProgressIndicator()),
          ),
          IconButton(
            iconSize: 48,
            icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
            onPressed: () {
              if (_isPlaying) {
                _videoController.pause();
                _audioPlayer.pause();
              } else {
                _videoController.play();
                _audioPlayer.resume();
              }
              setState(() => _isPlaying = !_isPlaying);
            },
          ),
        ],
      ),
    );
  }
}
`;

  const currentContent =
    activeFormat === 'txt'
      ? fullText
      : activeFormat === 'srt'
      ? srtContent
      : activeFormat === 'py'
      ? pythonScript
      : activeFormat === 'flutter'
      ? flutterCode
      : voiceOnlyText;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const sanitizedTitle = script.title.replace(/[^a-zA-Z0-9\u1780-\u17FF]/g, '_').slice(0, 30);
    if (activeFormat === 'txt') {
      downloadFile(fullText, `${sanitizedTitle}_recap_script.txt`);
    } else if (activeFormat === 'srt') {
      downloadFile(srtContent, `${sanitizedTitle}_subtitles.srt`, 'application/x-subrip');
    } else if (activeFormat === 'py') {
      downloadFile(pythonScript, `${sanitizedTitle}_generate_edge_tts.py`, 'text/x-python');
    } else if (activeFormat === 'flutter') {
      downloadFile(flutterCode, `${sanitizedTitle}_flutter_player.dart`, 'text/plain');
    } else {
      downloadFile(voiceOnlyText, `${sanitizedTitle}_voiceover_only.txt`);
    }
  };

  const stats = calculateKhmerWordStats(script);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full flex flex-col max-h-[90vh] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              Export Production Kit
            </span>
            <h2 className="text-lg font-bold text-slate-100">
              នាំចេញ Script សម្រាយរឿងខ្មែរ
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Selector Tabs */}
        <div className="px-6 pt-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/60 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveFormat('txt')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeFormat === 'txt'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Full Script (.txt)</span>
            </button>

            <button
              onClick={() => setActiveFormat('srt')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeFormat === 'srt'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Subtitles (.srt)</span>
            </button>

            <button
              onClick={() => setActiveFormat('voiceonly')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeFormat === 'voiceonly'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>តែពាក្យអាន (Voice Only)</span>
            </button>

            <button
              onClick={() => setActiveFormat('py')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeFormat === 'py'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Python Script (edge-tts)</span>
            </button>

            <button
              onClick={() => setActiveFormat('flutter')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeFormat === 'flutter'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Flutter App (.dart)</span>
            </button>
          </div>

          <div className="text-xs text-slate-400 font-medium">
            ~{stats.estimatedWords.toLocaleString()} ពាក្យ • {stats.totalBeats} ឈុតឆាក
          </div>
        </div>

        {/* Content Viewer */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950">
          <pre className="font-mono text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
            {currentContent}
          </pre>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 border-t border-slate-800">
          <span className="text-xs text-slate-400 hidden sm:inline">
            អាចនាំចូលទៅក្នុង Adobe Premiere Pro, CapCut, ឬ DaVinci Resolve
          </span>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all"
            >
              {copied ? (
                <>
                  <CheckCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">បានចម្លង!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>ចម្លង (Copy)</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>ទាញយក File ({activeFormat.toUpperCase()})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
