import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Film,
  Zap,
  Sliders,
  Layers,
  Clock,
  HelpCircle,
  Loader2,
  Bookmark,
} from 'lucide-react';
import { RecapScript } from '../types/script';

interface ScriptGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScriptGenerated: (script: RecapScript) => void;
}

const GENRE_OPTIONS = [
  'រន្ធត់ / ភ័យរន្ធត់ (Horror Thriller)',
  'សកម្មភាព / កាប់ចាក់ (Action Thriller)',
  'រស់រានមានជីវិត (Survival Suspense)',
  'ស៊ើបអង្កេត / អាថ៌កំបាំង (Mystery Detective)',
  'វិទ្យាសាស្ត្រ / អវកាស (Sci-Fi)',
  'ស្នេហា / មនោសញ្ចេតនា (Romantic Drama)',
  'កំប្លែង / ហាសគោរវាង (Dark Comedy)',
];

const TONE_OPTIONS = [
  'ញាប់ញ័រ រន្ធត់ព្រឺឆ្អឹងខ្នង (Spine-Chilling & Suspenseful)',
  'ជក់ចិត្ត ដិតអារម្មណ៍ កន្ត្រាក់ទ្រូង (High Stakes & Intense)',
  'រំជួលចិត្ត កម្សត់ស្រក់ទឹកភ្នែក (Emotional & Touching)',
  'កំប្លែង ឌឺដង សើចចុកពោះ (Humorous & Sarcastic Recap)',
  'ស្ងប់ស្ងាត់ វិភាគអាថ៌កំបាំង (Deep & Analytical Mystery)',
];

const PACING_OPTIONS = [
  'លម្អិតខ្លាំង Beat-by-Beat មិនកាត់សេចក្តីលឿន (Comprehensive & Slow Burn)',
  'ស្តង់ដារ Movie Recap (YouTube 10 - 15 នាទី)',
  'រហ័សខ្លី កន្ត្រាក់អារម្មណ៍ (TikTok / Reels / Shorts 2 - 3 នាទី)',
];

const QUICK_IDEAS = [
  {
    title: 'អាថ៌កំបាំងសាលារៀនចាស់បន្ទប់ ៤០៤',
    genre: 'រន្ធត់ / ភ័យរន្ធត់ (Horror Thriller)',
    synopsis: 'សិស្សវិទ្យាល័យ ៤ នាក់បានលួចចូលក្នុងបន្ទប់ ៤០៤ ដែលត្រូវបិទទ្វារចោល ២០ ឆ្នាំ។ ស្រាប់តែទ្វារដែកចាក់សោរពីក្រៅ ហើយក្ដារខៀនចាប់ផ្តើមលេចចេញអក្សរឈាមម្តងមួយៗ។',
    tone: 'ញាប់ញ័រ រន្ធត់ព្រឺឆ្អឹងខ្នង (Spine-Chilling & Suspenseful)',
  },
  {
    title: 'អ្នកបើកយន្តហោះចុងក្រោយលើដែនកោះបាត់បង់',
    genre: 'រស់រានមានជីវិត (Survival Suspense)',
    synopsis: 'យន្តហោះដឹកអ្នកដំណើរមួយគ្រឿងបានធ្លាក់លើកោះអាថ៌កំបាំងកណ្តាលមហាសមុទ្រប៉ាស៊ីហ្វិក។ អ្នកនៅរស់រានមានជីវិតចាប់ផ្តើមដឹងថា កោះនេះមិនមាននៅលើផែនទី ហើយមានសត្វចម្លែកតាមប្រមាញ់ពួកគេពេលយប់។',
    tone: 'ជក់ចិត្ត ដិតអារម្មណ៍ កន្ត្រាក់ទ្រូង (High Stakes & Intense)',
  },
  {
    title: 'ចោរប្លន់ឆ្លាតវៃ និងពេជ្របេះដូងសមុទ្រ',
    genre: 'សកម្មភាព / កាប់ចាក់ (Action Thriller)',
    synopsis: 'ក្រុមចោរប្លន់បច្ចេកវិទ្យាខ្ពស់ ៥ នាក់ បានរៀបគម្រោងលួចពេជ្រតម្លៃរាប់រយលានដុល្លារពីធនាគារកប់ក្រោមដី។ តែនៅនាទីចុងក្រោយ មានជនក្បត់ម្នាក់នៅក្នុងក្រុមបិទច្រកចេញទាំងអស់។',
    tone: 'ជក់ចិត្ត ដិតអារម្មណ៍ កន្ត្រាក់ទ្រូង (High Stakes & Intense)',
  },
];

export const ScriptGeneratorModal: React.FC<ScriptGeneratorModalProps> = ({
  isOpen,
  onClose,
  onScriptGenerated,
}) => {
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState(GENRE_OPTIONS[0]);
  const [synopsis, setSynopsis] = useState('');
  const [tone, setTone] = useState(TONE_OPTIONS[0]);
  const [pacing, setPacing] = useState(PACING_OPTIONS[0]);
  const [beatCount, setBeatCount] = useState<number>(5);
  const [customInstructions, setCustomInstructions] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');

  if (!isOpen) return null;

  const handleApplyPreset = (idea: typeof QUICK_IDEAS[0]) => {
    setTitle(idea.title);
    setGenre(idea.genre);
    setSynopsis(idea.synopsis);
    setTone(idea.tone);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title && !synopsis) {
      alert('សូមបញ្ចូលចំណងជើងរឿង ឬដំណើររឿងសង្ខេប!');
      return;
    }

    setIsLoading(true);
    setLoadingStep('កំពុងវិភាគដំណើររឿង និងរៀបចំរចនាសម្ព័ន្ធ...');

    try {
      const stepTimer1 = setTimeout(() => {
        setLoadingStep('កំពុងសរសេរឈុតឆាកម្ដងមួយៗ (Beat-by-Beat) ជាមួយ [ឈុតឆាក], [សំឡេងបន្លឺ], [ពន្យល់សាច់រឿង]...');
      }, 2500);

      const stepTimer2 = setTimeout(() => {
        setLoadingStep('កំពុងសម្រួលពាក្យអានជាភាសាខ្មែរឱ្យពិរោះ ជក់ចិត្ត និងកន្ត្រាក់អារម្មណ៍...');
      }, 6000);

      const res = await fetch('/api/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title || 'រឿងអាថ៌កំបាំង',
          genre,
          synopsis,
          tone,
          pacing,
          beatCount,
          customInstructions,
        }),
      });

      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'បរាជ័យក្នុងការបង្កើត Script');
      }

      const data = await res.json();
      const newScript: RecapScript = {
        id: `script-${Date.now()}`,
        title: data.title || title || 'សាច់រឿងថ្មី',
        genre: data.genre || genre,
        synopsis: synopsis || '',
        tone: tone,
        pacing: pacing,
        estimatedDuration: data.estimatedDuration || `${beatCount * 2} នាទី`,
        hookOpening: data.hookOpening || '',
        beats: data.beats || [],
        outroCallToAction: data.outroCallToAction || '',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      onScriptGenerated(newScript);
      onClose();
    } catch (err: any) {
      alert(err.message || 'កំហុសបច្ចេកទេសក្នុងការបង្កើត Script');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full flex flex-col max-h-[92vh] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4 text-slate-950" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                បង្កើត Script សម្រាយរឿងខ្មែរអាជីព
              </h2>
              <p className="text-xs text-slate-400">
                ដំណើរការដោយ Gemini AI • លម្អិតឈុតឆាកម្ដងមួយៗ (Beat-by-Beat)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 disabled:opacity-30"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Quick Idea Presets */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 mb-2">
              <Bookmark className="w-3.5 h-3.5" />
              <span>គំនិតរឿងគំរូលឿន (Quick Ideas)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {QUICK_IDEAS.map((idea, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(idea)}
                  className="text-left p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-all text-xs group"
                >
                  <div className="font-semibold text-slate-200 group-hover:text-amber-300 truncate">
                    {idea.title}
                  </div>
                  <div className="text-[10px] text-slate-500 truncate mt-0.5">
                    {idea.genre.split('(')[0]}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <form id="generate-script-form" onSubmit={handleSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                ចំណងជើងរឿង ឬឈ្មោះភាពយន្ត <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="ឧ. ផ្ទះឈើចុងភូមិ និងស្រមោលក្រចកខ្មៅ"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Genre & Beat Count */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  ប្រភេទរឿង (Genre)
                </label>
                <select
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                >
                  {GENRE_OPTIONS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    ចំនួនឈុតឆាក (Beats)
                  </label>
                  <span className="text-xs font-mono font-bold text-amber-400">
                    {beatCount} ឈុតឆាក
                  </span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="10"
                  value={beatCount}
                  onChange={(e) => setBeatCount(parseInt(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Synopsis / Story Details */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                សាច់រឿងសង្ខេប / ដំណើររឿងសំខាន់ៗ (Synopsis & Plot Points){' '}
                <span className="text-rose-400">*</span>
              </label>
              <textarea
                rows={3}
                required
                value={synopsis}
                onChange={(e) => setSynopsis(e.target.value)}
                placeholder="រៀបរាប់ត្រួសៗអំពីតួអង្គ ទីតាំង និងឧប្បត្តិហេតុដែលបានកើតឡើង... (AI នឹងពង្រីកជា Beat-by-Beat យ៉ាងលម្អិត)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 leading-relaxed"
              />
            </div>

            {/* Tone of Voice */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                សម្លេង និងអារម្មណ៍រឿង (Tone of Voice)
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              >
                {TONE_OPTIONS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            {/* Pacing */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                ល្បឿនសាច់រឿង (Pacing)
              </label>
              <select
                value={pacing}
                onChange={(e) => setPacing(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              >
                {PACING_OPTIONS.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            {/* Custom Instructions */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                សេចក្តីណែនាំបន្ថែមពិសេស (ជម្រើសបន្ថែម)
              </label>
              <input
                type="text"
                value={customInstructions}
                onChange={(e) => setCustomInstructions(e.target.value)}
                placeholder="ឧ. បញ្ចូលឈុតឆាករបត់សាច់រឿងចុងក្រោយ (Plot Twist) ឱ្យភ្ញាក់ផ្អើលបំផុត..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-amber-500"
              />
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            {isLoading ? (
              <span className="flex items-center gap-2 text-amber-400">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="truncate max-w-xs">{loadingStep}</span>
              </span>
            ) : (
              <span>បញ្ជាក់សញ្ញា [ឈុតឆាក], [សំឡេងបន្លឺ], [ពន្យល់សាច់រឿង]</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-all disabled:opacity-40"
            >
              បោះបង់
            </button>

            <button
              form="generate-script-form"
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:hover:scale-100"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>កំពុងបង្កើត Script...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>បង្កើត Script ឥឡូវនេះ</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
