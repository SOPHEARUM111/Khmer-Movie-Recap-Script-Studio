import React, { useState } from 'react';
import {
  Video,
  Volume2,
  Mic,
  HeartPulse,
  Scissors,
  Sparkles,
  Play,
  Square,
  Edit3,
  Check,
  Copy,
  Trash2,
  ChevronUp,
  ChevronDown,
  Loader2,
  MoreVertical,
} from 'lucide-react';
import { Beat } from '../types/script';
import { sfx } from '../utils/soundEffects';

interface BeatCardProps {
  beat: Beat;
  isFirst: boolean;
  isLast: boolean;
  onUpdateBeat: (updated: Beat) => void;
  onDeleteBeat: (id: string) => void;
  onMoveUp: (id: string) => void;
  onMoveDown: (id: string) => void;
}

export const BeatCard: React.FC<BeatCardProps> = ({
  beat,
  isFirst,
  isLast,
  onUpdateBeat,
  onDeleteBeat,
  onMoveUp,
  onMoveDown,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedBeat, setEditedBeat] = useState<Beat>(beat);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [showEnhanceMenu, setShowEnhanceMenu] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // TTS State
  const [isGeneratingTts, setIsGeneratingTts] = useState(false);
  const [isPlayingTts, setIsPlayingTts] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  const handleSaveEdit = () => {
    onUpdateBeat(editedBeat);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditedBeat(beat);
    setIsEditing(false);
  };

  const handleCopyNarration = () => {
    navigator.clipboard.writeText(beat.narration);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Enhance beat via backend Gemini
  const handleEnhance = async (instructionType: 'more_scary' | 'more_detail' | 'smoother_voice') => {
    setShowEnhanceMenu(false);
    setIsEnhancing(true);
    try {
      const res = await fetch('/api/enhance-scene', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ beat, instructionType }),
      });
      if (!res.ok) throw new Error('បរាជ័យក្នុងការកែច្នៃឈុត');
      const data = await res.json();
      onUpdateBeat(data);
    } catch (err: any) {
      alert(err.message || 'កំហុសបច្ចេកទេស');
    } finally {
      setIsEnhancing(false);
    }
  };

  // Play audio cue helper (triggers boom or tension)
  const handlePlayAudioCue = () => {
    const cue = (beat.audioCue || '').toLowerCase();
    if (cue.includes('បេះដូង') || cue.includes('heartbeat')) {
      sfx.playHeartbeat();
    } else if (cue.includes('កន្ត្រាក់') || cue.includes('screech') || cue.includes('jump scare')) {
      sfx.playJumpScareStinger();
    } else if (cue.includes('តានតឹង') || cue.includes('riser')) {
      sfx.playTensionRiser();
    } else if (cue.includes('ព្រឺ') || cue.includes('drone') || cue.includes('ghost')) {
      sfx.playEerieDrone();
    } else if (cue.includes('ទ្វារ') || cue.includes('ដែក') || cue.includes('door') || cue.includes('metal')) {
      sfx.playMetalDoorImpact();
    } else {
      sfx.playCinematicBoom();
    }
  };

  // Text-To-Speech Narration Preview
  const handleToggleTts = async () => {
    if (isPlayingTts && audioElement) {
      audioElement.pause();
      setIsPlayingTts(false);
      return;
    }

    setIsGeneratingTts(true);
    try {
      const res = await fetch('/api/tts-narration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: beat.narration, voiceName: 'km-KH-PisethNeural' }),
      });

      if (!res.ok) {
        throw new Error('មិនអាចទាញយកសំឡេងបានទេ');
      }

      const data = await res.json();
      const audioUrl = `data:${data.format || 'audio/wav'};base64,${data.audioData}`;
      const audio = new Audio(audioUrl);
      
      audio.onended = () => setIsPlayingTts(false);
      audio.onerror = () => setIsPlayingTts(false);

      setAudioElement(audio);
      await audio.play();
      setIsPlayingTts(true);
    } catch (err) {
      // Fallback: If TTS server fails or not available, use browser SpeechSynthesis
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(beat.narration);
        utterance.rate = 0.95;
        utterance.onend = () => setIsPlayingTts(false);
        utterance.onerror = () => setIsPlayingTts(false);
        window.speechSynthesis.speak(utterance);
        setIsPlayingTts(true);
      } else {
        alert('សំឡេង TTS មិនអាចដំណើរការបាន');
      }
    } finally {
      setIsGeneratingTts(false);
    }
  };

  return (
    <div className="group relative bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-4 sm:p-6 transition-all shadow-lg hover:shadow-xl">
      {/* Beat Header Bar */}
      <div className="flex items-center justify-between gap-3 border-b border-slate-800/80 pb-3 mb-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold flex items-center justify-center text-sm shrink-0">
            {beat.beatNumber}
          </div>

          <div className="min-w-0">
            {isEditing ? (
              <input
                type="text"
                value={editedBeat.title}
                onChange={(e) => setEditedBeat({ ...editedBeat, title: e.target.value })}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-0.5 text-sm font-semibold text-slate-100 w-full"
              />
            ) : (
              <h3 className="font-bold text-slate-100 text-sm sm:text-base truncate">
                {beat.title}
              </h3>
            )}
          </div>

          <span className="text-xs bg-slate-800/80 text-slate-400 px-2.5 py-0.5 rounded-full font-mono shrink-0">
            {isEditing ? (
              <input
                type="text"
                value={editedBeat.timestamp}
                onChange={(e) => setEditedBeat({ ...editedBeat, timestamp: e.target.value })}
                className="bg-slate-950 border border-slate-700 rounded px-1 text-xs w-24 text-center text-amber-400"
              />
            ) : (
              beat.timestamp
            )}
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1 shrink-0">
          {/* TTS Button */}
          <button
            onClick={handleToggleTts}
            disabled={isGeneratingTts}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              isPlayingTts
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title="ស្តាប់សំឡេងអានសាកល្បង (AI Voiceover Preview)"
          >
            {isGeneratingTts ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
            ) : isPlayingTts ? (
              <Square className="w-3.5 h-3.5 fill-current" />
            ) : (
              <Play className="w-3.5 h-3.5" />
            )}
            <span className="hidden sm:inline">
              {isPlayingTts ? 'កំពុងអាន' : 'ស្តាប់សំឡេង'}
            </span>
          </button>

          {/* AI Enhance Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowEnhanceMenu(!showEnhanceMenu)}
              disabled={isEnhancing}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all"
              title="កែច្នៃឈុតនេះជាមួយ Gemini AI"
            >
              {isEnhancing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span className="hidden md:inline">កែច្នៃ AI</span>
            </button>

            {showEnhanceMenu && (
              <div className="absolute right-0 top-full mt-1.5 w-52 bg-slate-950 border border-slate-700 rounded-xl shadow-2xl py-1 z-30 text-xs">
                <div className="px-3 py-1.5 text-slate-400 font-semibold border-b border-slate-800">
                  ជ្រើសរើសទម្រង់កែច្នៃ
                </div>
                <button
                  onClick={() => handleEnhance('more_scary')}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-amber-500/10 hover:text-amber-400 flex items-center gap-2"
                >
                  <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
                  <span>ធ្វើឱ្យកាន់តែរន្ធត់ញាប់ញ័រ</span>
                </button>
                <button
                  onClick={() => handleEnhance('more_detail')}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-amber-500/10 hover:text-amber-400 flex items-center gap-2"
                >
                  <Video className="w-3.5 h-3.5 text-cyan-400" />
                  <span>បន្ថែមកាយវិការ & បរិយាកាស</span>
                </button>
                <button
                  onClick={() => handleEnhance('smoother_voice')}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-amber-500/10 hover:text-amber-400 flex items-center gap-2"
                >
                  <Mic className="w-3.5 h-3.5 text-emerald-400" />
                  <span>សម្រួលពាក្យអានឱ្យរលូន</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit / Save toggle */}
          {isEditing ? (
            <button
              onClick={handleSaveEdit}
              className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30"
              title="រក្សាទុកការកែប្រែ"
            >
              <Check className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              title="កែសម្រួលអត្ថបទ"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          )}

          {/* Copy Narration */}
          <button
            onClick={handleCopyNarration}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="ចម្លងពាក្យអានសម្រាយ"
          >
            <Copy className={`w-4 h-4 ${copied ? 'text-emerald-400' : ''}`} />
          </button>

          {/* Reordering */}
          <div className="flex flex-col ml-1">
            <button
              onClick={() => onMoveUp(beat.id)}
              disabled={isFirst}
              className="text-slate-500 hover:text-slate-200 disabled:opacity-30 disabled:hover:text-slate-500"
              title="រំកិលឡើងលើ"
            >
              <ChevronUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onMoveDown(beat.id)}
              disabled={isLast}
              className="text-slate-500 hover:text-slate-200 disabled:opacity-30 disabled:hover:text-slate-500"
              title="រំកិលចុះក្រោម"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Delete */}
          <button
            onClick={() => onDeleteBeat(beat.id)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 ml-1"
            title="លុបឈុតនេះ"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Beat Fields */}
      <div className="space-y-3.5 text-sm">
        {/* [ឈុតឆាក: Scene Description] */}
        <div className="bg-slate-950/60 rounded-xl p-3 border border-cyan-500/20">
          <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-xs mb-1.5">
            <Video className="w-3.5 h-3.5" />
            <span>[ឈុតឆាក]: ការពិពណ៌នារូបភាព ប្លង់កាមេរ៉ា & បរិយាកាស</span>
          </div>
          {isEditing ? (
            <textarea
              rows={2}
              value={editedBeat.sceneDescription}
              onChange={(e) =>
                setEditedBeat({ ...editedBeat, sceneDescription: e.target.value })
              }
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          ) : (
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              {beat.sceneDescription}
            </p>
          )}
        </div>

        {/* [សំឡេងបន្លឺ: Audio Cue & SFX] */}
        <div className="bg-slate-950/60 rounded-xl p-3 border border-amber-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-xs mb-1">
              <Volume2 className="w-3.5 h-3.5" />
              <span>[សំឡេងបន្លឺ]: សំឡេងបែបផែន (SFX) & ភ្លេងរំជើបរំជួល</span>
            </div>
            {isEditing ? (
              <input
                type="text"
                value={editedBeat.audioCue}
                onChange={(e) =>
                  setEditedBeat({ ...editedBeat, audioCue: e.target.value })
                }
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              />
            ) : (
              <p className="text-amber-200/90 text-xs sm:text-sm font-mono">
                {beat.audioCue}
              </p>
            )}
          </div>
          <button
            onClick={handlePlayAudioCue}
            className="flex items-center gap-1 self-start sm:self-center px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-medium shrink-0 transition-all active:scale-95"
            title="ចាក់សូរសំឡេងសាកល្បង"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>ចាក់សំឡេង SFX</span>
          </button>
        </div>

        {/* [ពន្យល់សាច់រឿង: Narration Voiceover] - The Core Storyteller Text */}
        <div className="bg-gradient-to-r from-emerald-950/40 via-slate-950 to-emerald-950/20 rounded-xl p-4 border border-emerald-500/30">
          <div className="flex items-center justify-between gap-2 text-emerald-400 font-bold text-xs mb-2">
            <div className="flex items-center gap-1.5">
              <Mic className="w-4 h-4 text-emerald-400" />
              <span className="uppercase tracking-wide">
                [ពន្យល់សាច់រឿង]: អត្ថបទអានសម្រាយរឿងខ្មែរ
              </span>
            </div>
            <span className="text-[11px] text-emerald-500/80 font-normal">
              សូរសៀងរលូន ជក់ចិត្ត
            </span>
          </div>

          {isEditing ? (
            <textarea
              rows={4}
              value={editedBeat.narration}
              onChange={(e) => setEditedBeat({ ...editedBeat, narration: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 font-medium leading-relaxed focus:outline-none focus:border-emerald-500"
            />
          ) : (
            <p className="text-slate-100 text-sm sm:text-base leading-relaxed font-medium">
              {beat.narration}
            </p>
          )}
        </div>

        {/* Bottom row: [អារម្មណ៍តួអង្គ] & [កំណត់សម្គាល់កាត់ត] */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* [អារម្មណ៍តួអង្គ: Character Emotions] */}
          <div className="bg-slate-950/50 rounded-xl p-3 border border-rose-500/20">
            <div className="flex items-center gap-1.5 text-rose-400 font-semibold text-xs mb-1">
              <HeartPulse className="w-3.5 h-3.5" />
              <span>[អារម្មណ៍តួអង្គ]: កាយវិការ & ភាពភ័យខ្លាច</span>
            </div>
            {isEditing ? (
              <input
                type="text"
                value={editedBeat.characterEmotion}
                onChange={(e) =>
                  setEditedBeat({ ...editedBeat, characterEmotion: e.target.value })
                }
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
              />
            ) : (
              <p className="text-slate-300 text-xs leading-relaxed">
                {beat.characterEmotion}
              </p>
            )}
          </div>

          {/* [កំណត់សម្គាល់កាត់ត: Video Editing Cue] */}
          <div className="bg-slate-950/50 rounded-xl p-3 border border-purple-500/20">
            <div className="flex items-center gap-1.5 text-purple-400 font-semibold text-xs mb-1">
              <Scissors className="w-3.5 h-3.5" />
              <span>[កំណត់សម្គាល់កាត់ត]: កាត់ប្លង់ / Zoom / Glitch</span>
            </div>
            {isEditing ? (
              <input
                type="text"
                value={editedBeat.directorNotes || ''}
                onChange={(e) =>
                  setEditedBeat({ ...editedBeat, directorNotes: e.target.value })
                }
                placeholder="បច្ចេកទេសកាត់ត..."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
              />
            ) : (
              <p className="text-slate-300 text-xs leading-relaxed">
                {beat.directorNotes || 'កាត់ប្លង់តាមចង្វាក់ភ្លេងធម្មតា'}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
