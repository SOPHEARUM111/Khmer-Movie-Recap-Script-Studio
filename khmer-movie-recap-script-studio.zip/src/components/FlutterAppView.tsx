import React, { useState, useEffect, useRef } from 'react';
import JSZip from 'jszip';
import {
  Smartphone,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Film,
  Code,
  Copy,
  Check,
  Download,
  Sparkles,
  RefreshCw,
  Layers,
  Wifi,
  Battery,
  ArrowLeft,
  FileCode,
  Terminal,
  ExternalLink,
  ChevronRight,
  Music,
  Tv,
  CheckCircle2,
  AlertCircle,
  Loader2,
  BookOpen,
  Package,
} from 'lucide-react';
import { RecapScript, Beat } from '../types/script';

interface FlutterAppViewProps {
  onLoadScriptToEditor?: (script: RecapScript) => void;
}

interface RecapTask {
  task_id: string;
  movie_title: string;
  status: 'pending' | 'generating_script' | 'generating_audio' | 'completed' | 'failed';
  progress: number;
  stage: string;
  result?: {
    script_url?: string;
    audio_url?: string;
    scriptUrl?: string;
    audioUrl?: string;
    word_count?: number;
    wordCount?: number;
    voice_used?: string;
    characters_count?: number;
    script_content?: string;
  } | null;
  error?: string | null;
}

const PRESET_MOVIES = [
  {
    title: 'រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)',
    genre: 'ភ័យរន្ធត់ & រំភើប',
    notes: 'ដំណើររឿងកម្សត់ ការលះបង់របស់ឪពុក និងការប្រយុទ្ធទម្លុះហ្វូង Zombie',
    previewVideo: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80',
  },
  {
    title: 'កន្លែងស្ងប់ស្ងាត់ (A Quiet Place)',
    genre: 'ភ័យរន្ធត់ & វិទ្យាសាស្ត្រ',
    notes: 'សត្វចម្លែកប្រមាញ់តាមសំឡេង ភាពស្ងប់ស្ងាត់ដកដង្ហើម និងការការពារកូនៗ',
    previewVideo: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80',
  },
  {
    title: 'ដំណើរឆ្លងកាត់ផ្កាយ (Interstellar)',
    genre: 'វិទ្យាសាស្ត្រ & អារម្មណ៍',
    notes: 'ការស្វែងរកភពថ្មីសម្រាប់មនុស្សជាតិ ប្រហោងខ្មៅ និងពេលវេលា',
    previewVideo: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    poster: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80',
  },
];

const FLUTTER_CODE_FILES = [
  {
    filename: 'pubspec.yaml',
    title: 'pubspec.yaml (កញ្ចប់ Dependencies)',
    description: 'កញ្ចប់ជំនួយដូចដែលបានកំណត់ក្នុងសំណើ៖ http, video_player, audioplayers',
    content: `name: khmer_movie_recap_app
description: "Khmer Movie Recap AI Mobile App - Powered by FastAPI & Edge-TTS"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  http: ^1.2.0              # សម្រាប់ផ្ញើ Request ទៅកាន់ FastAPI Server
  video_player: ^2.8.2      # សម្រាប់ចាក់វីដេអូសម្រាយរឿង
  audioplayers: ^6.0.0      # សម្រាប់ចាក់ឯកសារសំឡេង MP3
  cupertino_icons: ^1.0.6

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`,
  },
  {
    filename: 'lib/services/api_service.dart',
    title: 'lib/services/api_service.dart (FastAPI Client)',
    description: 'គ្រប់គ្រងការផ្ញើ Request ទៅ FastAPI និង Polling ត្រួតពិនិត្យ Progress',
    content: `import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/recap_task.dart';

class RecapApiService {
  // អាសយដ្ឋាន Server FastAPI (នៅលើទូរស័ព្ទប្រើ IP ម៉ាស៊ីន ឬ 10.0.2.2 លើ Emulator)
  final String baseUrl;

  RecapApiService({this.baseUrl = 'http://10.0.2.2:8000'});

  /// បញ្ជាបង្កើត Script សម្រាយរឿង 5 វគ្គ និងសំឡេង Edge-TTS
  Future<String> createRecapTask({
    required String movieTitle,
    String genre = 'ភ័យរន្ធត់ (Horror)',
    String voice = 'km-KH-PisethNeural',
    String notes = '',
  }) async {
    final url = Uri.parse('$baseUrl/api/recap/generate');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'movie_title': movieTitle,
        'genre': genre,
        'voice': voice,
        'notes': notes,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['task_id'] as String;
    } else {
      throw Exception('បរាជ័យក្នុងការបង្កើត Task: \${response.statusCode}');
    }
  }

  /// ពិនិត្យមើលស្ថានភាព និង Progress Bar
  Future<RecapTask> getTaskStatus(String taskId) async {
    final url = Uri.parse('$baseUrl/api/recap/status/$taskId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return RecapTask.fromJson(data);
    } else {
      throw Exception('រកមិនឃើញ Task ID នេះឡើយ');
    }
  }
}
`,
  },
  {
    filename: 'lib/models/recap_task.dart',
    title: 'lib/models/recap_task.dart (Data Model)',
    description: 'ទម្រង់ទិន្នន័យឆ្លើយតបពី FastAPI API',
    content: `class RecapTask {
  final String taskId;
  final String movieTitle;
  final String status;
  final int progress;
  final String stage;
  final RecapResult? result;
  final String? error;

  RecapTask({
    required this.taskId,
    required this.movieTitle,
    required this.status,
    required this.progress,
    required this.stage,
    this.result,
    this.error,
  });

  factory RecapTask.fromJson(Map<String, dynamic> json) {
    return RecapTask(
      taskId: json['task_id'] ?? '',
      movieTitle: json['movie_title'] ?? '',
      status: json['status'] ?? 'pending',
      progress: json['progress'] ?? 0,
      stage: json['stage'] ?? '',
      result: json['result'] != null ? RecapResult.fromJson(json['result']) : null,
      error: json['error'],
    );
  }

  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
}

class RecapResult {
  final String scriptUrl;
  final String audioUrl;
  final int wordCount;
  final String? scriptContent;

  RecapResult({
    required this.scriptUrl,
    required this.audioUrl,
    required this.wordCount,
    this.scriptContent,
  });

  factory RecapResult.fromJson(Map<String, dynamic> json) {
    return RecapResult(
      scriptUrl: json['script_url'] ?? '',
      audioUrl: json['audio_url'] ?? '',
      wordCount: json['word_count'] ?? 0,
      scriptContent: json['script_content'],
    );
  }
}
`,
  },
  {
    filename: 'lib/screens/recap_player_screen.dart',
    title: 'lib/screens/recap_player_screen.dart (Video + Audio Player)',
    description: 'ចាក់វីដេអូជាមួយ video_player និងសំឡេង MP3 ខ្មែរជាមួយ audioplayers ព្រមទាំងបង្ហាញ Subtitle ឈុតឆាក',
    content: `import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import '../models/recap_task.dart';

class RecapPlayerScreen extends StatefulWidget {
  final RecapTask task;
  final String serverBaseUrl;

  const RecapPlayerScreen({
    Key? key,
    required this.task,
    required this.serverBaseUrl,
  }) : super(key: key);

  @override
  State<RecapPlayerScreen> createState() => _RecapPlayerScreenState();
}

class _RecapPlayerScreenState extends State<RecapPlayerScreen> {
  late VideoPlayerController _videoController;
  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _initPlayers();
  }

  void _initPlayers() async {
    // 1. រៀបចំ Video Player (វិដេអូទិដ្ឋភាពភាពយន្ត)
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4'),
    )..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
      });

    // 2. រៀបចំ Audio Player សម្រាប់ចាក់ MP3 ខ្មែរពី FastAPI
    _audioPlayer = AudioPlayer();
    final audioFullUrl = '\${widget.serverBaseUrl}\${widget.task.result?.audioUrl}';

    _audioPlayer.onDurationChanged.listen((d) => setState(() => _duration = d));
    _audioPlayer.onPositionChanged.listen((p) => setState(() => _position = p));
    _audioPlayer.onPlayerComplete.listen((_) => setState(() => _isPlaying = false));

    // កំណត់ Audio Source
    await _audioPlayer.setSourceUrl(audioFullUrl);
  }

  void _togglePlayPause() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
      await _videoController.pause();
    } else {
      await _audioPlayer.resume();
      await _videoController.play();
    }
    setState(() => _isPlaying = !_isPlaying);
  }

  @override
  void dispose() {
    _videoController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: Text(widget.task.movieTitle, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF1E293B),
      ),
      body: Column(
        children: [
          // ផ្នែកទី១: ផ្ទាំង Video Player (video_player)
          AspectRatio(
            aspectRatio: 16 / 9,
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : const Center(child: CircularProgressIndicator(color: Colors.amber)),
          ),

          // ផ្នែកទី២: ប៊ូតុងបញ្ជា និង Progress Bar សំឡេង (audioplayers)
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Slider(
                  activeColor: Colors.amber,
                  inactiveColor: Colors.white24,
                  min: 0,
                  max: _duration.inSeconds.toDouble(),
                  value: _position.inSeconds.toDouble().clamp(0, _duration.inSeconds.toDouble()),
                  onChanged: (val) async {
                    final newPos = Duration(seconds: val.toInt());
                    await _audioPlayer.seek(newPos);
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      iconSize: 48,
                      color: Colors.amber,
                      icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled),
                      onPressed: _togglePlayPause,
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ផ្នែកទី៣: Script អត្ថបទអាន 5 Acts
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(16),
              ),
              child: SingleChildScrollView(
                child: Text(
                  widget.task.result?.scriptContent ?? 'គ្មានអត្ថបទ',
                  style: const TextStyle(color: Colors.white70, height: 1.6, fontSize: 14),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
`,
  },
  {
    filename: 'lib/main.dart',
    title: 'lib/main.dart (Complete App Entry Point)',
    description: 'កម្មវិធីទូរស័ព្ទ AI Movie Recap Studio គាំទ្រ Script 90 នាទី, សំឡេងកូនក្មេង/មនុស្សចាស់/Voice Cloning, Storyboard និង Video Player',
    content: `// ==============================================================================
// កម្មវិធីទូរស័ព្ទ AI Movie Recap Studio (Flutter Android & iOS)
// គាំទ្រ៖ Script 90 នាទី, សំឡេងកូនក្មេង/មនុស្សចាស់, Storyboard និង Video Player
// ==============================================================================

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String kBackendBaseUrl = "http://10.0.2.2:8001"; // 10.0.2.2 សម្រាប់ Android Emulator

void main() {
  runApp(const MovieRecapApp());
}

class MovieRecapApp extends StatelessWidget {
  const MovieRecapApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Movie Recap Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07090E),
        primaryColor: const Color(0xFFE11D48),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE11D48),
          secondary: Color(0xFFF59E0B),
          surface: Color(0xFF111827),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _titleController = TextEditingController(text: "រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)");
  final TextEditingController _notesController = TextEditingController();

  int _selectedDuration = 90;
  String _selectedGenre = "រន្ធត់ / ខ្មោចឆៅ (Horror)";
  bool _enableChildVoice = true;
  bool _enableElderlyVoice = true;
  bool _isSubmitting = false;

  bool _useClonedVoice = false;
  String? _clonedVoiceId;
  String _clonedVoiceName = "សំឡេងមនុស្សពិតរបស់ខ្ញុំ";

  final List<int> _durations = [15, 30, 60, 90];
  final List<String> _genres = [
    "រន្ធត់ / ខ្មោចឆៅ (Horror)",
    "សកម្មភាព / វាយប្រហារ (Action)",
    "អាថ៌កំបាំង / ស៊ើបអង្កេត (Mystery)",
    "វិទ្យាសាស្ត្រ / Sci-Fi",
    "មនោសញ្ចេតនា / កម្សត់ (Drama)"
  ];

  Future<void> _startGeneration() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) return;
    setState(() => _isSubmitting = true);

    try {
      final url = Uri.parse("$kBackendBaseUrl/api/recap/generate");
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "movie_title": title,
          "genre": _selectedGenre,
          "duration": _selectedDuration,
          "notes": _notesController.text.trim(),
          "include_child_voice": _enableChildVoice,
          "include_elderly_voice": _enableElderlyVoice,
          "use_cloned_voice": _useClonedVoice,
          "cloned_voice_id": _clonedVoiceId,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final String taskId = data["task_id"];
        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProgressScreen(taskId: taskId, movieTitle: title),
          ),
        );
      }
    } catch (e) {
      debugPrint("Error: $e");
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Movie Recap Studio'), backgroundColor: const Color(0xFF111827)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'ចំណងជើងរឿង')),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _isSubmitting ? null : _startGeneration,
              icon: const Icon(Icons.auto_awesome),
              label: Text(_isSubmitting ? 'កំពុងដំណើការ...' : '🚀 ចាប់ផ្តើមបង្កើត 90 នាទី Script & សំឡេង'),
            ),
          ],
        ),
      ),
    );
  }
}

class ProgressScreen extends StatelessWidget {
  final String taskId;
  final String movieTitle;
  const ProgressScreen({super.key, required this.taskId, required this.movieTitle});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(movieTitle)),
      body: const Center(child: CircularProgressIndicator()),
    );
  }
}
`,
  },
  {
    filename: 'lib/screens/recap_generator_screen.dart',
    title: 'lib/screens/recap_generator_screen.dart (Generator Screen)',
    description: 'ទម្រង់បញ្ចូលចំណងជើងរឿង ជ្រើសរើសសំឡេង Khmer Edge-TTS និងផ្ញើ Request ទៅ FastAPI',
    content: `import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/recap_task.dart';
import 'recap_player_screen.dart';

class RecapGeneratorScreen extends StatefulWidget {
  const RecapGeneratorScreen({Key? key}) : super(key: key);

  @override
  State<RecapGeneratorScreen> createState() => _RecapGeneratorScreenState();
}

class _RecapGeneratorScreenState extends State<RecapGeneratorScreen> {
  final _apiService = RecapApiService();
  final _titleController = TextEditingController(text: 'រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)');
  final _notesController = TextEditingController(text: 'ដំណើររឿងកម្សត់ ការលះបង់របស់ឪពុក និងការប្រយុទ្ធទម្លុះហ្វូង Zombie');

  String _selectedGenre = 'ភ័យរន្ធត់ (Horror)';
  String _selectedVoice = 'km-KH-PisethNeural';
  bool _isLoading = false;
  String? _currentTaskId;
  RecapTask? _taskData;

  void _generateRecap() async {
    setState(() => _isLoading = true);
    try {
      final taskId = await _apiService.createRecapTask(
        movieTitle: _titleController.text.trim(),
        genre: _selectedGenre,
        voice: _selectedVoice,
        notes: _notesController.text.trim(),
      );
      setState(() => _currentTaskId = taskId);
      _pollStatus(taskId);
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('កំហុស៖ \$e')));
    }
  }

  void _pollStatus(String taskId) async {
    while (_isLoading) {
      await Future.delayed(const Duration(seconds: 3));
      try {
        final task = await _apiService.getTaskStatus(taskId);
        setState(() => _taskData = task);
        if (task.isCompleted) {
          setState(() => _isLoading = false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RecapPlayerScreen(task: task, serverBaseUrl: _apiService.baseUrl),
            ),
          );
          break;
        }
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🎬 Khmer Movie Recap AI')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'ចំណងជើងរឿង')),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _generateRecap,
              icon: const Icon(Icons.auto_awesome),
              label: Text(_isLoading ? 'កំពុងបង្កើត... (\${_taskData?.progress ?? 0}%)' : '🚀 ចាប់ផ្តើមបង្កើត 5 Acts'),
            ),
          ],
        ),
      ),
    );
  }
}
`,
  },
  {
    filename: 'README.md',
    title: 'README.md (សៀវភៅណែនាំដំឡើង & flutter pub get)',
    description: 'ការណែនាំដំឡើង flutter pub get, កំណត់ IP Server និងដំណើរការ flutter run',
    content: `# 🎬 Khmer Movie Recap AI - Flutter Client

## 📦 កញ្ចប់ជំនួយ (Dependencies in pubspec.yaml)
- http: ^1.2.0 (ផ្ញើ Request ទៅកាន់ FastAPI Server)
- video_player: ^2.8.2 (ចាក់វីដេអូសម្រាយរឿង)
- audioplayers: ^6.0.0 (ចាក់ឯកសារសំឡេង MP3)
- cupertino_icons: ^1.0.6

## 🚀 របៀបដំណើរការលើកុំព្យូទ័រ
1. flutter pub get
2. uvicorn main:app --reload --host 0.0.0.0 --port 8001
3. flutter run
`,
  },
];

export const FlutterAppView: React.FC<FlutterAppViewProps> = ({ onLoadScriptToEditor }) => {
  // Mobile Simulator state
  const [mobileTab, setMobileTab] = useState<'generator' | 'player' | 'tasks'>('player');
  const [movieTitle, setMovieTitle] = useState('រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)');
  const [genre, setGenre] = useState('ភ័យរន្ធត់ (Horror)');
  const [voice, setVoice] = useState('km-KH-PisethNeural');
  const [notes, setNotes] = useState('ដំណើររឿងកម្សត់ ការលះបង់របស់ឪពុក និងការប្រយុទ្ធទម្លុះហ្វូង Zombie');

  // Backend connection & tasks
  const [activeTaskId, setActiveTaskId] = useState<string>('d6c3b721');
  const [currentTask, setCurrentTask] = useState<RecapTask | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [allTasks, setAllTasks] = useState<RecapTask[]>([]);
  const [serverStatus, setServerStatus] = useState<'connected' | 'checking' | 'disconnected'>('checking');

  // Simulated Video & Audio Player
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);
  const [duration, setDuration] = useState(68); // seconds of sample
  const [isMuted, setIsMuted] = useState(false);
  const [activeBeatIndex, setActiveBeatIndex] = useState(0);

  // Flutter Code Explorer tab
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);

  // flutter pub get simulator & zip download state
  const [isPubGetting, setIsPubGetting] = useState(false);
  const [pubGetSuccess, setPubGetSuccess] = useState(true);
  const [pubGetLogs, setPubGetLogs] = useState<string[]>([
    '$ flutter pub get',
    'Resolving dependencies in khmer_movie_recap_app...',
    'Dependencies found in pubspec.yaml:',
    '  + http: ^1.2.0 (FastAPI Client)',
    '  + video_player: ^2.8.2 (Recap Video Player)',
    '  + audioplayers: ^6.0.0 (Edge-TTS Audio Player)',
    '  + cupertino_icons: ^1.0.6 (iOS Iconography)',
    '  + flutter_lints: ^3.0.0 (Code Health Rules)',
    '✔ All packages resolved and ready!',
  ]);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [isFlutterRunning, setIsFlutterRunning] = useState(false);

  // Audio element reference for real audio playback
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Check FastAPI connection and fetch existing tasks on mount
  useEffect(() => {
    checkServerAndFetchTasks();
  }, []);

  const checkServerAndFetchTasks = async () => {
    setServerStatus('checking');
    try {
      const res = await fetch('/api/recap/voices');
      if (res.ok) {
        setServerStatus('connected');
        // Check latest tasks
        const tasksRes = await fetch('/api/recap/tasks');
        if (tasksRes.ok) {
          const list: RecapTask[] = await tasksRes.json();
          setAllTasks(list);
          if (list.length > 0) {
            // Find completed task or pick first
            const comp = list.find((t) => t.status === 'completed') || list[0];
            setActiveTaskId(comp.task_id);
            setCurrentTask(comp);
          }
        }
      } else {
        setServerStatus('disconnected');
      }
    } catch {
      setServerStatus('disconnected');
    }
  };

  // Poll task status when generating
  useEffect(() => {
    if (!isGenerating && !activeTaskId) return;

    let interval: NodeJS.Timeout | null = null;

    const checkStatus = async () => {
      try {
        const res = await fetch(`/api/recap/status/${activeTaskId}`);
        if (res.ok) {
          const taskData: RecapTask = await res.json();
          setCurrentTask(taskData);

          if (taskData.status === 'completed') {
            setIsGenerating(false);
            setMobileTab('player');
            if (interval) clearInterval(interval);
            checkServerAndFetchTasks();
          } else if (taskData.status === 'failed') {
            setIsGenerating(false);
            if (interval) clearInterval(interval);
          }
        }
      } catch (e) {
        console.error('Status check error:', e);
      }
    };

    checkStatus();
    if (isGenerating) {
      interval = setInterval(checkStatus, 2000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeTaskId, isGenerating]);

  // Handle Play/Pause synchronization
  const togglePlay = () => {
    if (!isPlaying) {
      audioRef.current?.play().catch(() => {});
      videoRef.current?.play().catch(() => {});
      setIsPlaying(true);
    } else {
      audioRef.current?.pause();
      videoRef.current?.pause();
      setIsPlaying(false);
    }
  };

  // Sync audio time updates
  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const cur = audioRef.current.currentTime;
      setPlaybackTime(cur);
      if (audioRef.current.duration) {
        setDuration(audioRef.current.duration);
      }
      // Calculate active act / beat based on progress
      const pct = cur / (audioRef.current.duration || 68);
      const beatIdx = Math.min(4, Math.floor(pct * 5));
      setActiveBeatIndex(beatIdx);
    }
  };

  // Start new recap generation via FastAPI
  const handleStartGeneration = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/recap/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          movie_title: movieTitle,
          genre,
          voice,
          notes,
        }),
      });
      const data = await res.json();
      if (data.task_id) {
        setActiveTaskId(data.task_id);
      }
    } catch (e) {
      console.error(e);
      setIsGenerating(false);
    }
  };

  // Copy code helper
  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  // Run simulated flutter pub get
  const handleRunPubGet = async () => {
    setIsPubGetting(true);
    setPubGetSuccess(false);
    setPubGetLogs(['$ flutter pub get', 'Resolving dependencies in khmer_movie_recap_app...']);

    await new Promise((r) => setTimeout(r, 450));
    setPubGetLogs((prev) => [
      ...prev,
      'Downloading packages...',
      '  > http 1.2.0 (FastAPI Client API)',
      '  > video_player 2.8.2 (Video stream engine)',
    ]);

    await new Promise((r) => setTimeout(r, 450));
    setPubGetLogs((prev) => [
      ...prev,
      '  > audioplayers 6.0.0 (Khmer Edge-TTS MP3 audio)',
      '  > cupertino_icons 1.0.6 (iOS design icons)',
      '  > flutter_lints 3.0.0 (Lint rules)',
    ]);

    await new Promise((r) => setTimeout(r, 400));
    setPubGetLogs((prev) => [
      ...prev,
      'Changed 5 dependencies!',
      '✔ Dependencies are up to date! Ready for `flutter run`.',
    ]);
    setIsPubGetting(false);
    setPubGetSuccess(true);
  };

  // Run simulated flutter run
  const handleFlutterRun = async () => {
    setIsFlutterRunning(true);
    setPubGetLogs([
      '$ flutter run',
      'Launching lib/main.dart on Android Emulator / Physical Device...',
      'Running Gradle task "assembleDebug"...',
    ]);

    await new Promise((r) => setTimeout(r, 500));
    setPubGetLogs((prev) => [
      ...prev,
      '✓ Built build/app/outputs/flutter-apk/app-debug.apk (32.4MB)',
      'Installing app to connected device...',
      'Syncing files to device...',
    ]);

    await new Promise((r) => setTimeout(r, 500));
    setPubGetLogs((prev) => [
      ...prev,
      'Connected to the VM Service at ws://127.0.0.1:58921/ws',
      '🔥 Application running! Loading RecapPlayerScreen with Khmer Audio & Video...',
      'Flutter run key commands: [r] Hot reload, [R] Hot restart, [q] Quit',
      '✔ Flutter Client is LIVE and connected to FastAPI!',
    ]);
    setIsFlutterRunning(false);
    setMobileTab('player');
    setIsPlaying(true);
    if (audioRef.current) {
      audioRef.current.play().catch(() => {});
    }
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  // Download entire Flutter project as ZIP archive
  const handleDownloadFullZip = async () => {
    try {
      setIsDownloadingZip(true);
      const zip = new JSZip();

      FLUTTER_CODE_FILES.forEach((file) => {
        zip.file(file.filename, file.content);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'khmer_movie_recap_flutter_app.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip', err);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  // Parse 5-act text into studio script
  const handleImportToStudio = () => {
    if (!currentTask || !onLoadScriptToEditor) return;

    const scriptContent = currentTask.result?.script_content || '';
    const actParts = scriptContent.split(/## Act [I|V|X]+/);
    const acts = actParts.length > 1 ? actParts.slice(1) : [scriptContent];

    const newBeats: Beat[] = acts.map((content, idx) => {
      const lines = content.trim().split('\n').filter(Boolean);
      let scene = 'ទិដ្ឋភាពភាពយន្ត';
      let audio = 'សំឡេងផ្ទៃខាងក្រោយ';
      let narration = content.trim();
      let emotion = 'អារម្មណ៍តួអង្គ';

      lines.forEach((line) => {
        if (line.includes('[ឈុតឆាក:')) {
          scene = line.replace(/.*\[ឈុតឆាក:\s*/, '').replace(']', '');
        } else if (line.includes('[សំឡេងបន្លឺ:')) {
          audio = line.replace(/.*\[សំឡេងបន្លឺ:\s*/, '').replace(']', '');
        } else if (line.includes('[ពន្យល់សាច់រឿង]:')) {
          narration = line.replace(/.*\[ពន្យល់សាច់រឿង]:\s*/, '');
        } else if (line.includes('[អារម្មណ៍តួអង្គ:')) {
          emotion = line.replace(/.*\[អារម្មណ៍តួអង្គ:\s*/, '').replace(']', '');
        }
      });

      return {
        id: `beat-import-${Date.now()}-${idx}`,
        beatNumber: idx + 1,
        title: `Act ${['I', 'II', 'III', 'IV', 'V'][idx] || idx + 1}: ឈុតឆាកវគ្គទី ${idx + 1}`,
        timestamp: `${idx * 15}:00 - ${(idx + 1) * 15}:00`,
        sceneDescription: scene,
        audioCue: audio,
        narration: narration || content.slice(0, 300),
        characterEmotion: emotion,
      };
    });

    const newScript: RecapScript = {
      id: `script-fastapi-${currentTask.task_id}`,
      title: currentTask.movie_title,
      genre: 'ភ័យរន្ធត់ / សម្រាយរឿង 5 វគ្គ',
      synopsis: `ស្គ្រីបសម្រាយរឿង 5 Acts ផលិតចេញពី Movie Recap AI Engine (FastAPI & Gemini) សម្រាប់រឿង ${currentTask.movie_title}`,
      tone: 'ជក់ចិត្ត និងកម្សត់',
      pacing: 'លឿនល្មម (Fast & Dynamic)',
      estimatedDuration: '~15 នាទី',
      hookOpening: 'សួស្តីបងប្អូនទាំងអស់គ្នា! ថ្ងៃនេះយើងនឹងនាំអារម្មណ៍អ្នកទាំងអស់គ្នាមកទស្សនានូវរឿងដ៏អស្ចារ្យ...',
      beats: newBeats.length > 0 ? newBeats : [
        {
          id: 'beat-default',
          beatNumber: 1,
          title: 'Act I: បើកឆាក',
          timestamp: '00:00 - 05:00',
          sceneDescription: 'ទិដ្ឋភាពទូទៅនៃសាច់រឿង',
          audioCue: 'សំឡេងតន្ត្រីរំភើប',
          narration: scriptContent.slice(0, 500),
          characterEmotion: 'តានតឹង',
        },
      ],
      outroCallToAction: 'សូមអរគុណបងប្អូនទាំងអស់គ្នាសម្រាប់ការទស្សនា សូមជួយ Like និង Subscribe ដើម្បីតាមដានរឿងល្អៗជាបន្តទៀត!',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onLoadScriptToEditor(newScript);
  };

  const ACT_NAMES = [
    { name: 'Act I', label: 'ការណែនាំតួអង្គ & ឧប្បត្តិហេតុដំបូង (00-15mn)' },
    { name: 'Act II', label: 'ដំណើររឿងកាន់តែស្មុគស្មាញ & ឧបសគ្គធំៗ (15-45mn)' },
    { name: 'Act III', label: 'ចំណុចកណ្ដាលនៃការបែកបាក់ & អស់សង្ឃឹម (45-70mn)' },
    { name: 'Act IV', label: 'ចំណុចកំពូល Climax & ការប្រយុទ្ធចុងក្រោយ (70-85mn)' },
    { name: 'Act V', label: 'វគ្គបញ្ចប់ដ៏កម្សត់ & ទស្សនវិជ្ជាដាស់តឿន (85-90mn)' },
  ];

  return (
    <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* Top Banner: Ecosystem Overview */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-cyan-400 bg-cyan-400/10 px-3 py-1 rounded-full border border-cyan-400/20">
                <Smartphone className="w-3.5 h-3.5" />
                <span>FLUTTER MOBILE CLIENT + FASTAPI ENGINE</span>
              </span>
              <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  {serverStatus === 'connected'
                    ? 'FastAPI Engine: ដំណើរការប្រក្រតី (Port 8001 / Proxied)'
                    : 'កំពុងតភ្ជាប់ FastAPI Server...'}
                </span>
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              កម្មវិធីទូរស័ព្ទ Flutter & ប្រព័ន្ធសម្រាយរឿង Movie Recap AI
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              ភ្ជាប់រវាង <strong>FastAPI Backend</strong> (Chaining 5 Acts ជាមួយ Gemini AI & Microsoft Edge TTS)
              និង <strong>Flutter Mobile App</strong> ដោយប្រើប្រាស់កញ្ចប់ <code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">http</code>, <code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">video_player</code> និង <code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">audioplayers</code>។
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={checkServerAndFetchTasks}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>ពិនិត្យស្ថានភាព API</span>
            </button>
            <a
              href="/docs"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/30 transition-all"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>FastAPI Swagger Docs (/docs)</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Grid: Left is Phone Simulator, Right is Flutter Code Explorer & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: INTERACTIVE PHONE SIMULATOR (5 COLS) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full max-w-[390px]">
            {/* Phone Outer Shell */}
            <div className="relative bg-slate-950 border-[10px] border-slate-850 rounded-[52px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden ring-1 ring-slate-800 p-1">
              {/* Dynamic Island / Notch */}
              <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 w-28 h-6 bg-black rounded-full flex items-center justify-between px-3">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                <div className="w-2.5 h-2.5 rounded-full bg-blue-950/60 ring-1 ring-blue-500/30" />
              </div>

              {/* Screen Area */}
              <div className="bg-slate-900 rounded-[42px] overflow-hidden flex flex-col min-h-[680px] max-h-[720px] text-slate-100 relative">
                {/* Status Bar */}
                <div className="flex items-center justify-between px-7 pt-3.5 pb-2 text-[11px] font-semibold text-slate-300 bg-slate-950/90 z-20">
                  <span>9:41</span>
                  <div className="flex items-center gap-2">
                    <Wifi className="w-3 h-3" />
                    <span className="text-[10px] font-bold">5G</span>
                    <Battery className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                </div>

                {/* App Header inside Phone */}
                <div className="px-5 py-3 bg-slate-950 border-b border-slate-800/80 flex items-center justify-between z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center font-black text-slate-950 text-xs shadow-sm shadow-amber-500/30">
                      MR
                    </div>
                    <div>
                      <h2 className="text-xs font-bold leading-tight text-white">Khmer Recap AI</h2>
                      <p className="text-[10px] text-slate-400">FastAPI & Edge TTS</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
                    <button
                      onClick={() => setMobileTab('generator')}
                      className={`px-2 py-1 rounded text-[10px] font-medium transition-all ${
                        mobileTab === 'generator'
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      បង្កើតថ្មី
                    </button>
                    <button
                      onClick={() => setMobileTab('player')}
                      className={`px-2 py-1 rounded text-[10px] font-medium transition-all ${
                        mobileTab === 'player'
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      ចាក់ផ្សាយ
                    </button>
                    <button
                      onClick={() => setMobileTab('tasks')}
                      className={`px-2 py-1 rounded text-[10px] font-medium transition-all ${
                        mobileTab === 'tasks'
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      បញ្ជី ({allTasks.length})
                    </button>
                  </div>
                </div>

                {/* TAB 1: GENERATOR FORM */}
                {mobileTab === 'generator' && (
                  <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                        🎬 ជ្រើសរើសភាពយន្តសម្រាយ
                      </span>
                      <div className="grid grid-cols-1 gap-1.5 mt-1.5">
                        {PRESET_MOVIES.map((p) => (
                          <button
                            key={p.title}
                            onClick={() => {
                              setMovieTitle(p.title);
                              setGenre(p.genre);
                              setNotes(p.notes);
                            }}
                            className={`text-left p-2 rounded-xl border text-[11px] transition-all flex items-center justify-between ${
                              movieTitle === p.title
                                ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                                : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                            }`}
                          >
                            <span className="truncate">{p.title}</span>
                            <span className="text-[9px] text-slate-500 shrink-0 ml-1">
                              {p.genre}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-300">
                        ចំណងជើងរឿង (Movie Title)
                      </label>
                      <input
                        type="text"
                        value={movieTitle}
                        onChange={(e) => setMovieTitle(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        placeholder="បញ្ចូលចំណងជើងរឿង..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">ប្រភេទរឿង</label>
                        <select
                          value={genre}
                          onChange={(e) => setGenre(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-500"
                        >
                          <option value="ភ័យរន្ធត់ (Horror)">ភ័យរន្ធត់ (Horror)</option>
                          <option value="វិទ្យាសាស្ត្រ (Sci-Fi)">វិទ្យាសាស្ត្រ (Sci-Fi)</option>
                          <option value="វាយប្រហារ (Action)">វាយប្រហារ (Action)</option>
                          <option value="កម្សត់ & មនោសញ្ចេតនា">កម្សត់ & មនោសញ្ចេតនា</option>
                          <option value="អាថ៌កំបាំង (Mystery)">អាថ៌កំបាំង (Mystery)</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">
                          សំឡេងអាន Edge-TTS
                        </label>
                        <select
                          value={voice}
                          onChange={(e) => setVoice(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-500"
                        >
                          <option value="km-KH-PisethNeural">Piseth (ប្រុស)</option>
                          <option value="km-KH-SreymomNeural">Sreymom (ស្រី)</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-300">
                        កំណត់ចំណាំដឹកនាំ (Director Notes)
                      </label>
                      <textarea
                        rows={2}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-500 resize-none"
                        placeholder="កំណត់ចំណាំសង្ខេប..."
                      />
                    </div>

                    {/* Progress Bar during generation */}
                    {isGenerating && currentTask && (
                      <div className="bg-slate-950 border border-amber-500/40 rounded-xl p-3 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-amber-400 font-bold flex items-center gap-1.5">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            {currentTask.stage}
                          </span>
                          <span className="font-mono text-amber-300">{currentTask.progress}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-gradient-to-r from-amber-500 to-rose-500 h-full transition-all duration-300"
                            style={{ width: `${currentTask.progress}%` }}
                          />
                        </div>
                        <p className="text-[10px] text-slate-400">
                          Gemini Chaining 5 Acts & Microsoft Edge-TTS Synthesizer...
                        </p>
                      </div>
                    )}

                    <button
                      onClick={handleStartGeneration}
                      disabled={isGenerating || !movieTitle.trim()}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 disabled:opacity-50 flex items-center justify-center gap-2 transition-all"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>កំពុងដំណើរការតាម Chaining 5 Acts...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>បញ្ជាបង្កើត Script 5 វគ្គ & សំឡេង TTS</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                {/* TAB 2: SYNCHRONIZED PLAYER (VIDEO + AUDIO) */}
                {mobileTab === 'player' && (
                  <div className="flex-1 overflow-y-auto flex flex-col">
                    {/* Simulated video_player Canvas */}
                    <div className="relative aspect-video bg-black shrink-0 overflow-hidden group">
                      <video
                        ref={videoRef}
                        src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
                        className="w-full h-full object-cover"
                        loop
                        muted
                        playsInline
                      />

                      {/* Video Player Overlay HUD */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 flex flex-col justify-between p-3 pointer-events-none">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-white bg-black/60 px-2 py-0.5 rounded backdrop-blur">
                            {currentTask?.movie_title || movieTitle}
                          </span>
                          <span className="text-[9px] font-mono text-amber-400 bg-amber-950/70 border border-amber-500/40 px-1.5 py-0.5 rounded">
                            {ACT_NAMES[activeBeatIndex]?.name || 'Act I'}
                          </span>
                        </div>

                        {/* Subtitle Ticker in Video */}
                        <div className="text-center px-2">
                          <p className="text-[11px] font-bold text-amber-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] bg-black/70 px-2 py-1 rounded-lg backdrop-blur inline-block max-w-full truncate">
                            {ACT_NAMES[activeBeatIndex]?.label}
                          </p>
                        </div>
                      </div>

                      {/* Play overlay button if paused */}
                      {!isPlaying && (
                        <button
                          onClick={togglePlay}
                          className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-amber-500/90 text-slate-950 flex items-center justify-center shadow-lg shadow-black/80 hover:scale-110 transition-all pointer-events-auto"
                        >
                          <Play className="w-6 h-6 fill-current ml-0.5" />
                        </button>
                      )}
                    </div>

                    {/* Audio Player Bar (audioplayers package simulation) */}
                    <div className="bg-slate-950 p-3 border-b border-slate-800 space-y-2">
                      {/* Hidden HTML Audio element playing real Edge-TTS audio */}
                      <audio
                        ref={audioRef}
                        src={
                          currentTask?.result?.audio_url ||
                          currentTask?.result?.audioUrl ||
                          '/files/d6c3b721_audio.mp3'
                        }
                        onTimeUpdate={handleTimeUpdate}
                        onEnded={() => setIsPlaying(false)}
                        muted={isMuted}
                      />

                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span className="flex items-center gap-1 font-mono text-amber-400">
                          <Music className="w-3 h-3" />
                          <span>
                            {Math.floor(playbackTime / 60)}:
                            {Math.floor(playbackTime % 60)
                              .toString()
                              .padStart(2, '0')}
                          </span>
                        </span>
                        <span className="text-[9px] text-slate-400">
                          {currentTask?.result?.voice_used || 'Edge-TTS Khmer Voice'}
                        </span>
                        <span className="font-mono">
                          {Math.floor(duration / 60)}:
                          {Math.floor(duration % 60)
                            .toString()
                            .padStart(2, '0')}
                        </span>
                      </div>

                      {/* Seek scrubber */}
                      <div
                        className="w-full bg-slate-800 rounded-full h-1.5 cursor-pointer relative"
                        onClick={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const pos = (e.clientX - rect.left) / rect.width;
                          if (audioRef.current && duration) {
                            audioRef.current.currentTime = pos * duration;
                          }
                        }}
                      >
                        <div
                          className="bg-amber-400 h-full rounded-full transition-all"
                          style={{ width: `${(playbackTime / (duration || 1)) * 100}%` }}
                        />
                      </div>

                      {/* Controls row */}
                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => {
                            if (audioRef.current) audioRef.current.currentTime = 0;
                          }}
                          className="text-slate-400 hover:text-white p-1"
                          title="Restart"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={togglePlay}
                          className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center hover:bg-amber-400 transition-all font-bold shadow-md shadow-amber-500/20"
                        >
                          {isPlaying ? (
                            <Pause className="w-4 h-4 fill-current" />
                          ) : (
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          )}
                        </button>

                        <button
                          onClick={() => setIsMuted(!isMuted)}
                          className="text-slate-400 hover:text-white p-1"
                        >
                          {isMuted ? (
                            <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Script Reader Body */}
                    <div className="flex-1 p-3 space-y-2 text-xs overflow-y-auto">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                          📜 អត្ថបទអាន 5 វគ្គ (Script Beat)
                        </span>
                        {onLoadScriptToEditor && (
                          <button
                            onClick={handleImportToStudio}
                            className="text-[10px] text-amber-400 hover:text-amber-300 underline font-semibold"
                          >
                            បញ្ចូលទៅ Web Studio
                          </button>
                        )}
                      </div>

                      <div className="space-y-2">
                        {ACT_NAMES.map((act, idx) => (
                          <div
                            key={act.name}
                            onClick={() => {
                              setActiveBeatIndex(idx);
                              if (audioRef.current && duration) {
                                audioRef.current.currentTime = (idx / 5) * duration;
                              }
                            }}
                            className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                              activeBeatIndex === idx
                                ? 'bg-amber-500/10 border-amber-500/50 text-amber-100'
                                : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <div className="flex items-center justify-between text-[10px] font-bold text-amber-400 mb-1">
                              <span>{act.name}</span>
                              {activeBeatIndex === idx && (
                                <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-[9px] animate-pulse">
                                  កំពុងចាក់...
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] leading-relaxed line-clamp-2">{act.label}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: SAVED TASKS & FILES */}
                {mobileTab === 'tasks' && (
                  <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        បញ្ជី Recaps ក្នុង FastAPI
                      </span>
                      <button
                        onClick={checkServerAndFetchTasks}
                        className="text-[10px] text-amber-400 hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className="w-2.5 h-2.5" /> ផ្ទុកឡើងវិញ
                      </button>
                    </div>

                    {allTasks.length === 0 ? (
                      <div className="text-center py-10 text-slate-500">
                        មិនទាន់មាន Task ណាត្រូវបានបង្កើតនៅឡើយទេ។
                      </div>
                    ) : (
                      allTasks.map((t) => (
                        <div
                          key={t.task_id}
                          className={`p-3 rounded-xl border transition-all ${
                            activeTaskId === t.task_id
                              ? 'bg-amber-500/10 border-amber-500/50'
                              : 'bg-slate-950/70 border-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-white text-[11px] truncate max-w-[160px]">
                              {t.movie_title}
                            </span>
                            <span
                              className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                                t.status === 'completed'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-amber-500/20 text-amber-400'
                              }`}
                            >
                              {t.status}
                            </span>
                          </div>

                          <p className="text-[10px] text-slate-400 mb-2">{t.stage}</p>

                          <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                            <button
                              onClick={() => {
                                setActiveTaskId(t.task_id);
                                setCurrentTask(t);
                                setMobileTab('player');
                              }}
                              className="text-[10px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                            >
                              <Play className="w-3 h-3 fill-current" /> ចាក់ស្តាប់
                            </button>

                            {(t.result?.audio_url || t.result?.audioUrl) && (
                              <a
                                href={t.result?.audio_url || t.result?.audioUrl}
                                download
                                className="text-[10px] text-slate-300 hover:text-white flex items-center gap-1"
                              >
                                <Download className="w-3 h-3" /> MP3
                              </a>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* Bottom Home Indicator */}
                <div className="py-2 flex justify-center bg-slate-950">
                  <div className="w-32 h-1 bg-slate-700 rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: FLUTTER CODEBASE VIEWER & EXPORT (7 COLS) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Header Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                <FileCode className="w-4 h-4" />
                <span>FLUTTER SOURCE CODE (READY TO RUN)</span>
              </div>
              <p className="text-xs text-slate-300">
                កូដកម្មវិធីទូរស័ព្ទ Flutter ពេញលេញ សម្រាប់ដំណើរការលើ Android & iOS ជាមួយកញ្ចប់ dependencies ដែលអ្នកបានផ្ញើមក។
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={handleDownloadFullZip}
                disabled={isDownloadingZip}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-md shadow-blue-600/20 disabled:opacity-50"
              >
                {isDownloadingZip ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>ទាញយកគម្រោង (.ZIP)</span>
              </button>

              <button
                onClick={() =>
                  handleCopyCode(FLUTTER_CODE_FILES[selectedFileIdx].content)
                }
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-md shadow-amber-500/20"
              >
                {copiedFile ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-slate-950" />
                    <span>បានចម្លង!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>ចម្លងកូដឯកសារនេះ</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Interactive Flutter pub get & Dependencies Hub */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Dependencies & flutter pub get</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                      pubspec.yaml Verified
                    </span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    កញ្ចប់បណ្ណាល័យដែលបានកំណត់៖ http, video_player, audioplayers, cupertino_icons
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                <button
                  onClick={handleRunPubGet}
                  disabled={isPubGetting || isFlutterRunning}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 transition-all shadow-md disabled:opacity-50"
                  title="ទាញយក Dependencies ទាំងអស់"
                >
                  {isPubGetting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Terminal className="w-3.5 h-3.5" />
                  )}
                  <span>{isPubGetting ? 'កំពុងទាញយក...' : 'flutter pub get'}</span>
                </button>

                <button
                  onClick={handleFlutterRun}
                  disabled={isPubGetting || isFlutterRunning}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50"
                  title="ដំណើរការ Flutter App លើ Mobile Simulator"
                >
                  {isFlutterRunning ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-current" />
                  )}
                  <span>{isFlutterRunning ? 'កំពុងដំណើរការ...' : 'flutter run (ដំណើរការ App)'}</span>
                </button>
              </div>
            </div>

            {/* Packages badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-2.5">
                <div className="text-[11px] font-bold text-amber-400 font-mono">http: ^1.2.0</div>
                <div className="text-[10px] text-slate-400 mt-0.5">FastAPI REST Client</div>
              </div>
              <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-2.5">
                <div className="text-[11px] font-bold text-sky-400 font-mono">video_player: ^2.8.2</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Movie Stream Engine</div>
              </div>
              <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-2.5">
                <div className="text-[11px] font-bold text-emerald-400 font-mono">audioplayers: ^6.0.0</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Edge-TTS MP3 Audio</div>
              </div>
              <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-2.5">
                <div className="text-[11px] font-bold text-purple-400 font-mono">cupertino_icons: ^1.0.6</div>
                <div className="text-[10px] text-slate-400 mt-0.5">iOS System Icons</div>
              </div>
            </div>

            {/* Console Output Box */}
            <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 font-mono text-xs text-slate-300 space-y-1">
              <div className="flex items-center justify-between text-[10px] text-slate-500 pb-1 border-b border-slate-800">
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3 h-3 text-emerald-400" />
                  Terminal Output (flutter pub get)
                </span>
                {pubGetSuccess && (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Got dependencies!
                  </span>
                )}
              </div>
              <div className="pt-1 space-y-1 max-h-36 overflow-y-auto font-mono text-[11px] leading-relaxed">
                {pubGetLogs.map((log, i) => (
                  <div
                    key={i}
                    className={
                      log.startsWith('$')
                        ? 'text-amber-400 font-semibold'
                        : log.startsWith('✔')
                        ? 'text-emerald-400 font-semibold'
                        : log.startsWith('  >') || log.startsWith('  +')
                        ? 'text-sky-300'
                        : 'text-slate-400'
                    }
                  >
                    {log}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Code Tabs */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            {/* Tab Header */}
            <div className="flex items-center gap-1 bg-slate-950 p-2 border-b border-slate-800 overflow-x-auto">
              {FLUTTER_CODE_FILES.map((file, idx) => (
                <button
                  key={file.filename}
                  onClick={() => setSelectedFileIdx(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    selectedFileIdx === idx
                      ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-sm font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Code className="w-3 h-3" />
                  <span>{file.filename}</span>
                </button>
              ))}
            </div>

            {/* File info banner */}
            <div className="bg-slate-900/90 px-4 py-2.5 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-slate-200">
                {FLUTTER_CODE_FILES[selectedFileIdx].title}
              </span>
              <span className="text-[11px] text-slate-400">
                {FLUTTER_CODE_FILES[selectedFileIdx].description}
              </span>
            </div>

            {/* Code Box */}
            <div className="relative">
              <pre className="p-4 text-xs font-mono text-slate-200 bg-slate-950/80 overflow-x-auto max-h-[460px] leading-relaxed select-all">
                <code>{FLUTTER_CODE_FILES[selectedFileIdx].content}</code>
              </pre>
            </div>
          </div>

          {/* Quick Terminal Guide on How to Run Flutter App */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
              <Terminal className="w-4 h-4" />
              <span>របៀបដំណើរការកម្មវិធី FLUTTER លើកុំព្យូទ័ររបស់អ្នក</span>
            </div>

            <div className="bg-slate-950 rounded-xl p-3 text-xs font-mono text-slate-300 space-y-2 border border-slate-800">
              <div className="text-slate-500"># 1. បង្កើត Flutter project ថ្មី</div>
              <div className="text-amber-300">flutter create khmer_movie_recap_app</div>
              <div className="text-amber-300">cd khmer_movie_recap_app</div>

              <div className="text-slate-500 pt-2"># 2. ដំឡើង Dependencies ពី pubspec.yaml</div>
              <div className="text-amber-300">flutter pub get</div>

              <div className="text-slate-500 pt-2"># 3. បញ្ជាដំណើរការ Server FastAPI</div>
              <div className="text-emerald-300">uvicorn main:app --reload --host 0.0.0.0 --port 8000</div>

              <div className="text-slate-500 pt-2"># 4. ដំណើរការ Flutter App លើ Mobile ឬ Emulator</div>
              <div className="text-amber-300">flutter run</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
