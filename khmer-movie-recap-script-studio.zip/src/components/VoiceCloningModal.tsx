import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  Play,
  Square,
  Download,
  Copy,
  Check,
  Loader2,
  Sparkles,
  Volume2,
  Upload,
  Trash2,
  Radio,
  Sliders,
  ShieldCheck,
  FileAudio,
  Cpu,
  RefreshCw,
  Zap,
} from 'lucide-react';

export interface VoiceProfile {
  id: string;
  name: string;
  gender: string;
  description: string;
  sample_url?: string;
  similarity?: string;
  status?: string;
  created_at?: string;
}

interface VoiceCloningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVoiceForScript?: (voiceId: string) => void;
}

export const VoiceCloningModal: React.FC<VoiceCloningModalProps> = ({
  isOpen,
  onClose,
  onSelectVoiceForScript,
}) => {
  const [profiles, setProfiles] = useState<VoiceProfile[]>([]);
  const [isLoadingProfiles, setIsLoadingProfiles] = useState(false);
  const [selectedProfileId, setSelectedProfileId] = useState<string>('');
  
  // Create / Upload state
  const [profileName, setProfileName] = useState('សំឡេងសម្រាយរឿង Admin Pros');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [description, setDescription] = useState('សំឡេងចម្លងពីអ្នកសម្រាយរឿង 16kHz Denoised');
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string | null>(null);

  // Synthesize test state
  const [testText, setTestText] = useState(
    'សួស្តីបងប្អូនទាំងអស់គ្នា! ថ្ងៃនេះយើងនឹងនាំអារម្មណ៍អ្នកទាំងអស់គ្នាមកទស្សនានូវរឿងភាគភ័យរន្ធត់បំផុតប្រចាំឆ្នាំ ដែលមានឈុតឆាកតានតឹងនិងជក់ចិត្តដិតអារម្មណ៍ជាទីបំផុត។'
  );
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [synthAudioUrl, setSynthAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Audio player ref
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Code Tab state
  const [activeCodeTab, setActiveCodeTab] = useState<'python' | 'fastapi' | 'curl'>('python');
  const [copiedCode, setCopiedCode] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchProfiles();
    }
  }, [isOpen]);

  const fetchProfiles = async () => {
    setIsLoadingProfiles(true);
    try {
      const res = await fetch('/api/recap/clone-voice/profiles');
      if (res.ok) {
        const data = await res.json();
        if (data.profiles && Array.isArray(data.profiles)) {
          setProfiles(data.profiles);
          if (data.profiles.length > 0 && !selectedProfileId) {
            setSelectedProfileId(data.profiles[0].id);
          }
        }
      }
    } catch (e) {
      console.error('Failed to fetch voice profiles:', e);
    } finally {
      setIsLoadingProfiles(false);
    }
  };

  if (!isOpen) return null;

  const handleUploadNewProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileToUpload) {
      setErrorMsg('សូមជ្រើសរើសឯកសារសំឡេងគំរូ (10s - 30s MP3/WAV/M4A)');
      return;
    }

    setIsUploading(true);
    setErrorMsg(null);
    setUploadSuccessMsg(null);

    const formData = new FormData();
    formData.append('file', fileToUpload);
    formData.append('profile_name', profileName);
    formData.append('gender', gender);
    formData.append('description', description);

    try {
      const res = await fetch('/api/recap/clone-voice/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setUploadSuccessMsg(data.message || 'បានបង្កើត Voice Profile ជោគជ័យ!');
        setFileToUpload(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        fetchProfiles();
        if (data.profile) {
          setSelectedProfileId(data.profile.id);
        }
      } else {
        setErrorMsg(data.detail || data.error || 'បរាជ័យក្នុងការបង្កើត Voice Profile');
      }
    } catch (err: any) {
      setErrorMsg('កំហុសតភ្ជាប់ API: ' + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteProfile = async (id: string, name: string) => {
    if (!window.confirm(`តើអ្នកពិតជាចង់លុប Voice Profile [${name}] នេះមែនទេ?`)) return;
    try {
      const res = await fetch(`/api/recap/clone-voice/profiles/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        fetchProfiles();
        if (selectedProfileId === id) {
          setSelectedProfileId('');
        }
      }
    } catch (err: any) {
      alert('កំហុសលុប Profile: ' + err.message);
    }
  };

  const handleSynthesizeTest = async () => {
    if (!testText.trim()) {
      setErrorMsg('សូមបញ្ចូលអត្ថបទខ្មែរសម្រាប់សាកល្បង');
      return;
    }
    if (!selectedProfileId) {
      setErrorMsg('សូមជ្រើសរើស Voice Profile');
      return;
    }

    setIsSynthesizing(true);
    setErrorMsg(null);
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }

    try {
      const res = await fetch('/api/recap/clone-voice/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: testText,
          profile_id: selectedProfileId,
        }),
      });

      const data = await res.json();
      if (res.ok && data.audio_url) {
        setSynthAudioUrl(data.audio_url);
        // auto play
        setTimeout(() => {
          if (audioRef.current) {
            audioRef.current.play();
            setIsPlaying(true);
          }
        }, 300);
      } else {
        setErrorMsg(data.detail || data.error || 'បរាជ័យក្នុងការសំយោគសំឡេង');
      }
    } catch (err: any) {
      setErrorMsg('កំហុសតភ្ជាប់ API: ' + err.message);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const togglePlayAudio = () => {
    if (!audioRef.current || !synthAudioUrl) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const selectedProfile = profiles.find((p) => p.id === selectedProfileId);

  const pythonCode = `# ==============================================================================
# ប្រព័ន្ធចម្លងសំឡេងមនុស្សពិតសម្រាប់សម្រាយរឿង (AI Voice Cloning Engine)
# បច្ចេកវិទ្យា៖ Zero-Shot Voice Cloning (F5-TTS / XTTS-v2 / ElevenLabs API)
# ==============================================================================

import asyncio
from voice_cloner import voice_cloner

async def run_voice_clone_demo():
    # 1. ដំណើរការ FFmpeg Denoise & Clean លើឯកសារសំឡេងគំរូ 10s-30s
    profile_id = voice_cloner.process_and_clean_sample(
        input_audio_path="my_recapper_sample.wav",
        profile_name="${profileName}",
        gender="${gender}",
        description="${description}"
    )
    
    # 2. បម្លែងអត្ថបទសម្រាយរឿងជាភាសាខ្មែរទៅជាសំឡេង
    output_audio = await voice_cloner.synthesize_with_cloned_voice(
        text="""${testText.replace(/"/g, '\\"')}""",
        profile_id=profile_id,
        output_filepath="cloned_output.mp3"
    )
    print(f"✅ បានបង្កើតសំឡេង Cloned ជោគជ័យ៖ {output_audio}")

if __name__ == "__main__":
    asyncio.run(run_voice_clone_demo())
`;

  const fastapiCode = `from fastapi import FastAPI, UploadFile, File, Form
from voice_cloner import voice_cloner

app = FastAPI(title="Khmer Zero-Shot Voice Cloning API")

@app.post("/clone-voice/upload")
async def upload_sample(file: UploadFile = File(...), name: str = Form(...)):
    profile_id = voice_cloner.process_and_clean_sample(file.filename, name)
    return {"profile_id": profile_id, "status": "ready"}

@app.post("/clone-voice/synthesize")
async def synthesize(text: str, profile_id: str):
    output_path = "output_recaper.mp3"
    await voice_cloner.synthesize_with_cloned_voice(text, profile_id, output_path)
    return {"audio_path": output_path}
`;

  const curlCode = `# 1. Upload sample reference audio (10s - 30s)
curl -X POST "http://localhost:8001/api/recap/clone-voice/upload" \\
  -F "file=@my_recapper_sample.wav" \\
  -F "profile_name=${profileName}" \\
  -F "gender=${gender}"

# 2. Test Synthesize Khmer Text with Cloned Voice
curl -X POST "http://localhost:8001/api/recap/clone-voice/synthesize" \\
  -H "Content-Type: application/json" \\
  -d '{"text": "${testText}", "profile_id": "${selectedProfileId || 'voice_starter_pro'}"}'
`;

  const getActiveCode = () => {
    if (activeCodeTab === 'python') return pythonCode;
    if (activeCodeTab === 'fastapi') return fastapiCode;
    return curlCode;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(getActiveCode());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-8 flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-400/10 px-2.5 py-0.5 rounded-full border border-purple-400/20">
                  Zero-Shot AI Engine
                </span>
                <span className="text-xs text-slate-400 hidden sm:inline">
                  F5-TTS / XTTS-v2 / ElevenLabs API
                </span>
              </div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                ស្ទូឌីយោចម្លងសំឡេងមនុស្សពិត (AI Voice Cloning Studio)
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body - Scrollable */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {errorMsg && (
            <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 px-4 py-3 rounded-2xl text-xs flex items-center justify-between">
              <span>{errorMsg}</span>
              <button onClick={() => setErrorMsg(null)} className="underline ml-2">
                បិទ
              </button>
            </div>
          )}

          {uploadSuccessMsg && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 px-4 py-3 rounded-2xl text-xs flex items-center justify-between">
              <span>{uploadSuccessMsg}</span>
              <button onClick={() => setUploadSuccessMsg(null)} className="underline ml-2">
                បិទ
              </button>
            </div>
          )}

          {/* Grid Layout: Left Profiles & Upload, Right Test Synthesizer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* LEFT COLUMN: Speaker Profiles & Upload (5 Cols) */}
            <div className="lg:col-span-5 space-y-6">
              {/* Existing Voice Profiles */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                    <Radio className="w-4 h-4 text-purple-400" />
                    បញ្ជី Voice Profiles ({profiles.length})
                  </h3>
                  <button
                    onClick={fetchProfiles}
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
                    title="ធ្វើបច្ចុប្បន្នភាពបញ្ជី"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingProfiles ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {isLoadingProfiles ? (
                  <div className="py-8 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                    កំពុងទាញយក Profile...
                  </div>
                ) : profiles.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    មិនទាន់មាន Cloned Voice Profile ឡើយ។ សូម Upload សំឡេងខាងក្រោម!
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                    {profiles.map((p) => {
                      const isSelected = selectedProfileId === p.id;
                      return (
                        <div
                          key={p.id}
                          onClick={() => setSelectedProfileId(p.id)}
                          className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between gap-3 ${
                            isSelected
                              ? 'bg-purple-500/10 border-purple-500/50 text-purple-200'
                              : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs truncate">{p.name}</span>
                              <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                                {p.gender === 'female' ? 'ស្រី' : 'ប្រុស'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 truncate mt-0.5">
                              {p.description}
                            </p>
                            {p.similarity && (
                              <div className="mt-1 flex items-center gap-2 text-[10px] text-emerald-400">
                                <ShieldCheck className="w-3 h-3" />
                                <span>ភាពដូចគ្នា (Similarity): {p.similarity}</span>
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {p.sample_url && (
                              <a
                                href={p.sample_url}
                                target="_blank"
                                rel="noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="p-1.5 text-slate-400 hover:text-purple-300 hover:bg-slate-800 rounded-lg transition-colors"
                                title="ស្តាប់សំឡេង Reference 16kHz"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </a>
                            )}

                            {p.id !== 'voice_starter_pro' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteProfile(p.id, p.name);
                                }}
                                className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                                title="លុប Profile"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {selectedProfileId && onSelectVoiceForScript && (
                  <button
                    onClick={() => {
                      onSelectVoiceForScript(selectedProfileId);
                      onClose();
                    }}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    ជ្រើសរើសសំឡេង [{selectedProfile?.name}] សម្រាប់ Script
                  </button>
                )}
              </div>

              {/* Upload New Reference Audio Form */}
              <form
                onSubmit={handleUploadNewProfile}
                className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-3"
              >
                <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <Upload className="w-4 h-4 text-purple-400" />
                  បង្កើត Voice Profile ថ្មី (Clone Sample 10s - 30s)
                </h3>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    ឈ្មោះ Speaker Profile
                  </label>
                  <input
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                    placeholder="ឧ. សំឡេង Admin Pros (Movie Recapper)"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                      ភេទ (Gender)
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as 'male' | 'female')}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                    >
                      <option value="male">ប្រុស (Male)</option>
                      <option value="female">ស្រី (Female)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                      កំណត់សម្គាល់
                    </label>
                    <input
                      type="text"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                      placeholder="ឧ. 16kHz Mono Denoised"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    ជ្រើសរើសឯកសារសំឡេងគំរូ (.MP3 / .WAV / .M4A)
                  </label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*"
                    onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                    className="w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-purple-500/10 file:text-purple-300 hover:file:bg-purple-500/20"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    * ប្រព័ន្ធនឹងប្រើ FFmpeg ដើម្បី Denoise (highpass/lowpass/afftdn) និង Convert ទៅជា 16kHz Mono WAV ស្វ័យប្រវត្តិ។
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isUploading || !fileToUpload}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      កំពុង Processing & Denoising...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      បង្កើត Cloned Voice Profile ឥឡូវនេះ
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* RIGHT COLUMN: Test Synthesizer & Code Explorer (7 Cols) */}
            <div className="lg:col-span-7 space-y-6">
              {/* Test Voice Synthesizer */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                    <Mic className="w-4 h-4 text-purple-400" />
                    សាកល្បងអានអត្ថបទជាមួយ Cloned Voice Selected
                  </h3>
                  {selectedProfile && (
                    <span className="text-xs bg-purple-500/10 text-purple-300 border border-purple-500/20 px-2.5 py-0.5 rounded-full font-medium">
                      {selectedProfile.name}
                    </span>
                  )}
                </div>

                <div>
                  <textarea
                    rows={4}
                    value={testText}
                    onChange={(e) => setTestText(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 leading-relaxed"
                    placeholder="បញ្ចូលអត្ថបទខ្មែរសម្រាប់ឱ្យ AI អានបញ្ចូលសំឡេង..."
                  />
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <button
                    onClick={handleSynthesizeTest}
                    disabled={isSynthesizing || !selectedProfileId}
                    className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    {isSynthesizing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        កំពុងសំយោគសំឡេង Zero-Shot...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 text-amber-300" />
                        បម្លែងជាសំឡេង Cloned MP3
                      </>
                    )}
                  </button>

                  {synthAudioUrl && (
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <button
                        onClick={togglePlayAudio}
                        className="px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center gap-2"
                      >
                        {isPlaying ? (
                          <>
                            <Square className="w-3.5 h-3.5 fill-current" />
                            ផ្អាក (Pause)
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5 fill-current" />
                            ស្ដាប់សំឡេង (Play)
                          </>
                        )}
                      </button>

                      <a
                        href={synthAudioUrl}
                        download="cloned_recaper_voice.mp3"
                        className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold"
                        title="ទាញយក MP3"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                    </div>
                  )}
                </div>

                <audio
                  ref={audioRef}
                  src={synthAudioUrl || undefined}
                  onEnded={() => setIsPlaying(false)}
                  className="hidden"
                />
              </div>

              {/* Code Integration Explorer */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                    <FileAudio className="w-4 h-4 text-indigo-400" />
                    កូដសមាសភាគ (Code Integration Guide)
                  </h3>

                  <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => setActiveCodeTab('python')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                        activeCodeTab === 'python'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      voice_cloner.py
                    </button>
                    <button
                      onClick={() => setActiveCodeTab('fastapi')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                        activeCodeTab === 'fastapi'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      FastAPI Route
                    </button>
                    <button
                      onClick={() => setActiveCodeTab('curl')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                        activeCodeTab === 'curl'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      cURL API
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <pre className="bg-slate-950 text-slate-300 p-3.5 rounded-xl text-[11px] font-mono overflow-x-auto border border-slate-800/80 max-h-[180px] leading-relaxed">
                    <code>{getActiveCode()}</code>
                  </pre>

                  <button
                    onClick={handleCopyCode}
                    className="absolute top-2.5 right-2.5 p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg text-xs flex items-center gap-1 backdrop-blur-sm transition-colors"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-[10px]">បានចម្លង</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[10px]">ចម្លងកូដ</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ប្រព័ន្ធ Denoise 16kHz Mono ធានាទឹកដមសំឡេងខ្មែរច្បាស់ល្អ គ្មានសំឡេងរំខាន
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl transition-colors"
          >
            បិទ
          </button>
        </div>
      </div>
    </div>
  );
};
