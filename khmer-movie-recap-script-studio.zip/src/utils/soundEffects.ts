// Synthesized Web Audio API sound effects for movie recap audio cues

class RecapSoundEffects {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // 1. Cinematic Sub Bass Drop / Boom (សំឡេងបាសបន្លឺធ្ងន់)
  playCinematicBoom() {
    const ctx = this.getContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(130, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 1.2);

    gain.gain.setValueAtTime(0.8, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 1.5);
  }

  // 2. Suspense Heartbeat (សំឡេងបេះដូងលោតញាប់)
  playHeartbeat() {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    const playThump = (time: number, freq: number, vol: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, time);
      osc.frequency.exponentialRampToValueAtTime(25, time + 0.15);

      gain.gain.setValueAtTime(vol, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(time);
      osc.stop(time + 0.2);
    };

    // Lub-dub
    playThump(now, 85, 0.9);
    playThump(now + 0.22, 65, 0.7);
  }

  // 3. Tension Riser (សំឡេងតានតឹងឡើងខ្ពស់)
  playTensionRiser() {
    const ctx = this.getContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(750, ctx.currentTime + 2.0);

    // Filter to soften the harsh sawtooth
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(250, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(2400, ctx.currentTime + 2.0);

    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.4, ctx.currentTime + 1.8);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.2);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 2.2);
  }

  // 4. Jump Scare Screech / Stinger (សំឡេងកន្ត្រាក់អារម្មណ៍)
  playJumpScareStinger() {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    // High discordant cluster
    [480, 520, 680, 920].forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.7, now + 0.8);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.9);
    });

    // Sub thump impact underneath
    this.playCinematicBoom();
  }

  // 5. Eerie Ambient Drone (សំឡេងបរិយាកាសព្រឺរោម)
  playEerieDrone() {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(55, now); // A1 note
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(57, now); // slight beat frequency dissonance

    gain.gain.setValueAtTime(0.01, now);
    gain.gain.linearRampToValueAtTime(0.35, now + 0.8);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 3.5);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 3.5);
    osc2.stop(now + 3.5);
  }

  // 6. Metal Impact / Door Slam (សំឡេងទះទ្វារ / ដែកកកិត)
  playMetalDoorImpact() {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.4);

    gain.gain.setValueAtTime(0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.5);
  }
}

export const sfx = new RecapSoundEffects();

export const SFX_PRESETS = [
  {
    id: 'cinematic_boom',
    name: 'Cinematic Sub Boom',
    nameKh: 'សំឡេងបាសបន្លឺធ្ងន់',
    description: 'បាសធ្លាក់ចុះយ៉ាងធ្ងន់ សម្រាប់ឈុតឆាករបត់សំខាន់',
    play: () => sfx.playCinematicBoom(),
    icon: 'Activity',
    color: 'from-amber-600 to-red-600',
  },
  {
    id: 'heartbeat',
    name: 'Heartbeat Thump',
    nameKh: 'សំឡេងបេះដូងលោត',
    description: 'សំឡេងបេះដូងលោតដង្ហក់ សម្រាប់ឈុតឆាកតានតឹងភ័យខ្លាច',
    play: () => sfx.playHeartbeat(),
    icon: 'Heart',
    color: 'from-rose-600 to-pink-600',
  },
  {
    id: 'tension_riser',
    name: 'Tension Riser',
    nameKh: 'សំឡេងតានតឹងឡើងខ្ពស់',
    description: 'សូរសំឡេងកើនកម្ដៅឡើងខ្ពស់បន្តិចម្តងៗ មុនពេលមានរឿងកើតឡើង',
    play: () => sfx.playTensionRiser(),
    icon: 'TrendingUp',
    color: 'from-purple-600 to-indigo-600',
  },
  {
    id: 'jump_scare',
    name: 'Jump Scare Stinger',
    nameKh: 'សំឡេងកន្ត្រាក់អារម្មណ៍',
    description: 'សំឡេងកន្ត្រាក់ស្រួចខ្លាំង ពេលខ្មោចលេច ឬគ្រោះថ្នាក់ភ្លាមៗ',
    play: () => sfx.playJumpScareStinger(),
    icon: 'Zap',
    color: 'from-red-600 to-orange-600',
  },
  {
    id: 'eerie_drone',
    name: 'Eerie Ghost Drone',
    nameKh: 'សំឡេងបរិយាកាសព្រឺរោម',
    description: 'សំឡេងរណ្តំអាថ៌កំបាំងត្រជាក់ស្រឹប កណ្តាលផ្ទះងងឹត',
    play: () => sfx.playEerieDrone(),
    icon: 'Radio',
    color: 'from-cyan-600 to-blue-600',
  },
  {
    id: 'metal_impact',
    name: 'Door Slam / Metal Clang',
    nameKh: 'សំឡេងទះទ្វារ / ដែកកកិត',
    description: 'សំឡេងទ្វារបិទគាំង ឬដែកជណ្តើរយន្តកកិត',
    play: () => sfx.playMetalDoorImpact(),
    icon: 'Volume2',
    color: 'from-slate-600 to-zinc-600',
  },
];
