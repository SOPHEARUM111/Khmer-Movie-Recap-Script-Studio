import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import '../models/recap_task.dart';

class RecapPlayerScreen extends StatefulWidget {
  final RecapTask task;
  final String serverBaseUrl;

  const RecapPlayerScreen({
    Key? key,
    required this.task,
    required this.serverBaseUrl,
  }) : super(key: key);

  @override
  State<RecapPlayerScreen> createState() => _RecapPlayerScreenState();
}

class _RecapPlayerScreenState extends State<RecapPlayerScreen> {
  late VideoPlayerController _videoController;
  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;

  @override
  void initState() {
    super.initState();
    _initMedia();
  }

  void _initMedia() {
    // 1. Initializing Video Player with sample clip
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'),
    )..initialize().then((_) {
        setState(() {});
      });

    // 2. Initializing Audio Player with Khmer Edge-TTS voice
    _audioPlayer = AudioPlayer();
    final audioUrl = widget.task.result?.audioUrl ?? '';
    final fullAudioUrl = audioUrl.startsWith('http')
        ? audioUrl
        : '${widget.serverBaseUrl}$audioUrl';

    if (audioUrl.isNotEmpty) {
      _audioPlayer.setSourceUrl(fullAudioUrl);
    }

    _audioPlayer.onPositionChanged.listen((p) {
      setState(() {
        _currentPosition = p;
      });
    });

    _audioPlayer.onDurationChanged.listen((d) {
      setState(() {
        _totalDuration = d;
      });
    });
  }

  void _togglePlayPause() {
    setState(() {
      if (_isPlaying) {
        _videoController.pause();
        _audioPlayer.pause();
        _isPlaying = false;
      } else {
        _videoController.play();
        _audioPlayer.resume();
        _isPlaying = true;
      }
    });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        title: Text(widget.task.movieTitle, style: const TextStyle(fontSize: 16)),
      ),
      body: Column(
        children: [
          // ផ្នែកទី១: ផ្ទាំងចាក់វីដេអូ
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Container(
              color: Colors.black,
              child: _videoController.value.isInitialized
                  ? VideoPlayer(_videoController)
                  : const Center(child: CircularProgressIndicator()),
            ),
          ),

          // ផ្នែកទី២: ប៊ូតុងបញ្ជាចាក់វីដេអូ និងសំឡេង (Sync Audio + Video)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: const Color(0xFF1E293B),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(_isPlaying ? Icons.pause_circle : Icons.play_circle, color: Colors.amber, size: 36),
                  onPressed: _togglePlayPause,
                ),
                Text(
                  '${_currentPosition.inMinutes}:${(_currentPosition.inSeconds % 60).toString().padLeft(2, '0')} / ${_totalDuration.inMinutes}:${(_totalDuration.inSeconds % 60).toString().padLeft(2, '0')}',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const Spacer(),
                const Icon(Icons.volume_up, color: Colors.amber, size: 20),
                const SizedBox(width: 8),
                const Text('Edge-TTS Khmer', style: TextStyle(color: Colors.white60, fontSize: 12)),
              ],
            ),
          ),

          // ផ្នែកទី៣: Script អត្ថបទអាន 5 Acts
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(16),
              ),
              child: SingleChildScrollView(
                child: Text(
                  widget.task.result?.scriptContent ?? 'គ្មានអត្ថបទ',
                  style: const TextStyle(color: Colors.white70, height: 1.6, fontSize: 14),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
