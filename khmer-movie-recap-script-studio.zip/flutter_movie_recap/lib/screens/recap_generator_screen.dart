import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/recap_task.dart';
import 'recap_player_screen.dart';

class RecapGeneratorScreen extends StatefulWidget {
  const RecapGeneratorScreen({Key? key}) : super(key: key);

  @override
  State<RecapGeneratorScreen> createState() => _RecapGeneratorScreenState();
}

class _RecapGeneratorScreenState extends State<RecapGeneratorScreen> {
  final _apiService = RecapApiService();
  final _titleController = TextEditingController(text: 'រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)');
  final _notesController = TextEditingController(text: 'ដំណើររឿងកម្សត់ ការលះបង់របស់ឪពុក និងការប្រយុទ្ធទម្លុះហ្វូង Zombie');

  String _selectedGenre = 'ភ័យរន្ធត់ (Horror)';
  String _selectedVoice = 'km-KH-PisethNeural';
  bool _isLoading = false;
  String? _currentTaskId;
  RecapTask? _taskData;

  final List<String> _genres = [
    'ភ័យរន្ធត់ (Horror)',
    'សកម្មភាព (Action)',
    'វិទ្យាសាស្ត្រ (Sci-Fi)',
    'មនោសញ្ចេតនា (Drama)',
    'ស៊ើបអង្កេត (Mystery)',
  ];

  final List<Map<String, String>> _voices = [
    {'id': 'km-KH-PisethNeural', 'name': 'សំឡេងពិសិដ្ឋ (ប្រុស - រំជួលចិត្ត)'},
    {'id': 'km-KH-SreymomNeural', 'name': 'សំឡេងស្រីមុំ (ស្រី - ស្រទន់ច្បាស់)'},
  ];

  void _generateRecap() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final taskId = await _apiService.createRecapTask(
        movieTitle: _titleController.text.trim(),
        genre: _selectedGenre,
        voice: _selectedVoice,
        notes: _notesController.text.trim(),
      );

      setState(() {
        _currentTaskId = taskId;
      });

      // Poll task status
      _pollStatus(taskId);
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('កំហុស៖ ${e.toString()}')),
      );
    }
  }

  void _pollStatus(String taskId) async {
    while (_isLoading) {
      await Future.delayed(const Duration(seconds: 3));
      try {
        final task = await _apiService.getTaskStatus(taskId);
        setState(() {
          _taskData = task;
        });

        if (task.isCompleted) {
          setState(() {
            _isLoading = false;
          });
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RecapPlayerScreen(
                task: task,
                serverBaseUrl: _apiService.baseUrl,
              ),
            ),
          );
          break;
        } else if (task.isFailed) {
          setState(() {
            _isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('ដំណើរការបរាជ័យ៖ ${task.error}')),
          );
          break;
        }
      } catch (_) {
        // Retry
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🎬 Khmer Movie Recap AI'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'ចំណងជើងរឿង (Movie Title)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedGenre,
              decoration: const InputDecoration(
                labelText: 'ប្រភេទរឿង (Genre)',
                border: OutlineInputBorder(),
              ),
              items: _genres.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
              onChanged: (val) => setState(() => _selectedGenre = val!),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedVoice,
              decoration: const InputDecoration(
                labelText: 'សំឡេងអាន Khmer Edge-TTS',
                border: OutlineInputBorder(),
              ),
              items: _voices.map((v) => DropdownMenuItem(value: v['id'], child: Text(v['name']!))).toList(),
              onChanged: (val) => setState(() => _selectedVoice = val!),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _notesController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'ចំណុចសំខាន់ៗនៃសាច់រឿង',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _generateRecap,
              icon: _isLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_awesome),
              label: Text(_isLoading ? 'កំពុងបង្កើត 5 Acts... (${_taskData?.progress ?? 0}%)' : '🚀 ចាប់ផ្តើមបង្កើត Script & Audio'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
