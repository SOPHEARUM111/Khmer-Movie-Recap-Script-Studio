import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/recap_task.dart';

class RecapApiService {
  // អាសយដ្ឋាន Server FastAPI (នៅលើទូរស័ព្ទពិតប្រើ IP ម៉ាស៊ីន local ឬ 10.0.2.2 លើ Android Emulator)
  final String baseUrl;

  RecapApiService({this.baseUrl = 'http://10.0.2.2:8001'});

  /// បញ្ជាបង្កើត Script សម្រាយរឿង 5 វគ្គ និងសំឡេង Edge-TTS
  Future<String> createRecapTask({
    required String movieTitle,
    String genre = 'ភ័យរន្ធត់ (Horror)',
    String voice = 'km-KH-PisethNeural',
    String notes = '',
  }) async {
    final url = Uri.parse('$baseUrl/api/recap/generate');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'movie_title': movieTitle,
        'genre': genre,
        'voice': voice,
        'notes': notes,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['task_id'] as String;
    } else {
      throw Exception('បរាជ័យក្នុងការបង្កើត Task: ${response.statusCode}');
    }
  }

  /// ពិនិត្យមើលស្ថានភាព និង Progress Bar
  Future<RecapTask> getTaskStatus(String taskId) async {
    final url = Uri.parse('$baseUrl/api/recap/status/$taskId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return RecapTask.fromJson(data);
    } else {
      throw Exception('រកមិនឃើញ Task ID នេះឡើយ');
    }
  }

  /// ទាញយកបញ្ជី Task ទាំងអស់
  Future<List<RecapTask>> getAllTasks() async {
    final url = Uri.parse('$baseUrl/api/recap/tasks');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final List data = jsonDecode(utf8.decode(response.bodyBytes));
      return data.map((item) => RecapTask.fromJson(item)).toList();
    } else {
      return [];
    }
  }
}
