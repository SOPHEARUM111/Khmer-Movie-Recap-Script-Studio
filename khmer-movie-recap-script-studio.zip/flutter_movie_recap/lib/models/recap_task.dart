class RecapTask {
  final String taskId;
  final String movieTitle;
  final String status;
  final int progress;
  final String stage;
  final RecapResult? result;
  final String? error;

  RecapTask({
    required this.taskId,
    required this.movieTitle,
    required this.status,
    required this.progress,
    required this.stage,
    this.result,
    this.error,
  });

  factory RecapTask.fromJson(Map<String, dynamic> json) {
    return RecapTask(
      taskId: json['task_id'] ?? '',
      movieTitle: json['movie_title'] ?? '',
      status: json['status'] ?? 'pending',
      progress: json['progress'] ?? 0,
      stage: json['stage'] ?? '',
      result: json['result'] != null ? RecapResult.fromJson(json['result']) : null,
      error: json['error'],
    );
  }

  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
}

class RecapResult {
  final String scriptUrl;
  final String audioUrl;
  final int wordCount;
  final String? scriptContent;

  RecapResult({
    required this.scriptUrl,
    required this.audioUrl,
    required this.wordCount,
    this.scriptContent,
  });

  factory RecapResult.fromJson(Map<String, dynamic> json) {
    return RecapResult(
      scriptUrl: json['script_url'] ?? '',
      audioUrl: json['audio_url'] ?? '',
      wordCount: json['word_count'] ?? 0,
      scriptContent: json['script_content'],
    );
  }
}
