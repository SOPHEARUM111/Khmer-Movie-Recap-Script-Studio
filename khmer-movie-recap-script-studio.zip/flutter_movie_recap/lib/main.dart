// ==============================================================================
// កម្មវិធីទូរស័ព្ទ AI Movie Recap Studio (Flutter Android & iOS)
// គាំទ្រ៖ Script 90 នាទី, សំឡេងកូនក្មេង/មនុស្សចាស់, Storyboard និង Video Player
// ==============================================================================

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ------------------------------------------------------------------------------
// ១. ការកំណត់រចនាសម្ព័ន្ធ API (Server Endpoint)
// ------------------------------------------------------------------------------
// ផ្លាស់ប្តូរ IP នេះទៅតាម IP របស់កុំព្យូទ័រ/Server របស់អ្នក (ឧទាហរណ៍៖ http://192.168.1.5:8000 ឬ 8001)
const String kBackendBaseUrl = "http://10.0.2.2:8001"; // 10.0.2.2 សម្រាប់ Android Emulator

void main() {
  runApp(const MovieRecapApp());
}

class MovieRecapApp extends StatelessWidget {
  const MovieRecapApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Movie Recap Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07090E),
        primaryColor: const Color(0xFFE11D48),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE11D48),
          secondary: Color(0xFFF59E0B),
          surface: Color(0xFF111827),
        ),
        textTheme: const TextTheme(
          bodyMedium: TextStyle(fontFamily: 'sans-serif', color: Color(0xFFE2E8F0)),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

// ------------------------------------------------------------------------------
// ២. អេក្រង់ដើម (Home Screen) - បញ្ចូលឈ្មោះរឿង, ជ្រើសរើសសំឡេង និងរយៈពេល
// ------------------------------------------------------------------------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _titleController = TextEditingController(text: "រថភ្លើងទៅកាន់ប៊ូសាន (Train to Busan)");
  final TextEditingController _notesController = TextEditingController(text: "ដំណើររឿងកម្សត់ ការលះបង់របស់ឪពុក និងការប្រយុទ្ធទម្លុះហ្វូង Zombie");

  int _selectedDuration = 90;
  String _selectedGenre = "រន្ធត់ / ខ្មោចឆៅ (Horror)";
  bool _enableChildVoice = true;
  bool _enableElderlyVoice = true;
  bool _isSubmitting = false;

  bool _useClonedVoice = false;
  String? _clonedVoiceId;
  String _clonedVoiceName = "សំឡេងមនុស្សពិតរបស់ខ្ញុំ";

  final List<int> _durations = [15, 30, 60, 90];
  final List<String> _genres = [
    "រន្ធត់ / ខ្មោចឆៅ (Horror)",
    "សកម្មភាព / វាយប្រហារ (Action)",
    "អាថ៌កំបាំង / ស៊ើបអង្កេត (Mystery)",
    "វិទ្យាសាស្ត្រ / Sci-Fi",
    "មនោសញ្ចេតនា / កម្សត់ (Drama)"
  ];

  Future<void> _startGeneration() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("សូមបញ្ចូលចំណងជើងរឿងជាមុនសិន!")),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final url = Uri.parse("$kBackendBaseUrl/api/recap/generate");
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "movie_title": title,
          "genre": _selectedGenre,
          "duration": _selectedDuration,
          "notes": _notesController.text.trim(),
          "include_child_voice": _enableChildVoice,
          "include_elderly_voice": _enableElderlyVoice,
          "use_cloned_voice": _useClonedVoice,
          "cloned_voice_id": _clonedVoiceId,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final String taskId = data["task_id"];

        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProgressScreen(taskId: taskId, movieTitle: title),
          ),
        );
      } else {
        throw Exception("Server Error: ${response.statusCode}");
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("មិនអាចភ្ជាប់ទៅកាន់ Server បានទេ៖ $e")),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.movie_filter_rounded, color: Color(0xFFE11D48)),
            SizedBox(width: 8),
            Text('AI Movie Recap Studio', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        backgroundColor: const Color(0xFF111827),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.mic, color: Color(0xFFF59E0B)),
            tooltip: "គ្រប់គ្រងសំឡេង Clone",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const VoiceCloneScreen()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ផ្នែកបញ្ចូលចំណងជើងរឿង
            const Text("ចំណងជើងភាពយន្តសម្រាយ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white70)),
            const SizedBox(height: 8),
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                hintText: "ឧទាហរណ៍៖ Train to Busan, Interstellar...",
                filled: true,
                fillColor: const Color(0xFF111827),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                prefixIcon: const Icon(Icons.movie_creation_outlined, color: Color(0xFFE11D48)),
              ),
            ),
            const SizedBox(height: 20),

            // ផ្នែកជ្រើសរើសប្រភេទរឿង
            const Text("ប្រភេទភាពយន្ត (Genre)", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white70)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedGenre,
                  isExpanded: true,
                  dropdownColor: const Color(0xFF111827),
                  items: _genres.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                  onChanged: (val) => setState(() => _selectedGenre = val!),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ផ្នែកជ្រើសរើសរយៈពេល
            const Text("រយៈពេលស្គ្រីបសម្រាយ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white70)),
            const SizedBox(height: 10),
            Row(
              children: _durations.map((d) {
                final isSelected = _selectedDuration == d;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text("$d នាទី"),
                      selected: isSelected,
                      selectedColor: const Color(0xFFE11D48),
                      backgroundColor: const Color(0xFF111827),
                      labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.white60, fontWeight: FontWeight.bold),
                      onSelected: (val) => setState(() => _selectedDuration = d),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            // ផ្នែកកំណត់សំឡេងអាន (សំឡេងកូនក្មេង/មនុស្សចាស់/សំឡេង Clone)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("កំណត់ជម្រើសសំឡេង AI (Voice Settings)", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFF59E0B))),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    title: const Text("បន្ថែមសំឡេងកូនក្មេង (Child Voice)"),
                    subtitle: const Text("សម្រាប់ឈុតឆាកតួរងជាកុមារ"),
                    value: _enableChildVoice,
                    activeColor: const Color(0xFFE11D48),
                    onChanged: (val) => setState(() => _enableChildVoice = val),
                  ),
                  SwitchListTile(
                    title: const Text("បន្ថែមសំឡេងមនុស្សចាស់ (Elderly Voice)"),
                    subtitle: const Text("សម្រាប់តួអង្គដូនតា ឬមនុស្សចាស់"),
                    value: _enableElderlyVoice,
                    activeColor: const Color(0xFFE11D48),
                    onChanged: (val) => setState(() => _enableElderlyVoice = val),
                  ),
                  const Divider(color: Colors.white10),
                  SwitchListTile(
                    title: const Text("ប្រើប្រាស់សំឡេង Clone មនុស្សពិត"),
                    subtitle: Text(_useClonedVoice ? _clonedVoiceName : "អានដោយ AI Voice Profiles ដែលបាន Clone"),
                    value: _useClonedVoice,
                    activeColor: const Color(0xFFF59E0B),
                    onChanged: (val) => setState(() => _useClonedVoice = val),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // កំណត់ចំណាំបន្ថែម
            const Text("កំណត់ចំណាំពិសេស (Director Notes)", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white70)),
            const SizedBox(height: 8),
            TextField(
              controller: _notesController,
              maxLines: 2,
              decoration: InputDecoration(
                hintText: "ឧទាហរណ៍៖ សង្កត់ធ្ងន់លើអារម្មណ៍កម្សត់ និងឈុតឆាកតស៊ូ...",
                filled: true,
                fillColor: const Color(0xFF111827),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 30),

            // ប៊ូតុងចាប់ផ្តើម
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _isSubmitting ? null : _startGeneration,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE11D48),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: _isSubmitting
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.auto_awesome, color: Colors.white),
                label: Text(
                  _isSubmitting ? "កំពុងរៀបចំបង្កើត..." : "🚀 ចាប់ផ្តើមបង្កើត Script & សំឡេង",
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------------------
// ៣. អេក្រង់ Progress Bar (Progress Screen) - តាមដានការសរសេរ 5 Acts & បម្លែងសំឡេង
// ------------------------------------------------------------------------------
class ProgressScreen extends StatefulWidget {
  final String taskId;
  final String movieTitle;

  const ProgressScreen({super.key, required this.taskId, required this.movieTitle});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  Timer? _timer;
  int _progress = 5;
  String _stage = "កំពុងរៀបចំប្រព័ន្ធ...";
  String _status = "pending";
  Map<String, dynamic>? _result;

  @override
  void initState() {
    super.initState();
    _startPolling();
  }

  void _startPolling() {
    _timer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      try {
        final url = Uri.parse("$kBackendBaseUrl/api/recap/status/${widget.taskId}");
        final response = await http.get(url);

        if (response.statusCode == 200) {
          final data = jsonDecode(utf8.decode(response.bodyBytes));
          setState(() {
            _progress = data["progress"] ?? 0;
            _stage = data["stage"] ?? "";
            _status = data["status"] ?? "";
            _result = data["result"];
          });

          if (_status == "completed") {
            _timer?.cancel();
            if (!mounted) return;
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => RecapDetailScreen(
                  taskData: data,
                  movieTitle: widget.movieTitle,
                ),
              ),
            );
          } else if (_status == "failed") {
            _timer?.cancel();
          }
        }
      } catch (e) {
        debugPrint("Error polling status: $e");
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.movieTitle), backgroundColor: const Color(0xFF111827)),
      body: Center(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 140,
                  height: 140,
                  child: CircularProgressIndicator(
                    value: _progress / 100,
                    strokeWidth: 10,
                    backgroundColor: Colors.white10,
                    color: const Color(0xFFE11D48),
                  ),
                ),
                Text("$_progress%", style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 30),
            Text(_stage, style: const TextStyle(fontSize: 16, color: Color(0xFFF59E0B), fontWeight: FontWeight.w600), textAlign: TextAlign.center),
            const SizedBox(height: 12),
            const Text("AI កំពុងចាក់សង្វាក់សរសេរ 5 Acts និងបម្លែងសំឡេងអាន...", style: TextStyle(color: Colors.white54, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------------------
// ៤. អេក្រង់បង្ហាញលទ្ធផល និង Storyboard Player
// ------------------------------------------------------------------------------
class RecapDetailScreen extends StatelessWidget {
  final Map<String, dynamic> taskData;
  final String movieTitle;

  const RecapDetailScreen({super.key, required this.taskData, required this.movieTitle});

  @override
  Widget build(BuildContext context) {
    final result = taskData["result"] ?? {};
    final String scriptContent = result["script_content"] ?? "គ្មានអត្ថបទ";
    final String audioUrl = "$kBackendBaseUrl${result["audio_url"] ?? ""}";

    return Scaffold(
      appBar: AppBar(
        title: Text(movieTitle),
        backgroundColor: const Color(0xFF111827),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("បានចម្លងស្គ្រីបសម្រាប់ Share")));
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // ផ្ទាំង Storyboard Player Mockup
          Container(
            height: 220,
            width: double.infinity,
            color: Colors.black,
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(Icons.movie, size: 64, color: Colors.white24),
                Positioned(
                  bottom: 12,
                  left: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.black70, borderRadius: BorderRadius.circular(8)),
                    child: Text(
                      "🎬 សម្រាយរឿង៖ $movieTitle (${result['word_count'] ?? 0} ពាក្យ)",
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                )
              ],
            ),
          ),

          // ផ្នែក Audio Bar Controls
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: const Color(0xFF111827),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.play_circle_fill, color: Color(0xFFE11D48), size: 40),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("កំពុងចាក់សំឡេងពី៖ $audioUrl")));
                  },
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("សំឡេងអាន៖ ${result['voice_used'] ?? 'Edge TTS'}", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      const Text("00:00 / 15:00 នាទី", style: TextStyle(color: Colors.white54, fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ផ្នែកបង្ហាញ Script 5 Acts
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: SelectableText(
                scriptContent,
                style: const TextStyle(fontSize: 14, height: 1.6, color: Colors.white70),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------------------
// ៥. អេក្រង់គ្រប់គ្រង និង Clone សំឡេង AI (Voice Cloning Screen)
// ------------------------------------------------------------------------------
class VoiceCloneScreen extends StatefulWidget {
  const VoiceCloneScreen({super.key});

  @override
  State<VoiceCloneScreen> createState() => _VoiceCloneScreenState();
}

class _VoiceCloneScreenState extends State<VoiceCloneScreen> {
  final TextEditingController _nameController = TextEditingController(text: "សំឡេងមនុស្សពិតរបស់ខ្ញុំ");
  bool _isUploading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("AI Voice Cloning Studio"), backgroundColor: const Color(0xFF111827)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("បង្កើត Voice Profile ពីសំឡេងមនុស្សពិត (10s - 30s)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFFF59E0B))),
            const SizedBox(height: 12),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: "ឈ្មោះ Voice Profile",
                filled: true,
                fillColor: const Color(0xFF111827),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              height: 140,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white24, style: BorderStyle.solid),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.cloud_upload_outlined, size: 40, color: Color(0xFFE11D48)),
                  SizedBox(height: 8),
                  Text("ចុចទីនេះដើម្បី Upload ឯកសារ MP3 / WAV សំឡេងគំរូ", style: TextStyle(color: Colors.white60, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                onPressed: _isUploading
                    ? null
                    : () {
                        setState(() => _isUploading = true);
                        Future.delayed(const Duration(seconds: 2), () {
                          if (mounted) {
                            setState(() => _isUploading = false);
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("✅ បានបង្កើត Voice Profile រួចរាល់!")));
                            Navigator.pop(context);
                          }
                        });
                      },
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF59E0B)),
                icon: const Icon(Icons.fingerprint, color: Colors.black),
                label: Text(_isUploading ? "កំពុងដំណើការ Denoise & Clone..." : "ចាប់ផ្តើម Clone សំឡេង", style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
