# 🎬 Khmer Movie Recap AI - Flutter Mobile Client

កម្មវិធីទូរស័ព្ទ Flutter សម្រាប់ផលិត និងចាក់បញ្ចាំងវីដេអូសម្រាយរឿងខ្មែរភ្ជាប់ជាមួយ **FastAPI Backend Engine** និង **Microsoft Edge-TTS**។

---

## 📦 កញ្ចប់ជំនួយ (Dependencies in `pubspec.yaml`)

```yaml
dependencies:
  flutter:
    sdk: flutter
  http: ^1.2.0              # សម្រាប់ផ្ញើ Request ទៅកាន់ FastAPI Server
  video_player: ^2.8.2      # សម្រាប់ចាក់វីដេអូសម្រាយរឿង
  audioplayers: ^6.0.0      # សម្រាប់ចាក់ឯកសារសំឡេង MP3
  cupertino_icons: ^1.0.6
```

---

## 🚀 របៀបដំឡើង និងដំណើរការ (Setup & Run)

### ជំហានទី១: ទាញយកកញ្ចប់ Dependencies (`flutter pub get`)

បើក Terminal នៅក្នុងថត `flutter_movie_recap/` រួចវាយបញ្ជា៖
```bash
flutter pub get
```

លទ្ធផលរំពឹងទុក៖
```
Resolving dependencies...
+ http 1.2.0
+ video_player 2.8.2
+ audioplayers 6.0.0
+ cupertino_icons 1.0.6
+ flutter_lints 3.0.0
Downloading packages...
Got dependencies!
```

---

### ជំហានទី២: កំណត់អាសយដ្ឋាន Server (IP Address)

នៅក្នុងឯកសារ `lib/services/api_service.dart`:
- ប្រសិនបើប្រើ **Android Emulator**: ប្រើ `http://10.0.2.2:8001`
- ប្រសិនបើប្រើ **iOS Simulator**: ប្រើ `http://127.0.0.1:8001`
- ប្រសិនបើប្រើ **ទូរស័ព្ទពិត (Physical Device)**: ប្រើ IP របស់កុំព្យូទ័រឧទាហរណ៍ `http://192.168.1.50:8001`

---

### ជំហានទី៣: ដំណើរការកម្មវិធី

```bash
flutter run
```

---

## 📱 លក្ខណៈពិសេសចម្បងៗ (Key Features)

1. **Recap Generator Screen**: បញ្ចូលចំណងជើងរឿង ប្រភេទរឿង ជ្រើសរើសសំឡេង Khmer Edge-TTS (`km-KH-PisethNeural` ឬ `km-KH-SreymomNeural`)
2. **Real-time Task Progress Tracker**: តាមដានដំណើរការសរសេរ 5 Acts តាមរយៈ FastAPI `/api/recap/status/{task_id}`
3. **Synchronized Recap Player**:
   - ចាក់វីដេអូឈុតឆាកជាមួយ `video_player`
   - ចាក់សំឡេង MP3 ខ្មែរជាមួយ `audioplayers`
   - បង្ហាញអត្ថបទសម្រាយរឿងពេញ 5 Acts
